"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const client_1 = require("@prisma/client");
const dotenv = __importStar(require("dotenv"));
dotenv.config();
const prisma = new client_1.PrismaClient();
function normalizePhone(phone) {
    const digits = phone.replace(/\D/g, '');
    if (digits.startsWith('251') && digits.length === 12)
        return digits;
    if (digits.startsWith('0') && digits.length === 10)
        return '251' + digits.slice(1);
    if (digits.length === 9)
        return '251' + digits;
    throw new Error(`Invalid phone: ${phone}`);
}
async function seedSuperAdmin() {
    const rawPhone = process.env.SUPER_ADMIN_PHONE;
    const name = process.env.SUPER_ADMIN_NAME || 'Super Admin';
    if (!rawPhone) {
        console.error('❌ SUPER_ADMIN_PHONE not set in .env');
        process.exit(1);
    }
    const phone = normalizePhone(rawPhone);
    console.log(`\n🔍 Checking for existing Super Admin...`);
    const existing = await prisma.staff.findFirst({
        where: { role: client_1.StaffRole.SUPER_ADMIN },
    });
    if (existing) {
        console.log(`⚠️  Super Admin already exists (id: ${existing.id}, phone: ${existing.phone})`);
        console.log(`   Skipping creation.`);
        return;
    }
    const byPhone = await prisma.staff.findUnique({ where: { phone } });
    let superAdmin;
    if (byPhone) {
        console.log(`📝 Staff with phone ${phone} exists — upgrading to SUPER_ADMIN`);
        superAdmin = await prisma.staff.update({
            where: { id: byPhone.id },
            data: {
                role: client_1.StaffRole.SUPER_ADMIN,
                name: byPhone.name || name,
                isActive: true,
                phoneVerified: true,
            },
        });
    }
    else {
        console.log(`✨ Creating new Super Admin...`);
        superAdmin = await prisma.staff.create({
            data: {
                phone,
                name,
                role: client_1.StaffRole.SUPER_ADMIN,
                isActive: true,
                phoneVerified: true,
            },
        });
    }
    console.log(`\n Super Admin ready:`);
    console.log(`   ID:    ${superAdmin.id}`);
    console.log(`   Phone: ${superAdmin.phone}`);
    console.log(`   Name:  ${superAdmin.name}`);
    console.log(`   Role:  ${superAdmin.role}`);
    console.log(`\n👉 Login with this phone via OTP\n`);
}
seedSuperAdmin()
    .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
})
    .finally(async () => {
    await prisma.$disconnect();
});
//# sourceMappingURL=seed.js.map