import { AdminService } from './admin.service';
import { CreateStaffDto } from './dto/create-staff.dto';
import { ListStaffQueryDto } from './dto/list-staff-query.dto';
declare class ResetPasswordDto {
    password: string;
}
export declare class AdminController {
    private admin;
    constructor(admin: AdminService);
    createRegionalAdmin(dto: CreateStaffDto, user: any): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        phone: string;
        email: string | null;
        mustChangePassword: boolean;
        role: import("@prisma/client").$Enums.StaffRole;
        regionId: string | null;
        branchId: string | null;
        isActive: boolean;
    }>;
    createBranchManager(dto: CreateStaffDto, user: any): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        phone: string;
        email: string | null;
        mustChangePassword: boolean;
        role: import("@prisma/client").$Enums.StaffRole;
        regionId: string | null;
        branchId: string | null;
        isActive: boolean;
    }>;
    listStaff(query: ListStaffQueryDto, user: any): Promise<{
        data: {
            id: string;
            name: string;
            createdAt: Date;
            phone: string;
            email: string | null;
            mustChangePassword: boolean;
            role: import("@prisma/client").$Enums.StaffRole;
            regionId: string | null;
            branchId: string | null;
            isActive: boolean;
            phoneVerified: boolean;
            suspendedAt: Date | null;
            region: {
                id: string;
                code: string;
                name: string;
            } | null;
            branch: {
                id: string;
                code: string;
                name: string;
            } | null;
        }[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    getStaff(id: string, user: any): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        phone: string;
        email: string | null;
        mustChangePassword: boolean;
        role: import("@prisma/client").$Enums.StaffRole;
        regionId: string | null;
        branchId: string | null;
        isActive: boolean;
        phoneVerified: boolean;
        suspendedAt: Date | null;
        region: {
            id: string;
            code: string;
            name: string;
        } | null;
        branch: {
            id: string;
            code: string;
            name: string;
        } | null;
    }>;
    suspend(id: string, user: any): Promise<{
        message: string;
    }>;
    reactivate(id: string, user: any): Promise<{
        message: string;
    }>;
    resetPassword(id: string, dto: ResetPasswordDto, user: any): Promise<{
        message: string;
    }>;
}
export {};
