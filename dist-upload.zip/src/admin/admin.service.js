"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminService = void 0;
const common_1 = require("@nestjs/common");
const argon2 = __importStar(require("argon2"));
const prisma_service_1 = require("../prisma/prisma.service");
const client_1 = require("@prisma/client");
const auto_assign_service_1 = require("../auto-assign/auto-assign.service");
const notifications_service_1 = require("../notifications/notifications.service");
let AdminService = class AdminService {
    constructor(prisma, autoAssign, notifications) {
        this.prisma = prisma;
        this.autoAssign = autoAssign;
        this.notifications = notifications;
    }
    async getStaffLocationScope(staffId) {
        const staff = await this.prisma.staff.findUnique({
            where: { id: staffId },
            select: { id: true, role: true, regionId: true, branchId: true },
        });
        if (!staff)
            throw new common_1.NotFoundException('Staff not found');
        if (staff.role === client_1.StaffRole.SUPER_ADMIN) {
            return { staff, orderWhere: {}, courierWhere: {} };
        }
        if (staff.role === client_1.StaffRole.REGIONAL_ADMIN && staff.regionId) {
            return {
                staff,
                orderWhere: { originBranch: { regionId: staff.regionId } },
                courierWhere: { regionId: staff.regionId },
            };
        }
        if (staff.role === client_1.StaffRole.BRANCH_MANAGER && staff.branchId) {
            return {
                staff,
                orderWhere: { originBranchId: staff.branchId },
                courierWhere: { branchId: staff.branchId },
            };
        }
        return {
            staff,
            orderWhere: { id: '__no_access__' },
            courierWhere: { id: '__no_access__' },
        };
    }
    async assertStaffOrderAccess(orderId, staffId) {
        const { orderWhere } = await this.getStaffLocationScope(staffId);
        const order = await this.prisma.order.findFirst({
            where: { AND: [{ id: orderId }, orderWhere] },
            select: { id: true },
        });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
    }
    normalizePhone(phone) {
        const digits = phone.replace(/\D/g, '');
        if (digits.startsWith('251') && digits.length === 12)
            return digits;
        if (digits.startsWith('0') && digits.length === 10)
            return '251' + digits.slice(1);
        if (digits.length === 9)
            return '251' + digits;
        throw new common_1.BadRequestException('Invalid phone');
    }
    async createStaff(dto, role, currentUser) {
        if (role === client_1.StaffRole.SUPER_ADMIN) {
            throw new common_1.ForbiddenException('Cannot create another Super Admin');
        }
        const phone = this.normalizePhone(dto.phone);
        if (role === client_1.StaffRole.REGIONAL_ADMIN && !dto.regionId) {
            throw new common_1.BadRequestException('Regional Admin requires a regionId');
        }
        if (role === client_1.StaffRole.BRANCH_MANAGER && (!dto.regionId || !dto.branchId)) {
            throw new common_1.BadRequestException('Branch Manager requires regionId and branchId');
        }
        if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN &&
            dto.regionId !== currentUser.regionId) {
            throw new common_1.ForbiddenException('You can only create staff in your region');
        }
        if (dto.regionId) {
            const region = await this.prisma.region.findUnique({
                where: { id: dto.regionId },
            });
            if (!region)
                throw new common_1.NotFoundException('Region not found');
        }
        if (dto.branchId) {
            const branch = await this.prisma.branch.findUnique({
                where: { id: dto.branchId },
            });
            if (!branch)
                throw new common_1.NotFoundException('Branch not found');
            if (dto.regionId && branch.regionId !== dto.regionId) {
                throw new common_1.BadRequestException('Branch does not belong to this region');
            }
        }
        const existing = await this.prisma.staff.findUnique({ where: { phone } });
        if (existing) {
            throw new common_1.ConflictException('A staff member with this phone already exists');
        }
        if (dto.email) {
            const emailExists = await this.prisma.staff.findUnique({
                where: { email: dto.email },
            });
            if (emailExists)
                throw new common_1.ConflictException('Email already in use');
        }
        const passwordHash = dto.password ? await argon2.hash(dto.password) : null;
        const data = {
            phone,
            name: dto.name,
            email: dto.email,
            role,
            passwordHash,
            passwordChangedAt: passwordHash ? new Date() : null,
            mustChangePassword: passwordHash ? (dto.mustChangePassword ?? false) : false,
            isActive: true,
            phoneVerified: false,
            createdById: currentUser.id,
        };
        if (dto.regionId)
            data.regionId = dto.regionId;
        if (dto.branchId)
            data.branchId = dto.branchId;
        return this.prisma.staff.create({
            data,
            select: {
                id: true,
                phone: true,
                name: true,
                email: true,
                role: true,
                regionId: true,
                branchId: true,
                isActive: true,
                mustChangePassword: true,
                createdAt: true,
            },
        });
    }
    async listStaff(query, currentUser) {
        const where = {};
        if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN) {
            where.regionId = currentUser.regionId;
        }
        else if (query.regionId) {
            where.regionId = query.regionId;
        }
        if (query.role)
            where.role = query.role;
        if (query.branchId)
            where.branchId = query.branchId;
        if (query.search) {
            where.OR = [
                { phone: { contains: query.search } },
                { name: { contains: query.search, mode: 'insensitive' } },
                { email: { contains: query.search, mode: 'insensitive' } },
            ];
        }
        const page = query.page || 1;
        const limit = query.limit || 20;
        const skip = (page - 1) * limit;
        const [data, total] = await Promise.all([
            this.prisma.staff.findMany({
                where,
                select: {
                    id: true,
                    phone: true,
                    name: true,
                    email: true,
                    role: true,
                    regionId: true,
                    branchId: true,
                    isActive: true,
                    phoneVerified: true,
                    mustChangePassword: true,
                    suspendedAt: true,
                    createdAt: true,
                    region: { select: { id: true, name: true, code: true } },
                    branch: { select: { id: true, name: true, code: true } },
                },
                orderBy: { createdAt: 'desc' },
                skip,
                take: limit,
            }),
            this.prisma.staff.count({ where }),
        ]);
        return {
            data,
            total,
            page,
            limit,
            pages: Math.ceil(total / limit),
        };
    }
    async getStaff(id, currentUser) {
        const staff = await this.prisma.staff.findUnique({
            where: { id },
            select: {
                id: true,
                phone: true,
                name: true,
                email: true,
                role: true,
                regionId: true,
                branchId: true,
                isActive: true,
                phoneVerified: true,
                mustChangePassword: true,
                suspendedAt: true,
                createdAt: true,
                region: { select: { id: true, name: true, code: true } },
                branch: { select: { id: true, name: true, code: true } },
            },
        });
        if (!staff)
            throw new common_1.NotFoundException('Staff not found');
        if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN &&
            staff.regionId !== currentUser.regionId) {
            throw new common_1.ForbiddenException('You can only view staff in your region');
        }
        return staff;
    }
    async suspendStaff(id, currentUser) {
        const target = await this.prisma.staff.findUnique({ where: { id } });
        if (!target)
            throw new common_1.NotFoundException('Staff not found');
        if (target.role === client_1.StaffRole.SUPER_ADMIN) {
            throw new common_1.ForbiddenException('Cannot suspend Super Admin');
        }
        if (target.id === currentUser.id) {
            throw new common_1.ForbiddenException('Cannot suspend yourself');
        }
        if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN &&
            target.regionId !== currentUser.regionId) {
            throw new common_1.ForbiddenException('You can only suspend staff in your region');
        }
        await this.prisma.staff.update({
            where: { id },
            data: {
                isActive: false,
                suspendedAt: new Date(),
                suspendedById: currentUser.id,
            },
        });
        await this.prisma.refreshToken.updateMany({
            where: { accountId: id, accountType: client_1.AccountType.STAFF, revokedAt: null },
            data: { revokedAt: new Date() },
        });
        return { message: 'Staff suspended' };
    }
    async reactivateStaff(id, currentUser) {
        const target = await this.prisma.staff.findUnique({ where: { id } });
        if (!target)
            throw new common_1.NotFoundException('Staff not found');
        if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN &&
            target.regionId !== currentUser.regionId) {
            throw new common_1.ForbiddenException('You can only reactivate staff in your region');
        }
        await this.prisma.staff.update({
            where: { id },
            data: {
                isActive: true,
                suspendedAt: null,
                suspendedById: null,
            },
        });
        return { message: 'Staff reactivated' };
    }
    async resetPassword(id, newPassword, currentUser) {
        const target = await this.prisma.staff.findUnique({ where: { id } });
        if (!target)
            throw new common_1.NotFoundException('Staff not found');
        if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN &&
            target.regionId !== currentUser.regionId) {
            throw new common_1.ForbiddenException('You can only reset passwords in your region');
        }
        const passwordHash = await argon2.hash(newPassword);
        await this.prisma.staff.update({
            where: { id },
            data: {
                passwordHash,
                passwordChangedAt: new Date(),
                mustChangePassword: true,
            },
        });
        await this.prisma.refreshToken.updateMany({
            where: { accountId: id, accountType: client_1.AccountType.STAFF, revokedAt: null },
            data: { revokedAt: new Date() },
        });
        return { message: 'Password reset' };
    }
    async retryAutoAssign(orderId, staffId) {
        await this.assertStaffOrderAccess(orderId, staffId);
        const order = await this.prisma.order.findUnique({
            where: { id: orderId },
        });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        if (order.courierId) {
            throw new common_1.BadRequestException('Order already has a courier');
        }
        if (order.status !== 'PAID') {
            throw new common_1.BadRequestException(`Cannot auto-assign order in ${order.status} status. Must be PAID.`);
        }
        await this.prisma.orderEvent.create({
            data: {
                orderId,
                status: 'PAID',
                note: `Manual retry of auto-assign triggered by staff`,
                actorType: 'STAFF',
                actorId: staffId,
                isPublic: false,
            },
        });
        await this.autoAssign.tryAutoAssign(orderId);
        return { success: true, message: 'Auto-assign triggered' };
    }
    async assignCourier(orderId, courierId, staffId, note) {
        const { courierWhere } = await this.getStaffLocationScope(staffId);
        await this.assertStaffOrderAccess(orderId, staffId);
        const [order, courier] = await Promise.all([
            this.prisma.order.findUnique({ where: { id: orderId } }),
            this.prisma.courier.findFirst({
                where: { AND: [{ id: courierId }, courierWhere] },
            }),
        ]);
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        if (!courier)
            throw new common_1.NotFoundException('Courier not found');
        if (order.courierId) {
            throw new common_1.BadRequestException('Order already has a courier assigned');
        }
        if (courier.status !== 'APPROVED' || !courier.isActive) {
            throw new common_1.BadRequestException('Courier is not active or approved');
        }
        const result = await this.prisma.order.updateMany({
            where: {
                id: orderId,
                courierId: null,
                status: { in: ['PAID', 'DRAFT', 'PENDING_PAYMENT'] },
            },
            data: {
                courierId,
                assignedAt: new Date(),
                status: 'ASSIGNED',
                autoUnassignAt: new Date(Date.now() + 15 * 60_000),
            },
        });
        if (result.count === 0) {
            throw new common_1.ConflictException('Order already assigned');
        }
        await this.prisma.orderEvent.create({
            data: {
                orderId,
                status: 'ASSIGNED',
                note: note || `Manually assigned by staff`,
                actorType: 'STAFF',
                actorId: staffId,
                isPublic: true,
            },
        });
        await this.notifications.notifyOrderStatus({
            ...order,
            status: 'ASSIGNED',
            courierId,
        });
        return { success: true, courierId, courierName: courier.name };
    }
    async listUnassignedOrders(staffId, page = 1, limit = 20) {
        const { orderWhere } = await this.getStaffLocationScope(staffId);
        const skip = (page - 1) * limit;
        const where = {
            AND: [
                { status: 'PAID', courierId: null },
                orderWhere,
            ],
        };
        const [data, total] = await Promise.all([
            this.prisma.order.findMany({
                where,
                skip,
                take: limit,
                orderBy: { createdAt: 'desc' },
                select: {
                    id: true,
                    trackingNumber: true,
                    senderName: true,
                    senderPhone: true,
                    receiverName: true,
                    receiverPhone: true,
                    receiverAddress: true,
                    totalWeightKg: true,
                    isFragile: true,
                    isRefrigerated: true,
                    routeCategory: true,
                    routeDistanceKm: true,
                    autoAssignAttempts: true,
                    lastOfferedAt: true,
                    createdAt: true,
                    originBranch: {
                        select: { id: true, name: true, code: true, city: true },
                    },
                    destBranch: {
                        select: { id: true, name: true, code: true, city: true },
                    },
                },
            }),
            this.prisma.order.count({ where }),
        ]);
        return {
            data,
            total,
            page,
            limit,
            pages: Math.ceil(total / limit),
        };
    }
    async listOrderOffers(orderId, staffId) {
        await this.assertStaffOrderAccess(orderId, staffId);
        return this.prisma.orderOffer.findMany({
            where: { orderId },
            orderBy: { offeredAt: 'desc' },
            include: {
                courier: {
                    select: {
                        id: true,
                        name: true,
                        phone: true,
                        vehicleType: true,
                        rating: true,
                        totalDeliveries: true,
                    },
                },
            },
        });
    }
    async getAutoAssignStats(staffId) {
        const { orderWhere } = await this.getStaffLocationScope(staffId);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const [totalOffers, acceptedOffers, rejectedOffers, expiredOffers, unassignedCount, avgAttempts,] = await Promise.all([
            this.prisma.orderOffer.count({
                where: { offeredAt: { gte: today }, order: orderWhere },
            }),
            this.prisma.orderOffer.count({
                where: { offeredAt: { gte: today }, status: 'ACCEPTED', order: orderWhere },
            }),
            this.prisma.orderOffer.count({
                where: { offeredAt: { gte: today }, status: 'REJECTED', order: orderWhere },
            }),
            this.prisma.orderOffer.count({
                where: { offeredAt: { gte: today }, status: 'EXPIRED', order: orderWhere },
            }),
            this.prisma.order.count({
                where: { AND: [{ status: 'PAID', courierId: null }, orderWhere] },
            }),
            this.prisma.order.aggregate({
                where: { createdAt: { gte: today }, ...orderWhere },
                _avg: { autoAssignAttempts: true },
            }),
        ]);
        const acceptanceRate = totalOffers > 0 ? (acceptedOffers / totalOffers) * 100 : 0;
        return {
            today: {
                totalOffers,
                acceptedOffers,
                rejectedOffers,
                expiredOffers,
                acceptanceRate: Math.round(acceptanceRate * 10) / 10,
            },
            unassignedCount,
            avgAttemptsPerOrder: Math.round((avgAttempts._avg.autoAssignAttempts ?? 0) * 10) / 10,
        };
    }
};
exports.AdminService = AdminService;
exports.AdminService = AdminService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        auto_assign_service_1.AutoAssignService,
        notifications_service_1.NotificationsService])
], AdminService);
//# sourceMappingURL=admin.service.js.map