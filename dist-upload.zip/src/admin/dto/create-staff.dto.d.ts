export declare class CreateStaffDto {
    phone: string;
    name: string;
    email?: string;
    regionId?: string;
    branchId?: string;
    password?: string;
    mustChangePassword?: boolean;
}
