export declare class AssignCourierDto {
    courierId: string;
    note?: string;
}
