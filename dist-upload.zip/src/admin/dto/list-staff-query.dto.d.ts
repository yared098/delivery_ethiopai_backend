import { StaffRole } from '@prisma/client';
export declare class ListStaffQueryDto {
    role?: StaffRole;
    regionId?: string;
    branchId?: string;
    search?: string;
    page?: number;
    limit?: number;
}
