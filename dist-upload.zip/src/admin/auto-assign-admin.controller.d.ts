import { AdminService } from './admin.service';
import { AssignCourierDto } from './dto/assign-courier.dto';
export declare class AutoAssignAdminController {
    private admin;
    constructor(admin: AdminService);
    retryAutoAssign(id: string, user: any): Promise<{
        success: boolean;
        message: string;
    }>;
    assignCourier(id: string, dto: AssignCourierDto, user: any): Promise<{
        success: boolean;
        courierId: string;
        courierName: string;
    }>;
    listUnassigned(user: any, page?: string, limit?: string): Promise<{
        data: {
            id: string;
            createdAt: Date;
            trackingNumber: string;
            senderName: string;
            senderPhone: string;
            receiverName: string | null;
            receiverPhone: string;
            receiverAddress: string | null;
            routeCategory: import("@prisma/client").$Enums.RouteCategory | null;
            routeDistanceKm: number | null;
            autoAssignAttempts: number;
            lastOfferedAt: Date | null;
            totalWeightKg: number;
            isFragile: boolean;
            isRefrigerated: boolean;
            originBranch: {
                id: string;
                code: string;
                name: string;
                city: string | null;
            } | null;
            destBranch: {
                id: string;
                code: string;
                name: string;
                city: string | null;
            } | null;
        }[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    listOffers(id: string, user: any): Promise<({
        courier: {
            id: string;
            name: string;
            phone: string;
            vehicleType: import("@prisma/client").$Enums.VehicleType;
            rating: number;
            totalDeliveries: number;
        };
    } & {
        id: string;
        courierId: string;
        status: import("@prisma/client").$Enums.OfferStatus;
        expiresAt: Date;
        rejectionReason: string | null;
        orderId: string;
        offeredAt: Date;
        respondedAt: Date | null;
        pickupKm: number | null;
        routeKm: number | null;
        attemptNo: number;
    })[]>;
    getAutoAssignStats(user: any): Promise<{
        today: {
            totalOffers: number;
            acceptedOffers: number;
            rejectedOffers: number;
            expiredOffers: number;
            acceptanceRate: number;
        };
        unassignedCount: number;
        avgAttemptsPerOrder: number;
    }>;
}
