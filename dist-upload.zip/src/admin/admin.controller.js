"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminController = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const admin_service_1 = require("./admin.service");
const create_staff_dto_1 = require("./dto/create-staff.dto");
const list_staff_query_dto_1 = require("./dto/list-staff-query.dto");
const jwt_auth_guard_1 = require("../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../common/guards/roles.guard");
const staff_roles_decorator_1 = require("../common/decorators/staff-roles.decorator");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const client_1 = require("@prisma/client");
class ResetPasswordDto {
}
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(8, { message: 'Password must be at least 8 characters' }),
    __metadata("design:type", String)
], ResetPasswordDto.prototype, "password", void 0);
let AdminController = class AdminController {
    constructor(admin) {
        this.admin = admin;
    }
    createRegionalAdmin(dto, user) {
        return this.admin.createStaff(dto, client_1.StaffRole.REGIONAL_ADMIN, user);
    }
    createBranchManager(dto, user) {
        return this.admin.createStaff(dto, client_1.StaffRole.BRANCH_MANAGER, user);
    }
    listStaff(query, user) {
        return this.admin.listStaff(query, user);
    }
    getStaff(id, user) {
        return this.admin.getStaff(id, user);
    }
    suspend(id, user) {
        return this.admin.suspendStaff(id, user);
    }
    reactivate(id, user) {
        return this.admin.reactivateStaff(id, user);
    }
    resetPassword(id, dto, user) {
        return this.admin.resetPassword(id, dto.password, user);
    }
};
exports.AdminController = AdminController;
__decorate([
    (0, common_1.Post)('regional-admin'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_staff_dto_1.CreateStaffDto, Object]),
    __metadata("design:returntype", void 0)
], AdminController.prototype, "createRegionalAdmin", null);
__decorate([
    (0, common_1.Post)('branch-manager'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_staff_dto_1.CreateStaffDto, Object]),
    __metadata("design:returntype", void 0)
], AdminController.prototype, "createBranchManager", null);
__decorate([
    (0, common_1.Get)(),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_staff_query_dto_1.ListStaffQueryDto, Object]),
    __metadata("design:returntype", void 0)
], AdminController.prototype, "listStaff", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AdminController.prototype, "getStaff", null);
__decorate([
    (0, common_1.Post)(':id/suspend'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AdminController.prototype, "suspend", null);
__decorate([
    (0, common_1.Post)(':id/reactivate'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], AdminController.prototype, "reactivate", null);
__decorate([
    (0, common_1.Post)(':id/reset-password'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, ResetPasswordDto, Object]),
    __metadata("design:returntype", void 0)
], AdminController.prototype, "resetPassword", null);
exports.AdminController = AdminController = __decorate([
    (0, common_1.Controller)('admin/staff'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    __metadata("design:paramtypes", [admin_service_1.AdminService])
], AdminController);
//# sourceMappingURL=admin.controller.js.map