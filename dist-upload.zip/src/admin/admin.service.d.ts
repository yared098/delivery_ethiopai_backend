import { PrismaService } from '../prisma/prisma.service';
import { CreateStaffDto } from './dto/create-staff.dto';
import { ListStaffQueryDto } from './dto/list-staff-query.dto';
import { StaffRole } from '@prisma/client';
import { AutoAssignService } from '../auto-assign/auto-assign.service';
import { NotificationsService } from '../notifications/notifications.service';
export declare class AdminService {
    private prisma;
    private autoAssign;
    private notifications;
    constructor(prisma: PrismaService, autoAssign: AutoAssignService, notifications: NotificationsService);
    private getStaffLocationScope;
    private assertStaffOrderAccess;
    private normalizePhone;
    createStaff(dto: CreateStaffDto, role: StaffRole, currentUser: any): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        phone: string;
        email: string | null;
        mustChangePassword: boolean;
        role: import("@prisma/client").$Enums.StaffRole;
        regionId: string | null;
        branchId: string | null;
        isActive: boolean;
    }>;
    listStaff(query: ListStaffQueryDto, currentUser: any): Promise<{
        data: {
            id: string;
            name: string;
            createdAt: Date;
            phone: string;
            email: string | null;
            mustChangePassword: boolean;
            role: import("@prisma/client").$Enums.StaffRole;
            regionId: string | null;
            branchId: string | null;
            isActive: boolean;
            phoneVerified: boolean;
            suspendedAt: Date | null;
            region: {
                id: string;
                code: string;
                name: string;
            } | null;
            branch: {
                id: string;
                code: string;
                name: string;
            } | null;
        }[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    getStaff(id: string, currentUser: any): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        phone: string;
        email: string | null;
        mustChangePassword: boolean;
        role: import("@prisma/client").$Enums.StaffRole;
        regionId: string | null;
        branchId: string | null;
        isActive: boolean;
        phoneVerified: boolean;
        suspendedAt: Date | null;
        region: {
            id: string;
            code: string;
            name: string;
        } | null;
        branch: {
            id: string;
            code: string;
            name: string;
        } | null;
    }>;
    suspendStaff(id: string, currentUser: any): Promise<{
        message: string;
    }>;
    reactivateStaff(id: string, currentUser: any): Promise<{
        message: string;
    }>;
    resetPassword(id: string, newPassword: string, currentUser: any): Promise<{
        message: string;
    }>;
    retryAutoAssign(orderId: string, staffId: string): Promise<{
        success: boolean;
        message: string;
    }>;
    assignCourier(orderId: string, courierId: string, staffId: string, note?: string): Promise<{
        success: boolean;
        courierId: string;
        courierName: string;
    }>;
    listUnassignedOrders(staffId: string, page?: number, limit?: number): Promise<{
        data: {
            id: string;
            createdAt: Date;
            trackingNumber: string;
            senderName: string;
            senderPhone: string;
            receiverName: string | null;
            receiverPhone: string;
            receiverAddress: string | null;
            routeCategory: import("@prisma/client").$Enums.RouteCategory | null;
            routeDistanceKm: number | null;
            autoAssignAttempts: number;
            lastOfferedAt: Date | null;
            totalWeightKg: number;
            isFragile: boolean;
            isRefrigerated: boolean;
            originBranch: {
                id: string;
                code: string;
                name: string;
                city: string | null;
            } | null;
            destBranch: {
                id: string;
                code: string;
                name: string;
                city: string | null;
            } | null;
        }[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    listOrderOffers(orderId: string, staffId: string): Promise<({
        courier: {
            id: string;
            name: string;
            phone: string;
            vehicleType: import("@prisma/client").$Enums.VehicleType;
            rating: number;
            totalDeliveries: number;
        };
    } & {
        id: string;
        courierId: string;
        status: import("@prisma/client").$Enums.OfferStatus;
        expiresAt: Date;
        rejectionReason: string | null;
        orderId: string;
        offeredAt: Date;
        respondedAt: Date | null;
        pickupKm: number | null;
        routeKm: number | null;
        attemptNo: number;
    })[]>;
    getAutoAssignStats(staffId: string): Promise<{
        today: {
            totalOffers: number;
            acceptedOffers: number;
            rejectedOffers: number;
            expiredOffers: number;
            acceptanceRate: number;
        };
        unassignedCount: number;
        avgAttemptsPerOrder: number;
    }>;
}
