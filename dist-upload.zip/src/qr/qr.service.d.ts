import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
export declare class QrService {
    private config;
    private prisma;
    private readonly logger;
    constructor(config: ConfigService, prisma: PrismaService);
    signQr(value: string): string;
    signTracking(value: string): string;
    verifySignature(value: string, signature: string, type: 'qr' | 'tracking'): boolean;
    generateForOrder(orderId: string, trackingNumber: string): Promise<{
        payload: string;
        signature: string;
        imageUrl: string;
    }>;
    generateBufferFromPayload(payload: string): Promise<Buffer>;
    getOrderQrBuffer(orderId: string): Promise<{
        buffer: Buffer;
        payload: string;
        trackingNumber: string;
    }>;
    generateTrackingToken(orderId: string): Promise<{
        token: string;
        signature: string;
        url: string;
    }>;
    revokeTrackingToken(orderId: string): Promise<{
        message: string;
    }>;
    getPublicInfo(trackingNumber: string, signature: string): Promise<{
        trackingNumber: string;
        status: import("@prisma/client").$Enums.OrderStatus;
        origin: {
            branch: string;
            code: string;
        } | null;
        destination: {
            branch: string;
            code: string;
        } | null;
        receiver: {
            name: string;
            phoneMasked: string;
        };
        package: {
            weightKg: number;
            isFragile: boolean;
            isRefrigerated: boolean;
            itemCount: number;
        };
        items: {
            description: string | null;
            quantity: number;
            weightKg: number;
            isFragile: boolean;
        }[];
        signature: string;
        checkedAt: string;
    }>;
    private maskName;
    private maskPhone;
}
