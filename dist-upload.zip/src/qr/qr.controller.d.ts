import { OnModuleDestroy } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { QrService } from './qr.service';
export declare class QrController implements OnModuleDestroy {
    private qr;
    private config;
    private redis;
    constructor(qr: QrService, config: ConfigService);
    onModuleDestroy(): void;
    scan(trackingNumber: string, signature: string, req: any): Promise<{
        trackingNumber: string;
        status: import("@prisma/client").$Enums.OrderStatus;
        origin: {
            branch: string;
            code: string;
        } | null;
        destination: {
            branch: string;
            code: string;
        } | null;
        receiver: {
            name: string;
            phoneMasked: string;
        };
        package: {
            weightKg: number;
            isFragile: boolean;
            isRefrigerated: boolean;
            itemCount: number;
        };
        items: {
            description: string | null;
            quantity: number;
            weightKg: number;
            isFragile: boolean;
        }[];
        signature: string;
        checkedAt: string;
    }>;
}
