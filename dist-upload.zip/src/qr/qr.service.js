"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var QrService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.QrService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const crypto_1 = require("crypto");
const QRCode = __importStar(require("qrcode"));
const prisma_service_1 = require("../prisma/prisma.service");
let QrService = QrService_1 = class QrService {
    constructor(config, prisma) {
        this.config = config;
        this.prisma = prisma;
        this.logger = new common_1.Logger(QrService_1.name);
    }
    signQr(value) {
        const secret = this.config.get('QR_SECRET');
        if (!secret)
            throw new Error('QR_SECRET not configured');
        return (0, crypto_1.createHmac)('sha256', secret).update(value).digest('hex').slice(0, 6);
    }
    signTracking(value) {
        const secret = this.config.get('TRACKING_SECRET');
        if (!secret)
            throw new Error('TRACKING_SECRET not configured');
        return (0, crypto_1.createHmac)('sha256', secret).update(value).digest('hex').slice(0, 6);
    }
    verifySignature(value, signature, type) {
        const expected = type === 'qr' ? this.signQr(value) : this.signTracking(value);
        if (expected.length !== signature.length)
            return false;
        let diff = 0;
        for (let i = 0; i < expected.length; i++) {
            diff |= expected.charCodeAt(i) ^ signature.charCodeAt(i);
        }
        return diff === 0;
    }
    async generateForOrder(orderId, trackingNumber) {
        const publicWebUrl = this.config.get('PUBLIC_WEB_URL') || 'http://localhost:5173';
        const signature = this.signQr(trackingNumber);
        const payload = `${publicWebUrl}/q/${trackingNumber}?s=${signature}`;
        const qrDataUrl = await QRCode.toDataURL(payload, {
            width: 400,
            margin: 2,
            errorCorrectionLevel: 'M',
            color: {
                dark: '#000000',
                light: '#ffffff',
            },
        });
        await this.prisma.order.update({
            where: { id: orderId },
            data: {
                qrCodePayload: payload,
                qrCodeSignature: signature,
                qrCodeImageUrl: qrDataUrl,
            },
        });
        this.logger.log(`QR generated for ${trackingNumber}`);
        return { payload, signature, imageUrl: qrDataUrl };
    }
    async generateBufferFromPayload(payload) {
        return QRCode.toBuffer(payload, {
            width: 450,
            margin: 2,
            errorCorrectionLevel: 'M',
            color: {
                dark: '#000000',
                light: '#ffffff',
            },
        });
    }
    async getOrderQrBuffer(orderId) {
        const order = await this.prisma.order.findUnique({
            where: { id: orderId },
            select: {
                id: true,
                trackingNumber: true,
                qrCodePayload: true,
                qrCodeImageUrl: true,
            },
        });
        if (!order) {
            throw new common_1.BadRequestException('Order not found');
        }
        let payload = order.qrCodePayload;
        if (!payload) {
            const generated = await this.generateForOrder(order.id, order.trackingNumber);
            payload = generated.payload;
        }
        if (order.qrCodeImageUrl && order.qrCodeImageUrl.startsWith('data:image/')) {
            const base64Data = order.qrCodeImageUrl.replace(/^data:image\/\w+;base64,/, '');
            const buffer = Buffer.from(base64Data, 'base64');
            return { buffer, payload, trackingNumber: order.trackingNumber };
        }
        const buffer = await this.generateBufferFromPayload(payload);
        return { buffer, payload, trackingNumber: order.trackingNumber };
    }
    async generateTrackingToken(orderId) {
        const publicWebUrl = this.config.get('PUBLIC_WEB_URL') || 'http://localhost:5173';
        const token = (0, crypto_1.randomBytes)(16).toString('hex');
        const signature = this.signTracking(token);
        const url = `${publicWebUrl}/t/${token}?s=${signature}`;
        await this.prisma.order.update({
            where: { id: orderId },
            data: {
                trackingToken: token,
                trackingTokenSetAt: new Date(),
                trackingTokenExpiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
                trackingTokenRevokedAt: null,
                trackingUrl: url,
            },
        });
        this.logger.log(`Tracking link generated for order ${orderId}`);
        return { token, signature, url };
    }
    async revokeTrackingToken(orderId) {
        await this.prisma.order.update({
            where: { id: orderId },
            data: { trackingTokenRevokedAt: new Date() },
        });
        return { message: 'Tracking link revoked' };
    }
    async getPublicInfo(trackingNumber, signature) {
        if (!this.verifySignature(trackingNumber, signature, 'qr')) {
            throw new common_1.BadRequestException('Invalid QR signature');
        }
        const order = await this.prisma.order.findUnique({
            where: { trackingNumber },
            select: {
                id: true,
                trackingNumber: true,
                status: true,
                senderName: true,
                receiverName: true,
                receiverPhone: true,
                totalWeightKg: true,
                isFragile: true,
                isRefrigerated: true,
                originBranch: { select: { name: true, code: true } },
                destBranch: { select: { name: true, code: true } },
                items: {
                    select: {
                        description: true,
                        quantity: true,
                        weightKg: true,
                        isFragile: true,
                    },
                },
            },
        });
        if (!order)
            throw new common_1.BadRequestException('Order not found');
        return {
            trackingNumber: order.trackingNumber,
            status: order.status,
            origin: order.originBranch
                ? { branch: order.originBranch.name, code: order.originBranch.code }
                : null,
            destination: order.destBranch
                ? { branch: order.destBranch.name, code: order.destBranch.code }
                : null,
            receiver: {
                name: this.maskName(order.receiverName),
                phoneMasked: this.maskPhone(order.receiverPhone),
            },
            package: {
                weightKg: order.totalWeightKg,
                isFragile: order.isFragile,
                isRefrigerated: order.isRefrigerated,
                itemCount: order.items.length,
            },
            items: order.items.map((it) => ({
                description: it.description,
                quantity: it.quantity,
                weightKg: it.weightKg,
                isFragile: it.isFragile,
            })),
            signature: signature,
            checkedAt: new Date().toISOString(),
        };
    }
    maskName(name) {
        if (!name)
            return 'Unknown';
        const parts = name.trim().split(/\s+/);
        return parts.map((p, i) => (i === 0 ? p : p[0] + '.')).join(' ');
    }
    maskPhone(phone) {
        if (!phone || phone.length < 8)
            return '****';
        return phone.slice(0, 5) + '****' + phone.slice(-4);
    }
};
exports.QrService = QrService;
exports.QrService = QrService = QrService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService,
        prisma_service_1.PrismaService])
], QrService);
//# sourceMappingURL=qr.service.js.map