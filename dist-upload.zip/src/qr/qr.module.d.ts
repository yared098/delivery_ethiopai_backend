export declare class QrModule {
}
