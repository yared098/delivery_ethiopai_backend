"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QrController = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const ioredis_1 = require("ioredis");
const qr_service_1 = require("./qr.service");
const public_decorator_1 = require("../common/decorators/public.decorator");
let QrController = class QrController {
    constructor(qr, config) {
        this.qr = qr;
        this.config = config;
        this.redis = new ioredis_1.Redis(this.config.get('REDIS_URL'));
    }
    onModuleDestroy() {
        this.redis.disconnect();
    }
    async scan(trackingNumber, signature, req) {
        if (!signature) {
            throw new common_1.HttpException('Missing signature', common_1.HttpStatus.BAD_REQUEST);
        }
        const key = `qr:rate:${req.ip}`;
        const count = await this.redis.incr(key);
        if (count === 1)
            await this.redis.expire(key, 60);
        if (count > 30) {
            throw new common_1.HttpException('Too many requests', common_1.HttpStatus.TOO_MANY_REQUESTS);
        }
        return this.qr.getPublicInfo(trackingNumber, signature);
    }
};
exports.QrController = QrController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)(':trackingNumber'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Param)('trackingNumber')),
    __param(1, (0, common_1.Query)('s')),
    __param(2, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], QrController.prototype, "scan", null);
exports.QrController = QrController = __decorate([
    (0, common_1.Controller)('public/qr'),
    __metadata("design:paramtypes", [qr_service_1.QrService,
        config_1.ConfigService])
], QrController);
//# sourceMappingURL=qr.controller.js.map