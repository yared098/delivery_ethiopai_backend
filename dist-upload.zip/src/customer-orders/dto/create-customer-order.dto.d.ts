import { ItemType, PaymentParty } from '@prisma/client';
declare class SenderDto {
    name: string;
    phone: string;
    address?: string;
    lat?: number;
    lng?: number;
}
declare class ReceiverDto {
    name?: string;
    phone: string;
    address?: string;
    lat?: number;
    lng?: number;
}
declare class ItemDto {
    type?: ItemType;
    description: string;
    weightKg: number;
    quantity?: number;
    isFragile?: boolean;
    isRefrigerated?: boolean;
    declaredValue?: number;
}
export declare class CreateCustomerOrderDto {
    sender: SenderDto;
    receiver: ReceiverDto;
    items: ItemDto[];
    originBranchId?: string;
    destBranchId?: string;
    packageDescription?: string;
    paymentParty?: PaymentParty;
    codAmount?: number;
    sendReceiverLink?: boolean;
}
export {};
