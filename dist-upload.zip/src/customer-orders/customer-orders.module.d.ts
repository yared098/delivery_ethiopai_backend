export declare class CustomerOrdersModule {
}
