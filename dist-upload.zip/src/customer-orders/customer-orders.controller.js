"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomerOrdersController = void 0;
const common_1 = require("@nestjs/common");
const customer_jwt_guard_1 = require("../common/guards/customer-jwt.guard");
const current_customer_decorator_1 = require("../common/decorators/current-customer.decorator");
const orders_service_1 = require("../orders/orders.service");
const prisma_service_1 = require("../prisma/prisma.service");
const create_customer_order_dto_1 = require("./dto/create-customer-order.dto");
const client_1 = require("@prisma/client");
let CustomerOrdersController = class CustomerOrdersController {
    constructor(orders, prisma) {
        this.orders = orders;
        this.prisma = prisma;
    }
    async create(dto, customer) {
        const actor = {
            id: customer.id,
            name: customer.name || 'Customer',
            accountType: client_1.AccountType.CUSTOMER,
            role: 'CUSTOMER',
        };
        return this.orders.create({
            ...dto,
            sender: {
                ...dto.sender,
                customerId: customer.id,
            },
        }, actor);
    }
    async list(customer, type = 'all', page = '1', limit = '20') {
        const skip = (Number(page) - 1) * Number(limit);
        const take = Number(limit);
        const where = {};
        if (type === 'sent')
            where.senderId = customer.id;
        else if (type === 'received')
            where.receiverId = customer.id;
        else
            where.OR = [
                { senderId: customer.id },
                { receiverId: customer.id },
            ];
        const [data, total] = await Promise.all([
            this.prisma.order.findMany({
                where,
                include: {
                    items: true,
                    sender: { select: { id: true, name: true, phone: true } },
                    receiver: { select: { id: true, name: true, phone: true } },
                    courier: { select: { id: true, name: true, phone: true } },
                },
                orderBy: { createdAt: 'desc' },
                skip,
                take,
            }),
            this.prisma.order.count({ where }),
        ]);
        return {
            data,
            total,
            page: Number(page),
            limit: take,
            pages: Math.ceil(total / take),
        };
    }
    async detail(id, customer) {
        const order = await this.prisma.order.findFirst({
            where: {
                id,
                OR: [
                    { senderId: customer.id },
                    { receiverId: customer.id },
                ],
            },
            include: {
                items: true,
                sender: { select: { id: true, name: true, phone: true } },
                receiver: { select: { id: true, name: true, phone: true } },
                courier: {
                    select: {
                        id: true,
                        name: true,
                        phone: true,
                        vehicleType: true,
                        vehiclePlate: true,
                        currentLat: true,
                        currentLng: true,
                    },
                },
                events: {
                    where: { isPublic: true },
                    orderBy: { createdAt: 'desc' },
                    take: 20,
                },
            },
        });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        return order;
    }
};
exports.CustomerOrdersController = CustomerOrdersController;
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_customer_decorator_1.CurrentCustomer)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_customer_order_dto_1.CreateCustomerOrderDto, Object]),
    __metadata("design:returntype", Promise)
], CustomerOrdersController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, current_customer_decorator_1.CurrentCustomer)()),
    __param(1, (0, common_1.Query)('type')),
    __param(2, (0, common_1.Query)('page')),
    __param(3, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object, Object]),
    __metadata("design:returntype", Promise)
], CustomerOrdersController.prototype, "list", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_customer_decorator_1.CurrentCustomer)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], CustomerOrdersController.prototype, "detail", null);
exports.CustomerOrdersController = CustomerOrdersController = __decorate([
    (0, common_1.Controller)('customer/orders'),
    (0, common_1.UseGuards)(customer_jwt_guard_1.CustomerJwtGuard),
    __metadata("design:paramtypes", [orders_service_1.OrdersService,
        prisma_service_1.PrismaService])
], CustomerOrdersController);
//# sourceMappingURL=customer-orders.controller.js.map