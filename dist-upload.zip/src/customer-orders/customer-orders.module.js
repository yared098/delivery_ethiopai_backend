"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomerOrdersModule = void 0;
const common_1 = require("@nestjs/common");
const customer_orders_controller_1 = require("./customer-orders.controller");
const prisma_module_1 = require("../prisma/prisma.module");
const orders_module_1 = require("../orders/orders.module");
let CustomerOrdersModule = class CustomerOrdersModule {
};
exports.CustomerOrdersModule = CustomerOrdersModule;
exports.CustomerOrdersModule = CustomerOrdersModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule, orders_module_1.OrdersModule],
        controllers: [customer_orders_controller_1.CustomerOrdersController],
    })
], CustomerOrdersModule);
//# sourceMappingURL=customer-orders.module.js.map