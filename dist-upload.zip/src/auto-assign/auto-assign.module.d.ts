export declare class AutoAssignModule {
}
