"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoAssignController = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const courier_jwt_guard_1 = require("../common/guards/courier-jwt.guard");
const current_courier_decorator_1 = require("../common/decorators/current-courier.decorator");
const auto_assign_service_1 = require("./auto-assign.service");
class RejectDto {
}
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], RejectDto.prototype, "reason", void 0);
let AutoAssignController = class AutoAssignController {
    constructor(service) {
        this.service = service;
    }
    accept(orderId, courierId) {
        return this.service.acceptOffer(orderId, courierId);
    }
    reject(orderId, courierId, body) {
        return this.service.rejectOffer(orderId, courierId, body.reason);
    }
};
exports.AutoAssignController = AutoAssignController;
__decorate([
    (0, common_1.Post)(':orderId/accept'),
    (0, common_1.UseGuards)(courier_jwt_guard_1.CourierJwtGuard),
    __param(0, (0, common_1.Param)('orderId')),
    __param(1, (0, current_courier_decorator_1.CurrentCourier)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", void 0)
], AutoAssignController.prototype, "accept", null);
__decorate([
    (0, common_1.Post)(':orderId/reject'),
    (0, common_1.UseGuards)(courier_jwt_guard_1.CourierJwtGuard),
    __param(0, (0, common_1.Param)('orderId')),
    __param(1, (0, current_courier_decorator_1.CurrentCourier)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, RejectDto]),
    __metadata("design:returntype", void 0)
], AutoAssignController.prototype, "reject", null);
exports.AutoAssignController = AutoAssignController = __decorate([
    (0, common_1.Controller)('auto-assign'),
    __metadata("design:paramtypes", [auto_assign_service_1.AutoAssignService])
], AutoAssignController);
//# sourceMappingURL=auto-assign.controller.js.map