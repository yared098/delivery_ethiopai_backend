import { PrismaService } from '../prisma/prisma.service';
import { TrackingGateway } from '../tracking/tracking.gateway';
import { NotificationsService } from '../notifications/notifications.service';
import { OfferStoreService } from './offer-store.service';
export declare class AutoAssignService {
    private prisma;
    private gateway;
    private notifications;
    private offerStore;
    private readonly logger;
    constructor(prisma: PrismaService, gateway: TrackingGateway, notifications: NotificationsService, offerStore: OfferStoreService);
    tryAutoAssign(orderId: string): Promise<void>;
    private findCandidates;
    private sendOffer;
    acceptOffer(orderId: string, courierId: string): Promise<{
        success: boolean;
    }>;
    rejectOffer(orderId: string, courierId: string, reason?: string): Promise<{
        success: boolean;
    }>;
    private handleOfferTimeout;
    private escalateToManual;
    detectNoShows(): Promise<void>;
}
