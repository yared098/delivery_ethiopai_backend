"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoAssignModule = void 0;
const common_1 = require("@nestjs/common");
const auto_assign_service_1 = require("./auto-assign.service");
const auto_assign_controller_1 = require("./auto-assign.controller");
const auto_assign_cron_1 = require("./auto-assign.cron");
const offer_store_service_1 = require("./offer-store.service");
const prisma_module_1 = require("../prisma/prisma.module");
const tracking_module_1 = require("../tracking/tracking.module");
const notifications_module_1 = require("../notifications/notifications.module");
let AutoAssignModule = class AutoAssignModule {
};
exports.AutoAssignModule = AutoAssignModule;
exports.AutoAssignModule = AutoAssignModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule, tracking_module_1.TrackingModule, notifications_module_1.NotificationsModule],
        controllers: [auto_assign_controller_1.AutoAssignController],
        providers: [auto_assign_service_1.AutoAssignService, offer_store_service_1.OfferStoreService, auto_assign_cron_1.AutoAssignCron],
        exports: [auto_assign_service_1.AutoAssignService],
    })
], AutoAssignModule);
//# sourceMappingURL=auto-assign.module.js.map