import { AutoAssignService } from './auto-assign.service';
declare class RejectDto {
    reason?: string;
}
export declare class AutoAssignController {
    private readonly service;
    constructor(service: AutoAssignService);
    accept(orderId: string, courierId: string): Promise<{
        success: boolean;
    }>;
    reject(orderId: string, courierId: string, body: RejectDto): Promise<{
        success: boolean;
    }>;
}
export {};
