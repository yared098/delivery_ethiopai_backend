"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AutoAssignService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoAssignService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const tracking_gateway_1 = require("../tracking/tracking.gateway");
const notifications_service_1 = require("../notifications/notifications.service");
const offer_store_service_1 = require("./offer-store.service");
const route_utils_1 = require("./route-utils");
const STALE_LOCATION_MIN = 50;
const NO_SHOW_MINUTES = 15;
let AutoAssignService = AutoAssignService_1 = class AutoAssignService {
    constructor(prisma, gateway, notifications, offerStore) {
        this.prisma = prisma;
        this.gateway = gateway;
        this.notifications = notifications;
        this.offerStore = offerStore;
        this.logger = new common_1.Logger(AutoAssignService_1.name);
    }
    async tryAutoAssign(orderId) {
        const order = await this.prisma.order.findUnique({
            where: { id: orderId },
            include: { originBranch: true, destBranch: true },
        });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        if (order.status !== 'PAID' || order.courierId) {
            this.logger.debug(`Skipping ${orderId} — status: ${order.status}`);
            return;
        }
        const route = (0, route_utils_1.analyzeRoute)(order);
        const config = (0, route_utils_1.getOfferConfig)(route.category);
        await this.prisma.order.update({
            where: { id: orderId },
            data: {
                routeCategory: route.category,
                routeDistanceKm: route.distanceKm,
            },
        });
        const attempts = await this.offerStore.getAttempts(orderId);
        if (attempts >= config.maxRetries) {
            await this.escalateToManual(orderId, `Max retries (${config.maxRetries}) reached`);
            return;
        }
        const candidates = await this.findCandidates(order, route);
        if (candidates.length === 0) {
            await this.escalateToManual(orderId, 'No eligible couriers');
            return;
        }
        const top = candidates.slice(0, config.broadcastSize);
        const attemptNo = await this.offerStore.incrementAttempt(orderId);
        await this.prisma.orderOffer.createMany({
            data: top.map((c) => ({
                orderId,
                courierId: c.id,
                attemptNo,
                expiresAt: new Date(Date.now() + config.timeoutMs),
                pickupKm: c.pickupDistanceKm,
                routeKm: route.distanceKm,
                status: 'PENDING',
            })),
            skipDuplicates: true,
        });
        await this.offerStore.saveOfferedCouriers(orderId, top.map((c) => c.id));
        await this.prisma.order.update({
            where: { id: orderId },
            data: {
                autoAssignAttempts: attemptNo,
                lastOfferedAt: new Date(),
            },
        });
        for (const courier of top) {
            await this.sendOffer(order, courier, route, config.timeoutMs);
        }
        this.logger.log(`Order ${order.trackingNumber} → offered to ${top.length} couriers (attempt ${attemptNo})`);
        setTimeout(() => this.handleOfferTimeout(orderId).catch((e) => this.logger.error('Timeout handler failed', e)), config.timeoutMs);
    }
    async findCandidates(order, route) {
        this.logger.debug(`🔍 findCandidates for order ${order.trackingNumber}: ` +
            `routeType=${route.type}, originRegion=${route.originRegionId}, ` +
            `deliveryRegion=${route.deliveryRegionId}, distance=${route.distanceKm}km, ` +
            `vehicles=[${route.eligibleVehicles.join(',')}]`);
        if (!route.originRegionId) {
            this.logger.warn(`❌ Order ${order.trackingNumber} has NO originRegionId — ` +
                `check originBranchId on the order`);
            return [];
        }
        const staleCutoff = new Date(Date.now() - STALE_LOCATION_MIN * 60_000);
        const baseFilter = {
            isOnline: true,
            isActive: true,
            status: 'APPROVED',
            vehicleType: { in: route.eligibleVehicles },
            currentLat: { not: null },
            currentLng: { not: null },
            lastSeenAt: { gte: staleCutoff },
            isOnLongTrip: false,
        };
        if (order.totalWeightKg > 0) {
            baseFilter.OR = [
                { maxWeightKg: null },
                { maxWeightKg: { gte: order.totalWeightKg } },
            ];
        }
        if (order.isFragile)
            baseFilter.handlesFragile = true;
        if (order.isRefrigerated)
            baseFilter.handlesRefrigerated = true;
        let regionFilter;
        if (route.type === 'INTRA_REGION') {
            regionFilter = { regionId: route.originRegionId };
        }
        else if (route.type === 'INTER_REGION') {
            regionFilter = {
                AND: [
                    {
                        OR: [
                            { regionId: route.originRegionId },
                            { serviceRegionIds: { has: route.originRegionId } },
                        ],
                    },
                    {
                        OR: [
                            { regionId: route.deliveryRegionId },
                            { serviceRegionIds: { has: route.deliveryRegionId } },
                        ],
                    },
                ],
            };
        }
        else {
            this.logger.warn(`❌ Order ${order.trackingNumber} route.type=${route.type} — ` +
                `cannot match couriers`);
            return [];
        }
        const couriers = await this.prisma.courier.findMany({
            where: { ...baseFilter, ...regionFilter },
            select: {
                id: true,
                name: true,
                phone: true,
                currentLat: true,
                currentLng: true,
                rating: true,
                totalDeliveries: true,
                maxWeightKg: true,
                vehicleType: true,
                acceptsReturnTrip: true,
            },
        });
        this.logger.debug(`🔍 Base filter matched ${couriers.length} courier(s)`);
        if (couriers.length === 0) {
            const totalApproved = await this.prisma.courier.count({
                where: { status: 'APPROVED' },
            });
            const online = await this.prisma.courier.count({
                where: { status: 'APPROVED', isOnline: true },
            });
            const withGps = await this.prisma.courier.count({
                where: {
                    status: 'APPROVED',
                    isOnline: true,
                    currentLat: { not: null },
                    currentLng: { not: null },
                },
            });
            const freshGps = await this.prisma.courier.count({
                where: {
                    status: 'APPROVED',
                    isOnline: true,
                    currentLat: { not: null },
                    currentLng: { not: null },
                    lastSeenAt: { gte: staleCutoff },
                },
            });
            this.logger.warn(`⚠️ No couriers matched. Funnel: ` +
                `approved=${totalApproved} → online=${online} → ` +
                `withGps=${withGps} → freshGps=${freshGps}`);
            return [];
        }
        const courierIds = couriers.map((c) => c.id);
        const activeCounts = await this.prisma.order.groupBy({
            by: ['courierId'],
            where: {
                courierId: { in: courierIds },
                status: {
                    in: ['ASSIGNED', 'PICKED_UP', 'IN_TRANSIT', 'OUT_FOR_DELIVERY'],
                },
            },
            _count: true,
        });
        const activeMap = new Map(activeCounts.map((r) => [r.courierId, r._count]));
        const maxConcurrent = (0, route_utils_1.getMaxConcurrent)(route.category);
        this.logger.debug(`🔍 maxConcurrent=${maxConcurrent}, ` +
            `busy couriers=${activeMap.size}`);
        let filtered = couriers.filter((c) => (activeMap.get(c.id) ?? 0) < maxConcurrent);
        const offeredIds = await this.offerStore.getOfferedCouriers(order.id);
        filtered = filtered.filter((c) => !offeredIds.includes(c.id));
        this.logger.debug(`🔍 After load+offered filter: ${filtered.length} courier(s)`);
        if (filtered.length === 0) {
            this.logger.warn(`⚠️ All candidates busy or already offered. ` +
                `Busy: ${activeMap.size}, Offered: ${offeredIds.length}`);
            return [];
        }
        const pickupLat = order.senderLat ?? 0;
        const pickupLng = order.senderLng ?? 0;
        return filtered
            .map((c) => {
            const pickupDistanceKm = (0, route_utils_1.haversine)(pickupLat, pickupLng, c.currentLat, c.currentLng);
            const distanceWeight = route.type === 'INTRA_REGION' ? 1.0 : 0.3;
            let score = pickupDistanceKm * distanceWeight * 10;
            score += (5 - c.rating) * 5;
            if (route.type === 'INTER_REGION' && c.totalDeliveries > 50)
                score -= 5;
            if (order.requiresReturn && c.acceptsReturnTrip)
                score -= 10;
            if (c.maxWeightKg && order.totalWeightKg > c.maxWeightKg * 0.8)
                score += 15;
            return { ...c, pickupDistanceKm, score };
        })
            .sort((a, b) => a.score - b.score);
    }
    async sendOffer(order, courier, route, timeoutMs) {
        const payload = {
            orderId: order.id,
            trackingNumber: order.trackingNumber,
            category: route.category,
            routeType: route.type,
            pickupDistanceKm: Math.round(courier.pickupDistanceKm * 10) / 10,
            routeDistanceKm: route.distanceKm,
            pickupLat: order.senderLat,
            pickupLng: order.senderLng,
            deliveryLat: order.receiverLat,
            deliveryLng: order.receiverLng,
            weight: order.totalWeightKg,
            isFragile: order.isFragile,
            isRefrigerated: order.isRefrigerated,
            estimatedEarning: order.courierEarning,
            expiresAt: new Date(Date.now() + timeoutMs).toISOString(),
        };
        this.gateway.server
            .to(`courier:${courier.id}`)
            .emit('order:offer', payload);
        await this.notifications.sendToCourier(courier.id, {
            title: 'New delivery nearby 🛵',
            body: `${order.trackingNumber} · ${courier.pickupDistanceKm.toFixed(1)} km away · ${order.courierEarning} ETB`,
            data: {
                type: 'ORDER_OFFER',
                orderId: order.id,
            },
        });
    }
    async acceptOffer(orderId, courierId) {
        const result = await this.prisma.order.updateMany({
            where: {
                id: orderId,
                courierId: null,
                status: 'PAID',
            },
            data: {
                courierId,
                assignedAt: new Date(),
                status: 'ASSIGNED',
                autoUnassignAt: new Date(Date.now() + NO_SHOW_MINUTES * 60_000),
            },
        });
        if (result.count === 0) {
            throw new common_1.ConflictException('Order already assigned to another courier');
        }
        await this.prisma.orderOffer.updateMany({
            where: { orderId, courierId, status: 'PENDING' },
            data: { status: 'ACCEPTED', respondedAt: new Date() },
        });
        await this.prisma.orderEvent.create({
            data: {
                orderId,
                status: 'ASSIGNED',
                note: 'Courier assigned',
                actorType: 'COURIER',
                actorId: courierId,
                isPublic: true,
            },
        });
        const offered = await this.offerStore.getOfferedCouriers(orderId);
        const others = offered.filter((id) => id !== courierId);
        for (const otherId of others) {
            this.gateway.server
                .to(`courier:${otherId}`)
                .emit('order:offer-cancelled', { orderId });
        }
        await this.prisma.orderOffer.updateMany({
            where: {
                orderId,
                courierId: { in: others },
                status: 'PENDING',
            },
            data: { status: 'CANCELLED', respondedAt: new Date() },
        });
        await this.offerStore.clearOffers(orderId);
        const order = await this.prisma.order.findUnique({
            where: { id: orderId },
        });
        if (order) {
            this.gateway.emitStatus(order.trackingNumber, 'ASSIGNED');
            await this.notifications.notifyOrderStatus(order);
        }
        this.logger.log(`Order ${orderId} assigned to courier ${courierId}`);
        return { success: true };
    }
    async rejectOffer(orderId, courierId, reason) {
        await this.prisma.orderOffer.updateMany({
            where: { orderId, courierId, status: 'PENDING' },
            data: {
                status: 'REJECTED',
                respondedAt: new Date(),
                rejectionReason: reason,
            },
        });
        const pending = await this.prisma.orderOffer.count({
            where: { orderId, status: 'PENDING' },
        });
        if (pending === 0) {
            this.logger.log(`All offers rejected for ${orderId}, retrying`);
            setTimeout(() => this.tryAutoAssign(orderId).catch(() => { }), 2000);
        }
        return { success: true };
    }
    async handleOfferTimeout(orderId) {
        const order = await this.prisma.order.findUnique({ where: { id: orderId } });
        if (!order || order.courierId)
            return;
        if (order.status !== 'PAID')
            return;
        this.logger.log(`Offer timeout for ${order.trackingNumber}`);
        await this.prisma.orderOffer.updateMany({
            where: { orderId, status: 'PENDING' },
            data: { status: 'EXPIRED', respondedAt: new Date() },
        });
        await this.offerStore.clearOffers(orderId);
        await this.tryAutoAssign(orderId);
    }
    async escalateToManual(orderId, reason) {
        const order = await this.prisma.order.findUnique({ where: { id: orderId } });
        if (!order)
            return;
        this.logger.warn(`Order ${order.trackingNumber} → MANUAL: ${reason}`);
        await this.prisma.orderEvent.create({
            data: {
                orderId,
                status: 'PAID',
                note: `Auto-assign failed: ${reason}`,
                isPublic: false,
            },
        });
        await this.notifications.broadcastToStaff({
            title: '⚠️ Order needs manual assignment',
            body: `${order.trackingNumber} — ${reason}`,
            data: { orderId, type: 'ORDER_MANUAL_ASSIGN_NEEDED' },
        });
    }
    async detectNoShows() {
        const now = new Date();
        const stale = await this.prisma.order.findMany({
            where: {
                status: 'ASSIGNED',
                autoUnassignAt: { lte: now },
                pickedUpAt: null,
            },
        });
        for (const order of stale) {
            this.logger.warn(`No-show detected: ${order.trackingNumber}`);
            await this.prisma.order.update({
                where: { id: order.id },
                data: {
                    courierId: null,
                    status: 'PAID',
                    assignedAt: null,
                    autoUnassignAt: null,
                    unassignReason: 'Courier did not pick up within 15 min',
                },
            });
            await this.offerStore.clearOffers(order.id);
            await this.tryAutoAssign(order.id);
        }
    }
};
exports.AutoAssignService = AutoAssignService;
exports.AutoAssignService = AutoAssignService = AutoAssignService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        tracking_gateway_1.TrackingGateway,
        notifications_service_1.NotificationsService,
        offer_store_service_1.OfferStoreService])
], AutoAssignService);
//# sourceMappingURL=auto-assign.service.js.map