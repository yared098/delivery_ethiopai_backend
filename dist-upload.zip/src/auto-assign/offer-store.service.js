"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var OfferStoreService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OfferStoreService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const ioredis_1 = require("ioredis");
let OfferStoreService = OfferStoreService_1 = class OfferStoreService {
    constructor(config) {
        this.logger = new common_1.Logger(OfferStoreService_1.name);
        this.TTL_SECONDS = 30 * 60;
        this.redis = new ioredis_1.Redis(config.get('REDIS_URL'));
    }
    async saveOfferedCouriers(orderId, courierIds) {
        const key = `offered:${orderId}`;
        if (courierIds.length === 0)
            return;
        await this.redis.sadd(key, ...courierIds);
        await this.redis.expire(key, this.TTL_SECONDS);
    }
    async getOfferedCouriers(orderId) {
        return this.redis.smembers(`offered:${orderId}`);
    }
    async wasCourierOffered(orderId, courierId) {
        return (await this.redis.sismember(`offered:${orderId}`, courierId)) === 1;
    }
    async clearOffers(orderId) {
        await this.redis.del(`offered:${orderId}`);
    }
    async incrementAttempt(orderId) {
        const key = `attempts:${orderId}`;
        const count = await this.redis.incr(key);
        if (count === 1)
            await this.redis.expire(key, this.TTL_SECONDS);
        return count;
    }
    async getAttempts(orderId) {
        const val = await this.redis.get(`attempts:${orderId}`);
        return val ? parseInt(val, 10) : 0;
    }
    async clearAttempts(orderId) {
        await this.redis.del(`attempts:${orderId}`);
    }
    async onModuleDestroy() {
        await this.redis.quit();
    }
};
exports.OfferStoreService = OfferStoreService;
exports.OfferStoreService = OfferStoreService = OfferStoreService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], OfferStoreService);
//# sourceMappingURL=offer-store.service.js.map