import { ConfigService } from '@nestjs/config';
export declare class OfferStoreService {
    private readonly logger;
    private redis;
    private readonly TTL_SECONDS;
    constructor(config: ConfigService);
    saveOfferedCouriers(orderId: string, courierIds: string[]): Promise<void>;
    getOfferedCouriers(orderId: string): Promise<string[]>;
    wasCourierOffered(orderId: string, courierId: string): Promise<boolean>;
    clearOffers(orderId: string): Promise<void>;
    incrementAttempt(orderId: string): Promise<number>;
    getAttempts(orderId: string): Promise<number>;
    clearAttempts(orderId: string): Promise<void>;
    onModuleDestroy(): Promise<void>;
}
