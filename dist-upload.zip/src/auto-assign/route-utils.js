"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.analyzeRoute = analyzeRoute;
exports.getRouteCategory = getRouteCategory;
exports.getEligibleVehicles = getEligibleVehicles;
exports.getOfferConfig = getOfferConfig;
exports.getMaxConcurrent = getMaxConcurrent;
exports.haversine = haversine;
function analyzeRoute(order) {
    const originRegionId = order.originBranch?.regionId ?? null;
    const deliveryRegionId = order.destBranch?.regionId ?? null;
    let type = 'UNKNOWN';
    if (originRegionId && deliveryRegionId) {
        type =
            originRegionId === deliveryRegionId ? 'INTRA_REGION' : 'INTER_REGION';
    }
    const distanceKm = order.distanceKm ?? order.routeDistanceKm ?? 0;
    const eligibleVehicles = getEligibleVehicles(distanceKm, order.totalWeightKg);
    const category = getRouteCategory(distanceKm);
    return {
        type,
        originRegionId,
        deliveryRegionId,
        distanceKm,
        eligibleVehicles,
        category,
    };
}
function getRouteCategory(distanceKm) {
    if (distanceKm <= 5)
        return 'MICRO';
    if (distanceKm <= 15)
        return 'INTRA_CITY';
    if (distanceKm <= 100)
        return 'SHORT_HAUL';
    if (distanceKm <= 500)
        return 'INTER_CITY';
    return 'LONG_HAUL';
}
function getEligibleVehicles(distanceKm, weightKg) {
    const byDistance = [];
    if (distanceKm <= 5)
        byDistance.push('BICYCLE', 'MOTORCYCLE', 'CAR');
    else if (distanceKm <= 15)
        byDistance.push('MOTORCYCLE', 'CAR', 'VAN');
    else if (distanceKm <= 100)
        byDistance.push('CAR', 'VAN', 'TRUCK');
    else if (distanceKm <= 500)
        byDistance.push('VAN', 'TRUCK');
    else
        byDistance.push('TRUCK');
    const byWeight = [];
    if (weightKg <= 5)
        byWeight.push('BICYCLE');
    if (weightKg <= 20)
        byWeight.push('MOTORCYCLE');
    if (weightKg <= 100)
        byWeight.push('CAR');
    if (weightKg <= 500)
        byWeight.push('VAN');
    byWeight.push('TRUCK');
    return byDistance.filter((v) => byWeight.includes(v));
}
function getOfferConfig(category) {
    switch (category) {
        case 'MICRO':
            return { broadcastSize: 3, timeoutMs: 20_000, maxRetries: 2 };
        case 'INTRA_CITY':
            return { broadcastSize: 3, timeoutMs: 30_000, maxRetries: 2 };
        case 'SHORT_HAUL':
            return { broadcastSize: 5, timeoutMs: 2 * 60_000, maxRetries: 2 };
        case 'INTER_CITY':
            return { broadcastSize: 5, timeoutMs: 5 * 60_000, maxRetries: 1 };
        case 'LONG_HAUL':
            return { broadcastSize: 10, timeoutMs: 15 * 60_000, maxRetries: 1 };
        default:
            return { broadcastSize: 3, timeoutMs: 30_000, maxRetries: 2 };
    }
}
function getMaxConcurrent(category) {
    switch (category) {
        case 'MICRO':
            return 5;
        case 'INTRA_CITY':
            return 3;
        case 'SHORT_HAUL':
            return 2;
        case 'INTER_CITY':
            return 1;
        case 'LONG_HAUL':
            return 1;
        default:
            return 3;
    }
}
function haversine(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a = Math.sin(dLat / 2) ** 2 +
        Math.cos((lat1 * Math.PI) / 180) *
            Math.cos((lat2 * Math.PI) / 180) *
            Math.sin(dLon / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
//# sourceMappingURL=route-utils.js.map