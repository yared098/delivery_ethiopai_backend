import { Branch, Order, VehicleType } from '@prisma/client';
export type RouteType = 'INTRA_REGION' | 'INTER_REGION' | 'UNKNOWN';
export interface RouteInfo {
    type: RouteType;
    originRegionId: string | null;
    deliveryRegionId: string | null;
    distanceKm: number;
    eligibleVehicles: VehicleType[];
    category: 'MICRO' | 'INTRA_CITY' | 'SHORT_HAUL' | 'INTER_CITY' | 'LONG_HAUL';
}
export declare function analyzeRoute(order: Order & {
    originBranch: Branch | null;
    destBranch: Branch | null;
}): RouteInfo;
export declare function getRouteCategory(distanceKm: number): "MICRO" | "INTRA_CITY" | "SHORT_HAUL" | "INTER_CITY" | "LONG_HAUL";
export declare function getEligibleVehicles(distanceKm: number, weightKg: number): VehicleType[];
export declare function getOfferConfig(category: string): {
    broadcastSize: number;
    timeoutMs: number;
    maxRetries: number;
};
export declare function getMaxConcurrent(category: string): number;
export declare function haversine(lat1: number, lon1: number, lat2: number, lon2: number): number;
