"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var AutoAssignCron_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoAssignCron = void 0;
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const auto_assign_service_1 = require("./auto-assign.service");
let AutoAssignCron = AutoAssignCron_1 = class AutoAssignCron {
    constructor(service) {
        this.service = service;
        this.logger = new common_1.Logger(AutoAssignCron_1.name);
    }
    async handleNoShows() {
        try {
            await this.service.detectNoShows();
        }
        catch (e) {
            this.logger.error('No-show cron failed', e);
        }
    }
};
exports.AutoAssignCron = AutoAssignCron;
__decorate([
    (0, schedule_1.Cron)('0 */2 * * * *'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AutoAssignCron.prototype, "handleNoShows", null);
exports.AutoAssignCron = AutoAssignCron = AutoAssignCron_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [auto_assign_service_1.AutoAssignService])
], AutoAssignCron);
//# sourceMappingURL=auto-assign.cron.js.map