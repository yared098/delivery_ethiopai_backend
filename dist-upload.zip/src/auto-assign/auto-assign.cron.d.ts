import { AutoAssignService } from './auto-assign.service';
export declare class AutoAssignCron {
    private readonly service;
    private readonly logger;
    constructor(service: AutoAssignService);
    handleNoShows(): Promise<void>;
}
