"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const core_1 = require("@nestjs/core");
const prisma_module_1 = require("./prisma/prisma.module");
const afromessage_module_1 = require("./integrations/afromessage/afromessage.module");
const staff_module_1 = require("./staff/staff.module");
const auth_module_1 = require("./auth/auth.module");
const regions_module_1 = require("./regions/regions.module");
const branches_module_1 = require("./branches/branches.module");
const admin_module_1 = require("./admin/admin.module");
const couriers_module_1 = require("./couriers/couriers.module");
const customers_module_1 = require("./customers/customers.module");
const orders_module_1 = require("./orders/orders.module");
const tracking_module_1 = require("./tracking/tracking.module");
const qr_module_1 = require("./qr/qr.module");
const uploads_module_1 = require("./uploads/uploads.module");
const payment_providers_module_1 = require("./payment-providers/payment-providers.module");
const customer_orders_module_1 = require("./customer-orders/customer-orders.module");
const public_tracking_module_1 = require("./public-tracking/public-tracking.module");
const jwt_auth_guard_1 = require("./common/guards/jwt-auth.guard");
const notifications_module_1 = require("./notifications/notifications.module");
const courier_app_module_1 = require("./courier-app/courier-app.module");
const payments_module_1 = require("./payments/payments.module");
const telegram_module_1 = require("./telegram/telegram.module");
const telegram_bot_module_1 = require("./telegram/bot/telegram-bot.module");
const telegram_webapp_module_1 = require("./telegram/webapp/telegram-webapp.module");
const auto_assign_module_1 = require("./auto-assign/auto-assign.module");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({ isGlobal: true }),
            prisma_module_1.PrismaModule,
            afromessage_module_1.AfroMessageModule,
            staff_module_1.StaffModule,
            auth_module_1.AuthModule,
            regions_module_1.RegionsModule,
            branches_module_1.BranchesModule,
            admin_module_1.AdminModule,
            couriers_module_1.CouriersModule,
            customers_module_1.CustomersModule,
            orders_module_1.OrdersModule,
            tracking_module_1.TrackingModule,
            qr_module_1.QrModule,
            uploads_module_1.UploadsModule,
            payment_providers_module_1.PaymentProvidersModule,
            customer_orders_module_1.CustomerOrdersModule,
            public_tracking_module_1.PublicTrackingModule,
            notifications_module_1.NotificationsModule,
            courier_app_module_1.CourierAppModule,
            payments_module_1.PaymentsModule,
            auto_assign_module_1.AutoAssignModule,
            telegram_module_1.TelegramModule,
            telegram_bot_module_1.TelegramBotModule,
            telegram_webapp_module_1.TelegramWebAppModule,
        ],
        providers: [{ provide: core_1.APP_GUARD, useClass: jwt_auth_guard_1.JwtAuthGuard }],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map