import { PrismaService } from '../prisma/prisma.service';
import { CreateBranchDto } from './dto/create-branch.dto';
import { UpdateBranchDto } from './dto/update-branch.dto';
export declare class BranchesService {
    private prisma;
    constructor(prisma: PrismaService);
    create(dto: CreateBranchDto, user: any): Promise<{
        region: {
            id: string;
            code: string;
            name: string;
        };
    } & {
        id: string;
        code: string;
        name: string;
        createdById: string | null;
        createdAt: Date;
        updatedAt: Date;
        phone: string | null;
        regionId: string;
        isActive: boolean;
        city: string | null;
        woreda: string | null;
        address: string | null;
        lat: number | null;
        lng: number | null;
    }>;
    findAll(regionId: string | undefined, user: any): Promise<({
        _count: {
            staff: number;
            couriers: number;
        };
        region: {
            id: string;
            code: string;
            name: string;
        };
    } & {
        id: string;
        code: string;
        name: string;
        createdById: string | null;
        createdAt: Date;
        updatedAt: Date;
        phone: string | null;
        regionId: string;
        isActive: boolean;
        city: string | null;
        woreda: string | null;
        address: string | null;
        lat: number | null;
        lng: number | null;
    })[]>;
    findOne(id: string, user: any): Promise<{
        _count: {
            staff: number;
            couriers: number;
        };
        region: {
            id: string;
            code: string;
            name: string;
        };
    } & {
        id: string;
        code: string;
        name: string;
        createdById: string | null;
        createdAt: Date;
        updatedAt: Date;
        phone: string | null;
        regionId: string;
        isActive: boolean;
        city: string | null;
        woreda: string | null;
        address: string | null;
        lat: number | null;
        lng: number | null;
    }>;
    update(id: string, dto: UpdateBranchDto, user: any): Promise<{
        region: {
            id: string;
            code: string;
            name: string;
        };
    } & {
        id: string;
        code: string;
        name: string;
        createdById: string | null;
        createdAt: Date;
        updatedAt: Date;
        phone: string | null;
        regionId: string;
        isActive: boolean;
        city: string | null;
        woreda: string | null;
        address: string | null;
        lat: number | null;
        lng: number | null;
    }>;
    remove(id: string, user: any): Promise<{
        message: string;
    }>;
}
