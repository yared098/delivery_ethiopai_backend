"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BranchesService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const client_1 = require("@prisma/client");
let BranchesService = class BranchesService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(dto, user) {
        const region = await this.prisma.region.findUnique({
            where: { id: dto.regionId },
        });
        if (!region)
            throw new common_1.NotFoundException('Region not found');
        if (user.role === client_1.StaffRole.REGIONAL_ADMIN && user.regionId !== dto.regionId) {
            throw new common_1.BadRequestException('You can only create branches in your region');
        }
        const nameExists = await this.prisma.branch.findFirst({
            where: { regionId: dto.regionId, name: dto.name },
        });
        if (nameExists) {
            throw new common_1.ConflictException('Branch with this name already exists in the region');
        }
        const codeExists = await this.prisma.branch.findUnique({
            where: { code: dto.code },
        });
        if (codeExists) {
            throw new common_1.ConflictException('Branch with this code already exists');
        }
        return this.prisma.branch.create({
            data: {
                regionId: dto.regionId,
                name: dto.name,
                code: dto.code,
                city: dto.city,
                woreda: dto.woreda,
                address: dto.address,
                phone: dto.phone,
                lat: dto.lat,
                lng: dto.lng,
            },
            include: {
                region: { select: { id: true, name: true, code: true } },
            },
        });
    }
    async findAll(regionId, user) {
        const where = {};
        if (user.role === client_1.StaffRole.REGIONAL_ADMIN) {
            where.regionId = user.regionId;
        }
        else if (regionId) {
            where.regionId = regionId;
        }
        return this.prisma.branch.findMany({
            where,
            orderBy: { name: 'asc' },
            include: {
                region: { select: { id: true, name: true, code: true } },
                _count: { select: { staff: true, couriers: true } },
            },
        });
    }
    async findOne(id, user) {
        const branch = await this.prisma.branch.findUnique({
            where: { id },
            include: {
                region: { select: { id: true, name: true, code: true } },
                _count: { select: { staff: true, couriers: true } },
            },
        });
        if (!branch)
            throw new common_1.NotFoundException('Branch not found');
        if (user.role === client_1.StaffRole.REGIONAL_ADMIN && branch.regionId !== user.regionId) {
            throw new common_1.NotFoundException('Branch not found');
        }
        return branch;
    }
    async update(id, dto, user) {
        const existing = await this.findOne(id, user);
        if (dto.regionId) {
            const region = await this.prisma.region.findUnique({
                where: { id: dto.regionId },
            });
            if (!region)
                throw new common_1.NotFoundException('Region not found');
            if (user.role === client_1.StaffRole.REGIONAL_ADMIN && user.regionId !== dto.regionId) {
                throw new common_1.ForbiddenException('You can only move branches within your region');
            }
        }
        if (dto.code && dto.code !== existing.code) {
            const codeExists = await this.prisma.branch.findUnique({
                where: { code: dto.code },
            });
            if (codeExists)
                throw new common_1.ConflictException('Branch code already in use');
        }
        return this.prisma.branch.update({
            where: { id },
            data: dto,
            include: {
                region: { select: { id: true, name: true, code: true } },
            },
        });
    }
    async remove(id, user) {
        const branch = await this.findOne(id, user);
        const staffCount = await this.prisma.staff.count({ where: { branchId: id } });
        const courierCount = await this.prisma.courier.count({ where: { branchId: id } });
        if (staffCount > 0 || courierCount > 0) {
            throw new common_1.BadRequestException(`Cannot delete branch with ${staffCount} staff and ${courierCount} couriers`);
        }
        await this.prisma.branch.delete({ where: { id: branch.id } });
        return { message: 'Branch deleted' };
    }
};
exports.BranchesService = BranchesService;
exports.BranchesService = BranchesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], BranchesService);
//# sourceMappingURL=branches.service.js.map