export declare class CreateBranchDto {
    regionId: string;
    name: string;
    code: string;
    city?: string;
    woreda?: string;
    address?: string;
    phone?: string;
    lat?: number;
    lng?: number;
}
