export declare class BranchesModule {
}
