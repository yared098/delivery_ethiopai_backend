export declare class PublicTrackingModule {
}
