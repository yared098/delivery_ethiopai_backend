"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublicTrackingController = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const public_decorator_1 = require("../common/decorators/public.decorator");
let PublicTrackingController = class PublicTrackingController {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async track(token) {
        const order = await this.prisma.order.findFirst({
            where: {
                OR: [{ trackingToken: token }, { trackingNumber: token }],
            },
            include: {
                courier: {
                    select: {
                        id: true,
                        name: true,
                        phone: true,
                        vehicleType: true,
                        vehiclePlate: true,
                        currentLat: true,
                        currentLng: true,
                    },
                },
                events: {
                    where: { isPublic: true },
                    orderBy: { createdAt: 'desc' },
                    take: 10,
                },
                items: true,
                _count: { select: { items: true } },
            },
        });
        if (!order)
            throw new common_1.NotFoundException('Tracking link not found');
        return {
            order: {
                id: order.id,
                trackingNumber: order.trackingNumber,
                status: order.status,
                senderName: maskName(order.senderName),
                receiverName: order.receiverName
                    ? maskName(order.receiverName)
                    : undefined,
                senderLat: order.senderLat,
                senderLng: order.senderLng,
                receiverLat: order.receiverLat,
                receiverLng: order.receiverLng,
                distanceKm: order.distanceKm,
                totalWeightKg: order.totalWeightKg,
                itemCount: order._count.items,
                createdAt: order.createdAt,
                lastCourierLat: order.lastCourierLat,
                lastCourierLng: order.lastCourierLng,
                lastTrackedAt: order.lastTrackedAt,
                estimatedArrival: order.estimatedArrival,
                courier: order.courier
                    ? {
                        id: order.courier.id,
                        name: maskName(order.courier.name),
                        phone: maskPhone(order.courier.phone || ''),
                        vehicleType: order.courier.vehicleType,
                        vehiclePlate: order.courier.vehiclePlate,
                        currentLat: order.courier.currentLat,
                        currentLng: order.courier.currentLng,
                    }
                    : null,
                events: order.events.map((e) => ({
                    id: e.id,
                    status: e.status,
                    note: e.note,
                    createdAt: e.createdAt,
                })),
            },
        };
    }
};
exports.PublicTrackingController = PublicTrackingController;
__decorate([
    (0, common_1.Get)('track/:token'),
    __param(0, (0, common_1.Param)('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PublicTrackingController.prototype, "track", null);
exports.PublicTrackingController = PublicTrackingController = __decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Controller)('public'),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PublicTrackingController);
function maskName(name) {
    if (!name)
        return '';
    const [first, last] = name.split(' ');
    return last ? `${first} ${last[0]}.` : first;
}
function maskPhone(phone) {
    if (!phone || phone.length < 6)
        return phone;
    return `${phone.slice(0, 4)}****${phone.slice(-3)}`;
}
//# sourceMappingURL=public-tracking.controller.js.map