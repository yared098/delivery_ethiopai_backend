import { PrismaService } from '../prisma/prisma.service';
export declare class PublicTrackingController {
    private prisma;
    constructor(prisma: PrismaService);
    track(token: string): Promise<{
        order: {
            id: string;
            trackingNumber: string;
            status: import("@prisma/client").$Enums.OrderStatus;
            senderName: string;
            receiverName: string | undefined;
            senderLat: number | null;
            senderLng: number | null;
            receiverLat: number | null;
            receiverLng: number | null;
            distanceKm: number | null;
            totalWeightKg: number;
            itemCount: number;
            createdAt: Date;
            lastCourierLat: number | null;
            lastCourierLng: number | null;
            lastTrackedAt: Date | null;
            estimatedArrival: Date | null;
            courier: {
                id: string;
                name: string;
                phone: string;
                vehicleType: import("@prisma/client").$Enums.VehicleType;
                vehiclePlate: string | null;
                currentLat: number | null;
                currentLng: number | null;
            } | null;
            events: {
                id: string;
                status: import("@prisma/client").$Enums.OrderStatus;
                note: string | null;
                createdAt: Date;
            }[];
        };
    }>;
}
