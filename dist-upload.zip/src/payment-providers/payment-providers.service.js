"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentProvidersService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const client_1 = require("@prisma/client");
let PaymentProvidersService = class PaymentProvidersService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(dto, currentUser) {
        if (currentUser.role !== client_1.StaffRole.SUPER_ADMIN) {
            throw new common_1.ForbiddenException('Only Super Admin can add payment providers');
        }
        const code = dto.code.toUpperCase().trim();
        const existing = await this.prisma.paymentProvider.findUnique({
            where: { code },
        });
        if (existing) {
            throw new common_1.ConflictException(`Provider with code ${code} already exists`);
        }
        return this.prisma.paymentProvider.create({
            data: {
                code,
                name: dto.name,
                description: dto.description,
                type: dto.type,
                logoUrl: dto.logoUrl,
                color: dto.color,
                sortOrder: dto.sortOrder ?? 0,
                isEnabled: dto.isEnabled ?? false,
                isTestMode: dto.isTestMode ?? true,
                feePercent: dto.feePercent ?? 0,
                feeFixed: dto.feeFixed ?? 0,
                minAmount: dto.minAmount,
                maxAmount: dto.maxAmount,
                apiKey: dto.apiKey?.trim() || null,
                apiSecret: dto.apiSecret?.trim() || null,
                merchantId: dto.merchantId?.trim() || null,
                webhookUrl: dto.webhookUrl?.trim() || null,
                configJson: dto.configJson,
                createdById: currentUser.id,
            },
            select: this.publicSelect(),
        });
    }
    async findAll(query) {
        const where = {};
        if (query.type)
            where.type = query.type;
        if (query.isEnabled !== undefined)
            where.isEnabled = query.isEnabled;
        if (query.search) {
            where.OR = [
                { name: { contains: query.search, mode: 'insensitive' } },
                { code: { contains: query.search, mode: 'insensitive' } },
            ];
        }
        return this.prisma.paymentProvider.findMany({
            where,
            orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
            select: this.publicSelect(),
        });
    }
    async findEnabled() {
        return this.prisma.paymentProvider.findMany({
            where: { isEnabled: true },
            orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
            select: {
                id: true,
                code: true,
                name: true,
                description: true,
                type: true,
                logoUrl: true,
                color: true,
                feePercent: true,
                feeFixed: true,
                minAmount: true,
                maxAmount: true,
            },
        });
    }
    async findOne(id) {
        const provider = await this.prisma.paymentProvider.findUnique({
            where: { id },
            select: this.publicSelect(),
        });
        if (!provider)
            throw new common_1.NotFoundException('Payment provider not found');
        return provider;
    }
    async findByCode(code) {
        const provider = await this.prisma.paymentProvider.findUnique({
            where: { code: code.toUpperCase() },
            select: this.publicSelect(),
        });
        if (!provider)
            throw new common_1.NotFoundException('Payment provider not found');
        return provider;
    }
    async update(id, dto, currentUser) {
        if (currentUser.role !== client_1.StaffRole.SUPER_ADMIN) {
            throw new common_1.ForbiddenException('Only Super Admin can edit payment providers');
        }
        await this.findOne(id);
        const data = { updatedById: currentUser.id };
        const { apiSecret, apiKey, configJson, ...rest } = dto;
        Object.assign(data, rest);
        if (apiSecret !== undefined &&
            apiSecret !== null &&
            apiSecret.trim() !== '') {
            data.apiSecret = apiSecret.trim();
        }
        if (apiKey !== undefined && apiKey !== null && apiKey.trim() !== '') {
            data.apiKey = apiKey.trim();
        }
        if (configJson !== undefined && configJson !== null) {
            data.configJson = configJson;
        }
        if (dto.code) {
            const code = dto.code.toUpperCase().trim();
            const existing = await this.prisma.paymentProvider.findUnique({
                where: { code },
            });
            if (existing && existing.id !== id) {
                throw new common_1.ConflictException(`Provider with code ${code} already exists`);
            }
            data.code = code;
        }
        return this.prisma.paymentProvider.update({
            where: { id },
            data,
            select: this.publicSelect(),
        });
    }
    async toggleEnabled(id, currentUser) {
        if (currentUser.role !== client_1.StaffRole.SUPER_ADMIN) {
            throw new common_1.ForbiddenException('Only Super Admin can enable/disable providers');
        }
        const provider = await this.findOne(id);
        const newState = !provider.isEnabled;
        await this.prisma.paymentProvider.update({
            where: { id },
            data: { isEnabled: newState, updatedById: currentUser.id },
        });
        return {
            isEnabled: newState,
            message: newState ? 'Provider enabled' : 'Provider disabled',
        };
    }
    async reorder(items, currentUser) {
        if (currentUser.role !== client_1.StaffRole.SUPER_ADMIN) {
            throw new common_1.ForbiddenException('Only Super Admin can reorder');
        }
        await this.prisma.$transaction(items.map((item) => this.prisma.paymentProvider.update({
            where: { id: item.id },
            data: { sortOrder: item.sortOrder, updatedById: currentUser.id },
        })));
        return { message: 'Reordered' };
    }
    async remove(id, currentUser) {
        if (currentUser.role !== client_1.StaffRole.SUPER_ADMIN) {
            throw new common_1.ForbiddenException('Only Super Admin can delete payment providers');
        }
        await this.findOne(id);
        await this.prisma.paymentProvider.delete({ where: { id } });
        return { message: 'Payment provider deleted' };
    }
    publicSelect() {
        return {
            id: true,
            code: true,
            name: true,
            description: true,
            type: true,
            logoUrl: true,
            color: true,
            sortOrder: true,
            isEnabled: true,
            isTestMode: true,
            feePercent: true,
            feeFixed: true,
            minAmount: true,
            maxAmount: true,
            merchantId: true,
            webhookUrl: true,
            apiKey: true,
            createdAt: true,
            updatedAt: true,
            createdBy: { select: { id: true, name: true } },
            updatedBy: { select: { id: true, name: true } },
        };
    }
};
exports.PaymentProvidersService = PaymentProvidersService;
exports.PaymentProvidersService = PaymentProvidersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], PaymentProvidersService);
//# sourceMappingURL=payment-providers.service.js.map