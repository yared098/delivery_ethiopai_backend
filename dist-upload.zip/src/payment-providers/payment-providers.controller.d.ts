import { PaymentProvidersService } from './payment-providers.service';
import { CreateProviderDto } from './dto/create-provider.dto';
import { UpdateProviderDto } from './dto/update-provider.dto';
import { ListProvidersQueryDto } from './dto/list-providers-query.dto';
declare class ReorderDto {
    items: {
        id: string;
        sortOrder: number;
    }[];
}
export declare class PaymentProvidersController {
    private providers;
    constructor(providers: PaymentProvidersService);
    findEnabled(): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
    }[]>;
    create(dto: CreateProviderDto, user: any): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        sortOrder: number;
        isEnabled: boolean;
        isTestMode: boolean;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
        apiKey: string | null;
        merchantId: string | null;
        webhookUrl: string | null;
        createdAt: Date;
        updatedAt: Date;
        createdBy: {
            id: string;
            name: string;
        } | null;
        updatedBy: {
            id: string;
            name: string;
        } | null;
    }>;
    findAll(query: ListProvidersQueryDto): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        sortOrder: number;
        isEnabled: boolean;
        isTestMode: boolean;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
        apiKey: string | null;
        merchantId: string | null;
        webhookUrl: string | null;
        createdAt: Date;
        updatedAt: Date;
        createdBy: {
            id: string;
            name: string;
        } | null;
        updatedBy: {
            id: string;
            name: string;
        } | null;
    }[]>;
    reorder(dto: ReorderDto, user: any): Promise<{
        message: string;
    }>;
    findByCode(code: string): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        sortOrder: number;
        isEnabled: boolean;
        isTestMode: boolean;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
        apiKey: string | null;
        merchantId: string | null;
        webhookUrl: string | null;
        createdAt: Date;
        updatedAt: Date;
        createdBy: {
            id: string;
            name: string;
        } | null;
        updatedBy: {
            id: string;
            name: string;
        } | null;
    }>;
    findOne(id: string): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        sortOrder: number;
        isEnabled: boolean;
        isTestMode: boolean;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
        apiKey: string | null;
        merchantId: string | null;
        webhookUrl: string | null;
        createdAt: Date;
        updatedAt: Date;
        createdBy: {
            id: string;
            name: string;
        } | null;
        updatedBy: {
            id: string;
            name: string;
        } | null;
    }>;
    update(id: string, dto: UpdateProviderDto, user: any): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        sortOrder: number;
        isEnabled: boolean;
        isTestMode: boolean;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
        apiKey: string | null;
        merchantId: string | null;
        webhookUrl: string | null;
        createdAt: Date;
        updatedAt: Date;
        createdBy: {
            id: string;
            name: string;
        } | null;
        updatedBy: {
            id: string;
            name: string;
        } | null;
    }>;
    toggle(id: string, user: any): Promise<{
        isEnabled: boolean;
        message: string;
    }>;
    remove(id: string, user: any): Promise<{
        message: string;
    }>;
    secretStatus(id: string): Promise<{
        code: any;
        hasApiKey: boolean;
        hasApiSecret: boolean;
        apiSecretLength: any;
        apiSecretPrefix: any;
        apiSecretSuffix: any;
        merchantId: any;
        webhookUrl: any;
        isEnabled: any;
        isTestMode: any;
    }>;
}
export {};
