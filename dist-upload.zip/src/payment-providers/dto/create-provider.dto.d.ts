import { PaymentProviderType } from '@prisma/client';
export declare class CreateProviderDto {
    code: string;
    name: string;
    description?: string;
    type: PaymentProviderType;
    logoUrl?: string;
    color?: string;
    sortOrder?: number;
    isEnabled?: boolean;
    isTestMode?: boolean;
    feePercent?: number;
    feeFixed?: number;
    minAmount?: number;
    maxAmount?: number;
    apiKey?: string;
    apiSecret?: string;
    merchantId?: string;
    webhookUrl?: string;
    configJson?: any;
}
