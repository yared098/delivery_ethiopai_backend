import { PaymentProviderType } from '@prisma/client';
export declare class ListProvidersQueryDto {
    type?: PaymentProviderType;
    isEnabled?: boolean;
    search?: string;
}
