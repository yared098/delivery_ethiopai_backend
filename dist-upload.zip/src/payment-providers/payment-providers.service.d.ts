import { PrismaService } from '../prisma/prisma.service';
import { CreateProviderDto } from './dto/create-provider.dto';
import { UpdateProviderDto } from './dto/update-provider.dto';
import { ListProvidersQueryDto } from './dto/list-providers-query.dto';
export declare class PaymentProvidersService {
    private prisma;
    constructor(prisma: PrismaService);
    create(dto: CreateProviderDto, currentUser: any): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        sortOrder: number;
        isEnabled: boolean;
        isTestMode: boolean;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
        apiKey: string | null;
        merchantId: string | null;
        webhookUrl: string | null;
        createdAt: Date;
        updatedAt: Date;
        createdBy: {
            id: string;
            name: string;
        } | null;
        updatedBy: {
            id: string;
            name: string;
        } | null;
    }>;
    findAll(query: ListProvidersQueryDto): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        sortOrder: number;
        isEnabled: boolean;
        isTestMode: boolean;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
        apiKey: string | null;
        merchantId: string | null;
        webhookUrl: string | null;
        createdAt: Date;
        updatedAt: Date;
        createdBy: {
            id: string;
            name: string;
        } | null;
        updatedBy: {
            id: string;
            name: string;
        } | null;
    }[]>;
    findEnabled(): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
    }[]>;
    findOne(id: string): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        sortOrder: number;
        isEnabled: boolean;
        isTestMode: boolean;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
        apiKey: string | null;
        merchantId: string | null;
        webhookUrl: string | null;
        createdAt: Date;
        updatedAt: Date;
        createdBy: {
            id: string;
            name: string;
        } | null;
        updatedBy: {
            id: string;
            name: string;
        } | null;
    }>;
    findByCode(code: string): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        sortOrder: number;
        isEnabled: boolean;
        isTestMode: boolean;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
        apiKey: string | null;
        merchantId: string | null;
        webhookUrl: string | null;
        createdAt: Date;
        updatedAt: Date;
        createdBy: {
            id: string;
            name: string;
        } | null;
        updatedBy: {
            id: string;
            name: string;
        } | null;
    }>;
    update(id: string, dto: UpdateProviderDto, currentUser: any): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        sortOrder: number;
        isEnabled: boolean;
        isTestMode: boolean;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
        apiKey: string | null;
        merchantId: string | null;
        webhookUrl: string | null;
        createdAt: Date;
        updatedAt: Date;
        createdBy: {
            id: string;
            name: string;
        } | null;
        updatedBy: {
            id: string;
            name: string;
        } | null;
    }>;
    toggleEnabled(id: string, currentUser: any): Promise<{
        isEnabled: boolean;
        message: string;
    }>;
    reorder(items: {
        id: string;
        sortOrder: number;
    }[], currentUser: any): Promise<{
        message: string;
    }>;
    remove(id: string, currentUser: any): Promise<{
        message: string;
    }>;
    private publicSelect;
}
