"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentProvidersController = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const payment_providers_service_1 = require("./payment-providers.service");
const create_provider_dto_1 = require("./dto/create-provider.dto");
const update_provider_dto_1 = require("./dto/update-provider.dto");
const list_providers_query_dto_1 = require("./dto/list-providers-query.dto");
const jwt_auth_guard_1 = require("../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../common/guards/roles.guard");
const staff_roles_decorator_1 = require("../common/decorators/staff-roles.decorator");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const client_1 = require("@prisma/client");
class ReorderDto {
}
__decorate([
    (0, class_validator_1.IsArray)(),
    __metadata("design:type", Array)
], ReorderDto.prototype, "items", void 0);
let PaymentProvidersController = class PaymentProvidersController {
    constructor(providers) {
        this.providers = providers;
    }
    findEnabled() {
        return this.providers.findEnabled();
    }
    create(dto, user) {
        return this.providers.create(dto, user);
    }
    findAll(query) {
        return this.providers.findAll(query);
    }
    reorder(dto, user) {
        return this.providers.reorder(dto.items, user);
    }
    findByCode(code) {
        return this.providers.findByCode(code);
    }
    findOne(id) {
        return this.providers.findOne(id);
    }
    update(id, dto, user) {
        return this.providers.update(id, dto, user);
    }
    toggle(id, user) {
        return this.providers.toggleEnabled(id, user);
    }
    remove(id, user) {
        return this.providers.remove(id, user);
    }
    async secretStatus(id) {
        const provider = await this.providers.prisma.paymentProvider.findUnique({
            where: { id },
        });
        if (!provider)
            throw new common_1.NotFoundException('Provider not found');
        return {
            code: provider.code,
            hasApiKey: !!provider.apiKey,
            hasApiSecret: !!provider.apiSecret,
            apiSecretLength: provider.apiSecret?.length || 0,
            apiSecretPrefix: provider.apiSecret?.slice(0, 14) || null,
            apiSecretSuffix: provider.apiSecret?.slice(-4) || null,
            merchantId: provider.merchantId,
            webhookUrl: provider.webhookUrl,
            isEnabled: provider.isEnabled,
            isTestMode: provider.isTestMode,
        };
    }
};
exports.PaymentProvidersController = PaymentProvidersController;
__decorate([
    (0, common_1.Get)('enabled'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PaymentProvidersController.prototype, "findEnabled", null);
__decorate([
    (0, common_1.Post)(),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_provider_dto_1.CreateProviderDto, Object]),
    __metadata("design:returntype", void 0)
], PaymentProvidersController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_providers_query_dto_1.ListProvidersQueryDto]),
    __metadata("design:returntype", void 0)
], PaymentProvidersController.prototype, "findAll", null);
__decorate([
    (0, common_1.Post)('reorder'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [ReorderDto, Object]),
    __metadata("design:returntype", void 0)
], PaymentProvidersController.prototype, "reorder", null);
__decorate([
    (0, common_1.Get)('by-code/:code'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN),
    __param(0, (0, common_1.Param)('code')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PaymentProvidersController.prototype, "findByCode", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PaymentProvidersController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_provider_dto_1.UpdateProviderDto, Object]),
    __metadata("design:returntype", void 0)
], PaymentProvidersController.prototype, "update", null);
__decorate([
    (0, common_1.Post)(':id/toggle'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], PaymentProvidersController.prototype, "toggle", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], PaymentProvidersController.prototype, "remove", null);
__decorate([
    (0, common_1.Get)(':id/secret-status'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentProvidersController.prototype, "secretStatus", null);
exports.PaymentProvidersController = PaymentProvidersController = __decorate([
    (0, common_1.Controller)('admin/payment-providers'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    __metadata("design:paramtypes", [payment_providers_service_1.PaymentProvidersService])
], PaymentProvidersController);
//# sourceMappingURL=payment-providers.controller.js.map