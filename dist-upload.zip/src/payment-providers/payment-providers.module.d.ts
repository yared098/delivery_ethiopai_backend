export declare class PaymentProvidersModule {
}
