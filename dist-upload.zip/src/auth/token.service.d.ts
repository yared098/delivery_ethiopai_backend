import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import { AccountType, StaffRole } from '@prisma/client';
export interface AccessPayload {
    sub: string;
    accountType: AccountType;
    family?: string;
    role?: StaffRole;
    regionId?: string | null;
    branchId?: string | null;
}
interface Meta {
    userAgent?: string;
    ipAddress?: string;
}
export declare class TokenService {
    private jwt;
    private config;
    private prisma;
    constructor(jwt: JwtService, config: ConfigService, prisma: PrismaService);
    issueTokens(payload: AccessPayload, meta: Meta): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    isSessionActive(accountId: string, accountType: AccountType, family?: string): Promise<boolean>;
    private lockAccount;
    rotate(refreshToken: string, meta: Meta): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    revokeAll(accountId: string, accountType: AccountType): Promise<void>;
    revokeByRefreshToken(refreshToken: string): Promise<void>;
}
export {};
