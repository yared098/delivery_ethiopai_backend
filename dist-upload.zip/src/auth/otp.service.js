"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OtpService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const afromessage_service_1 = require("../integrations/afromessage/afromessage.service");
const config_1 = require("@nestjs/config");
const argon2 = __importStar(require("argon2"));
const ioredis_1 = require("ioredis");
let OtpService = class OtpService {
    constructor(prisma, sms, config) {
        this.prisma = prisma;
        this.sms = sms;
        this.config = config;
        this.redis = new ioredis_1.Redis(this.config.get('REDIS_URL'));
    }
    onModuleDestroy() {
        this.redis.disconnect();
    }
    normalizePhone(phone) {
        const digits = phone.replace(/\D/g, '');
        if (digits.startsWith('251') && digits.length === 12)
            return digits;
        if (digits.startsWith('0') && digits.length === 10)
            return '251' + digits.slice(1);
        if (digits.length === 9)
            return '251' + digits;
        throw new common_1.BadRequestException('Invalid Ethiopian phone number');
    }
    async requestOtp(rawPhone, accountType, purpose = 'login', extraIds = {}) {
        const phone = this.normalizePhone(rawPhone);
        const limit = Number(this.config.get('OTP_RATE_LIMIT_PER_10MIN') || 3);
        const key = `otp:rate:${phone}:${accountType}:${purpose}`;
        const count = await this.redis.incr(key);
        if (count === 1)
            await this.redis.expire(key, 600);
        if (count > limit) {
            throw new common_1.HttpException('Too many OTP requests. Try again later.', common_1.HttpStatus.TOO_MANY_REQUESTS);
        }
        const code = Math.floor(100000 + Math.random() * 900000).toString();
        const codeHash = await argon2.hash(code);
        const ttl = Number(this.config.get('OTP_TTL_SECONDS') || 300);
        const expiresAt = new Date(Date.now() + ttl * 1000);
        await this.prisma.otpCode.updateMany({
            where: { phone, accountType, purpose, used: false },
            data: { used: true },
        });
        await this.prisma.otpCode.create({
            data: {
                phone,
                accountType,
                codeHash,
                purpose,
                expiresAt,
                staffId: extraIds.staffId,
                courierId: extraIds.courierId,
            },
        });
        const sent = await this.sms.sendOtp(phone, code);
        if (!sent)
            throw new common_1.BadRequestException('Failed to send OTP');
    }
    async verifyOtp(rawPhone, code, accountType, purpose = 'login') {
        const phone = this.normalizePhone(rawPhone);
        const record = await this.prisma.otpCode.findFirst({
            where: { phone, accountType, purpose, used: false },
            orderBy: { createdAt: 'desc' },
        });
        if (!record)
            throw new common_1.BadRequestException('No active OTP');
        if (record.expiresAt < new Date())
            throw new common_1.BadRequestException('OTP expired');
        const maxAttempts = Number(this.config.get('OTP_MAX_ATTEMPTS') || 3);
        if (record.attempts >= maxAttempts) {
            throw new common_1.BadRequestException('Too many attempts. Request a new OTP.');
        }
        const valid = await argon2.verify(record.codeHash, code);
        if (!valid) {
            await this.prisma.otpCode.update({
                where: { id: record.id },
                data: { attempts: { increment: 1 } },
            });
            throw new common_1.BadRequestException('Invalid OTP');
        }
        await this.prisma.otpCode.update({
            where: { id: record.id },
            data: { used: true },
        });
        return phone;
    }
};
exports.OtpService = OtpService;
exports.OtpService = OtpService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        afromessage_service_1.AfroMessageService,
        config_1.ConfigService])
], OtpService);
//# sourceMappingURL=otp.service.js.map