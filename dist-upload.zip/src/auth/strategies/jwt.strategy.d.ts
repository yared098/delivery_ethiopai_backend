import { Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { AccountType, StaffRole } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { TokenService } from '../token.service';
interface JwtPayload {
    sub: string;
    accountType: AccountType;
    role?: StaffRole;
    regionId?: string | null;
    branchId?: string | null;
    family?: string;
    iat?: number;
}
declare const JwtStrategy_base: new (...args: any[]) => Strategy;
export declare class JwtStrategy extends JwtStrategy_base {
    private prisma;
    private tokens;
    private readonly logger;
    constructor(config: ConfigService, prisma: PrismaService, tokens: TokenService);
    validate(payload: JwtPayload): Promise<{
        id: string;
        phone: string;
        name: string;
        email: string | null;
        accountType: "STAFF";
        role: import("@prisma/client").$Enums.StaffRole;
        regionId: string | null;
        branchId: string | null;
        mustChangePassword: boolean;
    } | {
        id: string;
        phone: string;
        name: string;
        email: string | null;
        accountType: "COURIER";
        regionId: string;
        branchId: string;
        role?: undefined;
        mustChangePassword?: undefined;
    } | {
        id: string;
        phone: string;
        name: string | null;
        email: string | null;
        accountType: "CUSTOMER";
        role?: undefined;
        regionId?: undefined;
        branchId?: undefined;
        mustChangePassword?: undefined;
    }>;
}
export {};
