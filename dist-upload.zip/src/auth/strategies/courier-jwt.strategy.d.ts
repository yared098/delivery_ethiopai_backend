import { Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';
import { AccountType } from '@prisma/client';
import { TokenService } from '../token.service';
declare const CourierJwtStrategy_base: new (...args: any[]) => Strategy;
export declare class CourierJwtStrategy extends CourierJwtStrategy_base {
    private prisma;
    private tokens;
    constructor(config: ConfigService, prisma: PrismaService, tokens: TokenService);
    validate(payload: {
        sub: string;
        accountType: AccountType;
        family?: string;
    }): Promise<{
        id: string;
        accountType: "COURIER";
        regionId: string;
        branchId: string;
    }>;
}
export {};
