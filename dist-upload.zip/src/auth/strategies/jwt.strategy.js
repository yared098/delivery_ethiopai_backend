"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var JwtStrategy_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.JwtStrategy = void 0;
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const passport_jwt_1 = require("passport-jwt");
const config_1 = require("@nestjs/config");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../prisma/prisma.service");
const token_service_1 = require("../token.service");
let JwtStrategy = JwtStrategy_1 = class JwtStrategy extends (0, passport_1.PassportStrategy)(passport_jwt_1.Strategy, 'jwt') {
    constructor(config, prisma, tokens) {
        super({
            jwtFromRequest: passport_jwt_1.ExtractJwt.fromAuthHeaderAsBearerToken(),
            ignoreExpiration: false,
            secretOrKey: config.get('JWT_ACCESS_SECRET'),
        });
        this.prisma = prisma;
        this.tokens = tokens;
        this.logger = new common_1.Logger(JwtStrategy_1.name);
    }
    async validate(payload) {
        const { sub, accountType, iat } = payload;
        if ([client_1.AccountType.STAFF, client_1.AccountType.COURIER, client_1.AccountType.CUSTOMER].includes(accountType) &&
            !(await this.tokens.isSessionActive(sub, accountType, payload.family))) {
            throw new common_1.UnauthorizedException('Session expired. Please log in again.');
        }
        if (accountType === client_1.AccountType.STAFF) {
            const staff = await this.prisma.staff.findUnique({
                where: { id: sub },
                select: {
                    id: true,
                    phone: true,
                    name: true,
                    email: true,
                    role: true,
                    regionId: true,
                    branchId: true,
                    isActive: true,
                    suspendedAt: true,
                    passwordChangedAt: true,
                    mustChangePassword: true,
                },
            });
            if (!staff) {
                this.logger.warn(`Staff not found: ${sub}`);
                throw new common_1.UnauthorizedException('Account not found');
            }
            if (!staff.isActive || staff.suspendedAt) {
                this.logger.warn(`Suspended staff tried to access: ${sub}`);
                throw new common_1.UnauthorizedException('Account suspended');
            }
            if (staff.passwordChangedAt &&
                iat &&
                Math.floor(staff.passwordChangedAt.getTime() / 1000) > iat) {
                this.logger.warn(`Stale token (password changed): ${sub}`);
                throw new common_1.UnauthorizedException('Password changed. Please log in again.');
            }
            this.logger.debug(`JWT validated: sub=${sub}, accountType=${accountType}, role=${staff.role}`);
            return {
                id: staff.id,
                phone: staff.phone,
                name: staff.name,
                email: staff.email,
                accountType: client_1.AccountType.STAFF,
                role: staff.role,
                regionId: staff.regionId,
                branchId: staff.branchId,
                mustChangePassword: staff.mustChangePassword,
            };
        }
        if (accountType === client_1.AccountType.COURIER) {
            const courier = await this.prisma.courier.findUnique({
                where: { id: sub },
                select: {
                    id: true,
                    phone: true,
                    name: true,
                    email: true,
                    regionId: true,
                    branchId: true,
                    isActive: true,
                    status: true,
                    suspendedAt: true,
                    passwordChangedAt: true,
                },
            });
            if (!courier) {
                this.logger.warn(`Courier not found: ${sub}`);
                throw new common_1.UnauthorizedException('Account not found');
            }
            if (!courier.isActive || courier.suspendedAt) {
                this.logger.warn(`Suspended courier tried to access: ${sub}`);
                throw new common_1.UnauthorizedException('Courier suspended');
            }
            if (courier.status !== 'APPROVED') {
                this.logger.warn(`Unapproved courier tried to access: ${sub}`);
                throw new common_1.UnauthorizedException(`Courier status: ${courier.status}`);
            }
            if (courier.passwordChangedAt &&
                iat &&
                Math.floor(courier.passwordChangedAt.getTime() / 1000) > iat) {
                throw new common_1.UnauthorizedException('Password changed. Please log in again.');
            }
            return {
                id: courier.id,
                phone: courier.phone,
                name: courier.name,
                email: courier.email,
                accountType: client_1.AccountType.COURIER,
                regionId: courier.regionId,
                branchId: courier.branchId,
            };
        }
        if (accountType === client_1.AccountType.CUSTOMER) {
            const customer = await this.prisma.customer.findUnique({
                where: { id: sub },
                select: {
                    id: true,
                    phone: true,
                    name: true,
                    email: true,
                    isActive: true,
                },
            });
            if (!customer) {
                this.logger.warn(`Customer not found: ${sub}`);
                throw new common_1.UnauthorizedException('Account not found');
            }
            if (!customer.isActive) {
                this.logger.warn(`Disabled customer tried to access: ${sub}`);
                throw new common_1.UnauthorizedException('Account disabled');
            }
            return {
                id: customer.id,
                phone: customer.phone,
                name: customer.name,
                email: customer.email,
                accountType: client_1.AccountType.CUSTOMER,
            };
        }
        this.logger.warn(`Invalid account type in JWT: ${accountType}`);
        throw new common_1.UnauthorizedException('Invalid account type');
    }
};
exports.JwtStrategy = JwtStrategy;
exports.JwtStrategy = JwtStrategy = JwtStrategy_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService,
        prisma_service_1.PrismaService,
        token_service_1.TokenService])
], JwtStrategy);
//# sourceMappingURL=jwt.strategy.js.map