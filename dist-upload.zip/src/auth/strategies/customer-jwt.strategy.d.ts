import { Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { AccountType } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { TokenService } from '../token.service';
declare const CustomerJwtStrategy_base: new (...args: any[]) => Strategy;
export declare class CustomerJwtStrategy extends CustomerJwtStrategy_base {
    private prisma;
    private tokens;
    private readonly logger;
    constructor(config: ConfigService, prisma: PrismaService, tokens: TokenService);
    validate(payload: {
        sub: string;
        accountType: AccountType;
        family?: string;
    }): Promise<{
        id: string;
        phone: string;
        name: string | null;
        accountType: "CUSTOMER";
    }>;
}
export {};
