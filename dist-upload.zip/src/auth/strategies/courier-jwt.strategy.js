"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CourierJwtStrategy = void 0;
const common_1 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
const passport_jwt_1 = require("passport-jwt");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../../prisma/prisma.service");
const client_1 = require("@prisma/client");
const token_service_1 = require("../token.service");
let CourierJwtStrategy = class CourierJwtStrategy extends (0, passport_1.PassportStrategy)(passport_jwt_1.Strategy, 'courier-jwt') {
    constructor(config, prisma, tokens) {
        super({
            jwtFromRequest: passport_jwt_1.ExtractJwt.fromAuthHeaderAsBearerToken(),
            ignoreExpiration: false,
            secretOrKey: config.get('JWT_ACCESS_SECRET'),
        });
        this.prisma = prisma;
        this.tokens = tokens;
    }
    async validate(payload) {
        if (payload.accountType !== client_1.AccountType.COURIER) {
            throw new common_1.UnauthorizedException('Not a courier token');
        }
        if (!(await this.tokens.isSessionActive(payload.sub, client_1.AccountType.COURIER, payload.family))) {
            throw new common_1.UnauthorizedException('Session expired. Please log in again.');
        }
        const courier = await this.prisma.courier.findUnique({
            where: { id: payload.sub },
        });
        if (!courier || !courier.isActive) {
            throw new common_1.UnauthorizedException('Courier not found or inactive');
        }
        if (courier.status !== client_1.CourierStatus.APPROVED) {
            throw new common_1.UnauthorizedException(`Courier status: ${courier.status}`);
        }
        return {
            id: courier.id,
            accountType: client_1.AccountType.COURIER,
            regionId: courier.regionId,
            branchId: courier.branchId,
        };
    }
};
exports.CourierJwtStrategy = CourierJwtStrategy;
exports.CourierJwtStrategy = CourierJwtStrategy = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService,
        prisma_service_1.PrismaService,
        token_service_1.TokenService])
], CourierJwtStrategy);
//# sourceMappingURL=courier-jwt.strategy.js.map