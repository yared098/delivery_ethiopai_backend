"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const auth_service_1 = require("./auth.service");
const request_otp_dto_1 = require("./dto/request-otp.dto");
const verify_otp_dto_1 = require("./dto/verify-otp.dto");
const refresh_token_dto_1 = require("./dto/refresh-token.dto");
const update_customer_profile_dto_1 = require("./dto/update-customer-profile.dto");
const courier_jwt_guard_1 = require("../common/guards/courier-jwt.guard");
const current_courier_decorator_1 = require("../common/decorators/current-courier.decorator");
const public_decorator_1 = require("../common/decorators/public.decorator");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const customer_jwt_guard_1 = require("../common/guards/customer-jwt.guard");
const current_customer_decorator_1 = require("../common/decorators/current-customer.decorator");
const register_customer_dto_1 = require("./dto/register-customer.dto");
const register_device_token_dto_1 = require("./dto/register-device-token.dto");
const check_courier_phone_dto_1 = require("./dto/check-courier-phone.dto");
class StaffLoginStep1Dto {
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], StaffLoginStep1Dto.prototype, "phone", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], StaffLoginStep1Dto.prototype, "password", void 0);
class StaffLoginStep2Dto {
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], StaffLoginStep2Dto.prototype, "tempToken", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], StaffLoginStep2Dto.prototype, "code", void 0);
let AuthController = class AuthController {
    constructor(auth) {
        this.auth = auth;
    }
    superAdminRequestOtp(dto) {
        return this.auth.requestSuperAdminOtp(dto.phone);
    }
    superAdminVerifyOtp(dto, req) {
        return this.auth.verifySuperAdminOtp(dto.phone, dto.code, this.meta(req));
    }
    staffLogin(dto) {
        return this.auth.staffLoginStep1(dto.phone, dto.password);
    }
    staffLoginVerify(dto, req) {
        return this.auth.staffLoginStep2(dto.tempToken, dto.code, this.meta(req));
    }
    courierRequestOtp(dto) {
        return this.auth.requestCourierOtp(dto.phone);
    }
    courierVerifyOtp(dto, req) {
        return this.auth.verifyCourierOtp(dto.phone, dto.code, this.meta(req));
    }
    customerRequestOtp(dto) {
        return this.auth.requestCustomerOtp(dto.phone);
    }
    customerVerifyOtp(dto, req) {
        return this.auth.verifyCustomerOtp(dto.phone, dto.code, this.meta(req));
    }
    customerRegister(dto, req) {
        return this.auth.registerCustomer(dto.registrationToken, {
            name: dto.name,
            email: dto.email,
            defaultAddress: dto.defaultAddress,
            defaultLat: dto.defaultLat,
            defaultLng: dto.defaultLng,
        }, this.meta(req));
    }
    refresh(dto, req) {
        return this.auth.refresh(dto.refreshToken, this.meta(req));
    }
    logout(dto) {
        return this.auth.logout(dto.refreshToken);
    }
    getCustomerProfile(customer) {
        return this.auth.getCustomerProfile(customer.id);
    }
    updateCustomerProfile(customer, dto) {
        return this.auth.updateCustomerProfile(customer.id, dto);
    }
    logoutAll(user) {
        return this.auth.logoutAll(user.id, user.accountType);
    }
    meta(req) {
        return {
            userAgent: req.headers['user-agent'],
            ipAddress: req.ip,
        };
    }
    registerDeviceToken(customer, dto) {
        return this.auth.registerCustomerDeviceToken(customer.id, dto.token, dto.platform);
    }
    removeDeviceToken(customer, dto) {
        return this.auth.removeCustomerDeviceToken(customer.id, dto.token);
    }
    checkCourierPhone(dto) {
        return this.auth.checkCourierPhone(dto.phone);
    }
    registerCourierDeviceToken(courier, dto) {
        return this.auth.registerCourierDeviceToken(courier.id, dto.token, dto.platform);
    }
    removeCourierDeviceToken(courier, dto) {
        return this.auth.removeCourierDeviceToken(courier.id, dto.token);
    }
};
exports.AuthController = AuthController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('super-admin/otp/request'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [request_otp_dto_1.RequestOtpDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "superAdminRequestOtp", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('super-admin/otp/verify'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [verify_otp_dto_1.VerifyOtpDto, Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "superAdminVerifyOtp", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('staff/login'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [StaffLoginStep1Dto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "staffLogin", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('staff/login/verify'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [StaffLoginStep2Dto, Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "staffLoginVerify", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('courier/otp/request'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [request_otp_dto_1.RequestOtpDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "courierRequestOtp", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('courier/otp/verify'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [verify_otp_dto_1.VerifyOtpDto, Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "courierVerifyOtp", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('customer/otp/request'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [request_otp_dto_1.RequestOtpDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "customerRequestOtp", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('customer/otp/verify'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [verify_otp_dto_1.VerifyOtpDto, Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "customerVerifyOtp", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('customer/register'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [register_customer_dto_1.RegisterCustomerDto, Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "customerRegister", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('refresh'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [refresh_token_dto_1.RefreshTokenDto, Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "refresh", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('logout'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [refresh_token_dto_1.RefreshTokenDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "logout", null);
__decorate([
    (0, common_1.UseGuards)(customer_jwt_guard_1.CustomerJwtGuard),
    (0, common_1.Get)('customer/me'),
    __param(0, (0, current_customer_decorator_1.CurrentCustomer)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "getCustomerProfile", null);
__decorate([
    (0, common_1.UseGuards)(customer_jwt_guard_1.CustomerJwtGuard),
    (0, common_1.Patch)('customer/me'),
    __param(0, (0, current_customer_decorator_1.CurrentCustomer)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, update_customer_profile_dto_1.UpdateCustomerProfileDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "updateCustomerProfile", null);
__decorate([
    (0, common_1.Post)('logout-all'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "logoutAll", null);
__decorate([
    (0, common_1.UseGuards)(customer_jwt_guard_1.CustomerJwtGuard),
    (0, common_1.Post)('customer/device-token'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_customer_decorator_1.CurrentCustomer)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, register_device_token_dto_1.RegisterDeviceTokenDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "registerDeviceToken", null);
__decorate([
    (0, common_1.UseGuards)(customer_jwt_guard_1.CustomerJwtGuard),
    (0, common_1.Post)('customer/device-token/remove'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_customer_decorator_1.CurrentCustomer)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, register_device_token_dto_1.RegisterDeviceTokenDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "removeDeviceToken", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Post)('courier/check-phone'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [check_courier_phone_dto_1.CheckCourierPhoneDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "checkCourierPhone", null);
__decorate([
    (0, common_1.UseGuards)(courier_jwt_guard_1.CourierJwtGuard),
    (0, common_1.Post)('courier/device-token'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, register_device_token_dto_1.RegisterDeviceTokenDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "registerCourierDeviceToken", null);
__decorate([
    (0, common_1.UseGuards)(courier_jwt_guard_1.CourierJwtGuard),
    (0, common_1.Post)('courier/device-token/remove'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, register_device_token_dto_1.RegisterDeviceTokenDto]),
    __metadata("design:returntype", void 0)
], AuthController.prototype, "removeCourierDeviceToken", null);
exports.AuthController = AuthController = __decorate([
    (0, common_1.Controller)('auth'),
    __metadata("design:paramtypes", [auth_service_1.AuthService])
], AuthController);
//# sourceMappingURL=auth.controller.js.map