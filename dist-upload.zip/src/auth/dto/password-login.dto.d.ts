export declare class PasswordLoginDto {
    phone: string;
    password: string;
}
