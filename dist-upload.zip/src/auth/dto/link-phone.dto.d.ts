export declare class LinkPhoneDto {
    phone: string;
    code: string;
}
