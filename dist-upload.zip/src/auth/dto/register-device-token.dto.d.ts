export declare class RegisterDeviceTokenDto {
    token: string;
    platform: 'android' | 'ios' | 'web';
}
