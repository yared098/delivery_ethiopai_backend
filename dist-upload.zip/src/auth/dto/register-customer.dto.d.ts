export declare class RegisterCustomerDto {
    registrationToken: string;
    name: string;
    email?: string;
    defaultAddress?: string;
    defaultLat?: number;
    defaultLng?: number;
}
