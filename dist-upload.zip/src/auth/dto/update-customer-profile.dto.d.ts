export declare class UpdateCustomerProfileDto {
    name?: string;
    email?: string;
    defaultAddress?: string;
    defaultLat?: number;
    defaultLng?: number;
}
