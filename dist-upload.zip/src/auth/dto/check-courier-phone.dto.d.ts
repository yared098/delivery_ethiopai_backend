export declare class CheckCourierPhoneDto {
    phone: string;
}
