import { ConfigService } from '@nestjs/config';
export interface GoogleProfile {
    googleId: string;
    email: string;
    name?: string;
    picture?: string;
    emailVerified: boolean;
}
export declare class GoogleService {
    private config;
    private client;
    constructor(config: ConfigService);
    verifyIdToken(idToken: string): Promise<GoogleProfile>;
}
