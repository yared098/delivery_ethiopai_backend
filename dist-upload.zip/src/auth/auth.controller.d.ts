import { AuthService } from './auth.service';
import { RequestOtpDto } from './dto/request-otp.dto';
import { VerifyOtpDto } from './dto/verify-otp.dto';
import { RefreshTokenDto } from './dto/refresh-token.dto';
import { UpdateCustomerProfileDto } from './dto/update-customer-profile.dto';
import { RegisterCustomerDto } from './dto/register-customer.dto';
import { RegisterDeviceTokenDto } from './dto/register-device-token.dto';
import { CheckCourierPhoneDto } from './dto/check-courier-phone.dto';
declare class StaffLoginStep1Dto {
    phone: string;
    password: string;
}
declare class StaffLoginStep2Dto {
    tempToken: string;
    code: string;
}
export declare class AuthController {
    private auth;
    constructor(auth: AuthService);
    superAdminRequestOtp(dto: RequestOtpDto): Promise<{
        message: string;
    }>;
    superAdminVerifyOtp(dto: VerifyOtpDto, req: any): Promise<{
        accessToken: string;
        refreshToken: string;
        account: {
            id: any;
            phone: any;
            name: any;
            email: any;
            role: any;
            regionId: any;
            branchId: any;
            phoneVerified: any;
            mustChangePassword: any;
        };
        accountType: "STAFF";
    }>;
    staffLogin(dto: StaffLoginStep1Dto): Promise<{
        requiresOtp: boolean;
        tempToken: `${string}-${string}-${string}-${string}-${string}`;
        phone: string;
        maskedPhone: string;
        message: string;
    }>;
    staffLoginVerify(dto: StaffLoginStep2Dto, req: any): Promise<{
        accessToken: string;
        refreshToken: string;
        account: {
            id: any;
            phone: any;
            name: any;
            email: any;
            role: any;
            regionId: any;
            branchId: any;
            phoneVerified: any;
            mustChangePassword: any;
        };
        accountType: "STAFF";
        mustChangePassword: boolean;
    }>;
    courierRequestOtp(dto: RequestOtpDto): Promise<{
        message: string;
    }>;
    courierVerifyOtp(dto: VerifyOtpDto, req: any): Promise<{
        accessToken: string;
        refreshToken: string;
        account: {
            id: any;
            phone: any;
            name: any;
            email: any;
            regionId: any;
            branchId: any;
            vehicleType: any;
            status: any;
            rating: any;
            totalDeliveries: any;
            phoneVerified: any;
        };
        accountType: "COURIER";
    }>;
    customerRequestOtp(dto: RequestOtpDto): Promise<{
        message: string;
        phone: string;
        isNewUser: boolean;
    }>;
    customerVerifyOtp(dto: VerifyOtpDto, req: any): Promise<{
        accessToken: string;
        refreshToken: string;
        isNewUser: boolean;
        account: {
            id: any;
            phone: any;
            name: any;
            email: any;
            phoneVerified: any;
        };
        accountType: "CUSTOMER";
        requiresRegistration?: undefined;
        registrationToken?: undefined;
        phone?: undefined;
        message?: undefined;
    } | {
        isNewUser: boolean;
        requiresRegistration: boolean;
        registrationToken: `${string}-${string}-${string}-${string}-${string}`;
        phone: string;
        message: string;
    }>;
    customerRegister(dto: RegisterCustomerDto, req: any): Promise<{
        accessToken: string;
        refreshToken: string;
        isNewUser: boolean;
        account: {
            id: any;
            phone: any;
            name: any;
            email: any;
            phoneVerified: any;
        };
        accountType: "CUSTOMER";
    }>;
    refresh(dto: RefreshTokenDto, req: any): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    logout(dto: RefreshTokenDto): Promise<{
        message: string;
    }>;
    getCustomerProfile(customer: any): Promise<{
        id: string;
        phone: string;
        name: string | null;
        email: string | null;
        defaultAddress: string | null;
        defaultLat: number | null;
        defaultLng: number | null;
        phoneVerified: boolean;
        createdAt: Date;
    }>;
    updateCustomerProfile(customer: any, dto: UpdateCustomerProfileDto): Promise<{
        id: any;
        phone: any;
        name: any;
        email: any;
        phoneVerified: any;
    }>;
    logoutAll(user: any): Promise<{
        message: string;
    }>;
    private meta;
    registerDeviceToken(customer: any, dto: RegisterDeviceTokenDto): Promise<{
        id: string;
        token: string;
        platform: string;
    }>;
    removeDeviceToken(customer: any, dto: RegisterDeviceTokenDto): Promise<{
        message: string;
    }>;
    checkCourierPhone(dto: CheckCourierPhoneDto): Promise<{
        phone: string;
        isCourier: boolean;
        exists: boolean;
        message: string;
        name?: undefined;
        status?: undefined;
        isActive?: undefined;
        phoneVerified?: undefined;
        vehicleType?: undefined;
        regionId?: undefined;
        branchId?: undefined;
        canLogin?: undefined;
    } | {
        phone: string;
        isCourier: boolean;
        exists: boolean;
        name: string;
        status: import("@prisma/client").$Enums.CourierStatus;
        isActive: boolean;
        phoneVerified: boolean;
        vehicleType: import("@prisma/client").$Enums.VehicleType;
        regionId: string;
        branchId: string;
        canLogin: boolean;
        message?: undefined;
    }>;
    registerCourierDeviceToken(courier: any, dto: RegisterDeviceTokenDto): Promise<{
        id: string;
        token: string;
        platform: string;
    }>;
    removeCourierDeviceToken(courier: any, dto: RegisterDeviceTokenDto): Promise<{
        message: string;
    }>;
}
export {};
