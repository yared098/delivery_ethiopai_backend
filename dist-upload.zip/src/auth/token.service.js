"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TokenService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const config_1 = require("@nestjs/config");
const prisma_service_1 = require("../prisma/prisma.service");
const client_1 = require("@prisma/client");
const argon2 = __importStar(require("argon2"));
const crypto_1 = require("crypto");
const REFRESH_TTL_MS = 30 * 24 * 60 * 60 * 1000;
let TokenService = class TokenService {
    constructor(jwt, config, prisma) {
        this.jwt = jwt;
        this.config = config;
        this.prisma = prisma;
    }
    async issueTokens(payload, meta) {
        const family = (0, crypto_1.randomUUID)();
        const accessToken = await this.jwt.signAsync({ ...payload, family }, {
            secret: this.config.get('JWT_ACCESS_SECRET'),
            expiresIn: this.config.get('JWT_ACCESS_EXPIRES'),
        });
        const refreshToken = await this.jwt.signAsync({ sub: payload.sub, accountType: payload.accountType, family }, {
            secret: this.config.get('JWT_REFRESH_SECRET'),
            expiresIn: this.config.get('JWT_REFRESH_EXPIRES'),
        });
        const tokenHash = await argon2.hash(refreshToken);
        const data = {
            accountId: payload.sub,
            accountType: payload.accountType,
            tokenHash,
            family,
            userAgent: meta.userAgent,
            ipAddress: meta.ipAddress,
            expiresAt: new Date(Date.now() + REFRESH_TTL_MS),
        };
        if (payload.accountType === client_1.AccountType.STAFF)
            data.staffId = payload.sub;
        if (payload.accountType === client_1.AccountType.COURIER)
            data.courierId = payload.sub;
        if (payload.accountType === client_1.AccountType.CUSTOMER)
            data.customerId = payload.sub;
        await this.prisma.$transaction(async (tx) => {
            await this.lockAccount(tx, payload.sub, payload.accountType);
            await tx.refreshToken.updateMany({
                where: {
                    accountId: payload.sub,
                    accountType: payload.accountType,
                    revokedAt: null,
                },
                data: { revokedAt: new Date() },
            });
            await tx.refreshToken.create({ data });
        });
        return { accessToken, refreshToken };
    }
    async isSessionActive(accountId, accountType, family) {
        if (!family)
            return false;
        const activeToken = await this.prisma.refreshToken.findFirst({
            where: {
                accountId,
                accountType,
                family,
                revokedAt: null,
                expiresAt: { gt: new Date() },
            },
            select: { id: true },
        });
        return activeToken !== null;
    }
    async lockAccount(tx, accountId, accountType) {
        if (accountType === client_1.AccountType.STAFF) {
            await tx.$queryRaw `SELECT id FROM "staff" WHERE id = ${accountId} FOR UPDATE`;
        }
        else if (accountType === client_1.AccountType.COURIER) {
            await tx.$queryRaw `SELECT id FROM "couriers" WHERE id = ${accountId} FOR UPDATE`;
        }
        else {
            await tx.$queryRaw `SELECT id FROM "customers" WHERE id = ${accountId} FOR UPDATE`;
        }
    }
    async rotate(refreshToken, meta) {
        let decoded;
        try {
            decoded = await this.jwt.verifyAsync(refreshToken, {
                secret: this.config.get('JWT_REFRESH_SECRET'),
            });
        }
        catch {
            throw new common_1.UnauthorizedException('Invalid refresh token');
        }
        const familyTokens = await this.prisma.refreshToken.findMany({
            where: { family: decoded.family },
            orderBy: { createdAt: 'desc' },
        });
        if (!familyTokens.length) {
            throw new common_1.UnauthorizedException('Token family not found');
        }
        let matched = null;
        for (const t of familyTokens) {
            if (await argon2.verify(t.tokenHash, refreshToken)) {
                matched = t;
                break;
            }
        }
        if (!matched || matched.revokedAt) {
            await this.prisma.refreshToken.updateMany({
                where: { family: decoded.family, revokedAt: null },
                data: { revokedAt: new Date() },
            });
            throw new common_1.UnauthorizedException('Refresh token reuse detected — session revoked');
        }
        if (matched.expiresAt < new Date()) {
            throw new common_1.UnauthorizedException('Refresh token expired');
        }
        await this.prisma.refreshToken.update({
            where: { id: matched.id },
            data: { revokedAt: new Date() },
        });
        let payload = null;
        if (matched.accountType === client_1.AccountType.STAFF) {
            const account = await this.prisma.staff.findUnique({
                where: { id: matched.accountId },
            });
            if (account && account.isActive) {
                payload = {
                    sub: account.id,
                    accountType: client_1.AccountType.STAFF,
                    role: account.role,
                    regionId: account.regionId,
                    branchId: account.branchId,
                };
            }
        }
        else if (matched.accountType === client_1.AccountType.COURIER) {
            const account = await this.prisma.courier.findUnique({
                where: { id: matched.accountId },
            });
            if (account && account.isActive) {
                payload = {
                    sub: account.id,
                    accountType: client_1.AccountType.COURIER,
                    regionId: account.regionId,
                    branchId: account.branchId,
                };
            }
        }
        else if (matched.accountType === client_1.AccountType.CUSTOMER) {
            const account = await this.prisma.customer.findUnique({
                where: { id: matched.accountId },
            });
            if (account && account.isActive) {
                payload = {
                    sub: account.id,
                    accountType: client_1.AccountType.CUSTOMER,
                };
            }
        }
        if (!payload) {
            throw new common_1.UnauthorizedException('Account inactive');
        }
        const newAccess = await this.jwt.signAsync({ ...payload, family: decoded.family }, {
            secret: this.config.get('JWT_ACCESS_SECRET'),
            expiresIn: this.config.get('JWT_ACCESS_EXPIRES'),
        });
        const newRefresh = await this.jwt.signAsync({ sub: payload.sub, accountType: payload.accountType, family: decoded.family }, {
            secret: this.config.get('JWT_REFRESH_SECRET'),
            expiresIn: this.config.get('JWT_REFRESH_EXPIRES'),
        });
        const newHash = await argon2.hash(newRefresh);
        const newData = {
            accountId: payload.sub,
            accountType: payload.accountType,
            tokenHash: newHash,
            family: decoded.family,
            userAgent: meta.userAgent,
            ipAddress: meta.ipAddress,
            expiresAt: new Date(Date.now() + REFRESH_TTL_MS),
        };
        if (payload.accountType === client_1.AccountType.STAFF)
            newData.staffId = payload.sub;
        if (payload.accountType === client_1.AccountType.COURIER)
            newData.courierId = payload.sub;
        if (payload.accountType === client_1.AccountType.CUSTOMER)
            newData.customerId = payload.sub;
        await this.prisma.refreshToken.create({ data: newData });
        return { accessToken: newAccess, refreshToken: newRefresh };
    }
    async revokeAll(accountId, accountType) {
        await this.prisma.refreshToken.updateMany({
            where: { accountId, accountType, revokedAt: null },
            data: { revokedAt: new Date() },
        });
    }
    async revokeByRefreshToken(refreshToken) {
        try {
            const decoded = await this.jwt.verifyAsync(refreshToken, {
                secret: this.config.get('JWT_REFRESH_SECRET'),
            });
            await this.prisma.refreshToken.updateMany({
                where: { family: decoded.family, revokedAt: null },
                data: { revokedAt: new Date() },
            });
        }
        catch {
        }
    }
};
exports.TokenService = TokenService;
exports.TokenService = TokenService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [jwt_1.JwtService,
        config_1.ConfigService,
        prisma_service_1.PrismaService])
], TokenService);
//# sourceMappingURL=token.service.js.map