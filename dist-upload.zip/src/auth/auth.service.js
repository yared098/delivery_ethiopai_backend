"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const argon2 = __importStar(require("argon2"));
const crypto_1 = require("crypto");
const ioredis_1 = require("ioredis");
const otp_service_1 = require("./otp.service");
const token_service_1 = require("./token.service");
const prisma_service_1 = require("../prisma/prisma.service");
const config_1 = require("@nestjs/config");
const notifications_service_1 = require("../notifications/notifications.service");
const client_1 = require("@prisma/client");
let AuthService = class AuthService {
    constructor(otp, tokens, prisma, config, notifications) {
        this.otp = otp;
        this.tokens = tokens;
        this.prisma = prisma;
        this.config = config;
        this.notifications = notifications;
        this.redis = new ioredis_1.Redis(this.config.get('REDIS_URL'));
    }
    normalizePhone(phone) {
        const digits = phone.replace(/\D/g, '');
        if (digits.startsWith('251') && digits.length === 12)
            return digits;
        if (digits.startsWith('0') && digits.length === 10)
            return '251' + digits.slice(1);
        if (digits.length === 9)
            return '251' + digits;
        return '251' + digits;
    }
    async requestSuperAdminOtp(phone) {
        const normalized = this.normalizePhone(phone);
        const staff = await this.prisma.staff.findUnique({ where: { phone: normalized } });
        if (!staff)
            throw new common_1.NotFoundException('No staff account with this phone');
        if (!staff.isActive)
            throw new common_1.UnauthorizedException('Account suspended');
        if (staff.role !== client_1.StaffRole.SUPER_ADMIN) {
            throw new common_1.ForbiddenException('Only Super Admin uses this login. Staff must use phone + password.');
        }
        await this.otp.requestOtp(phone, client_1.AccountType.STAFF, 'login', { staffId: staff.id });
        return { message: 'OTP sent' };
    }
    async verifySuperAdminOtp(phone, code, meta) {
        const normalized = await this.otp.verifyOtp(phone, code, client_1.AccountType.STAFF, 'login');
        const staff = await this.prisma.staff.findUnique({ where: { phone: normalized } });
        if (!staff)
            throw new common_1.UnauthorizedException('Staff not found');
        if (!staff.isActive)
            throw new common_1.UnauthorizedException('Account suspended');
        if (staff.role !== client_1.StaffRole.SUPER_ADMIN) {
            throw new common_1.UnauthorizedException('Not a Super Admin account');
        }
        if (!staff.phoneVerified) {
            await this.prisma.staff.update({
                where: { id: staff.id },
                data: { phoneVerified: true },
            });
        }
        const tokens = await this.tokens.issueTokens({
            sub: staff.id,
            accountType: client_1.AccountType.STAFF,
            role: staff.role,
            regionId: staff.regionId,
            branchId: staff.branchId,
        }, meta);
        return { account: this.publicStaff(staff), accountType: client_1.AccountType.STAFF, ...tokens };
    }
    async staffLoginStep1(phone, password) {
        const normalized = this.normalizePhone(phone);
        const staff = await this.prisma.staff.findUnique({ where: { phone: normalized } });
        if (!staff) {
            throw new common_1.UnauthorizedException('Invalid phone or password');
        }
        if (!staff.isActive) {
            throw new common_1.UnauthorizedException('Account suspended. Contact Super Admin.');
        }
        if (staff.role === client_1.StaffRole.SUPER_ADMIN) {
            throw new common_1.ForbiddenException('Super Admin uses OTP-only login. Use the Super Admin tab.');
        }
        if (!staff.passwordHash) {
            throw new common_1.UnauthorizedException('No password set. Contact Super Admin to set your password.');
        }
        const valid = await argon2.verify(staff.passwordHash, password);
        if (!valid) {
            throw new common_1.UnauthorizedException('Invalid phone or password');
        }
        const tempToken = (0, crypto_1.randomUUID)();
        await this.redis.setex(`staff:login:${tempToken}`, 300, JSON.stringify({
            staffId: staff.id,
            phone: normalized,
            createdAt: Date.now(),
        }));
        await this.otp.requestOtp(phone, client_1.AccountType.STAFF, 'login', { staffId: staff.id });
        return {
            requiresOtp: true,
            tempToken,
            phone: normalized,
            maskedPhone: this.maskPhone(normalized),
            message: 'OTP sent to your phone',
        };
    }
    async staffLoginStep2(tempToken, code, meta) {
        const stored = await this.redis.get(`staff:login:${tempToken}`);
        if (!stored) {
            throw new common_1.UnauthorizedException('Login session expired. Please try again.');
        }
        const { staffId, phone } = JSON.parse(stored);
        await this.otp.verifyOtp(phone, code, client_1.AccountType.STAFF, 'login');
        const staff = await this.prisma.staff.findUnique({ where: { id: staffId } });
        if (!staff)
            throw new common_1.UnauthorizedException('Staff not found');
        if (!staff.isActive)
            throw new common_1.UnauthorizedException('Account suspended');
        await this.redis.del(`staff:login:${tempToken}`);
        if (!staff.phoneVerified) {
            await this.prisma.staff.update({
                where: { id: staff.id },
                data: { phoneVerified: true },
            });
        }
        const tokens = await this.tokens.issueTokens({
            sub: staff.id,
            accountType: client_1.AccountType.STAFF,
            role: staff.role,
            regionId: staff.regionId,
            branchId: staff.branchId,
        }, meta);
        return {
            account: this.publicStaff(staff),
            accountType: client_1.AccountType.STAFF,
            mustChangePassword: staff.mustChangePassword,
            ...tokens,
        };
    }
    async requestCourierOtp(phone) {
        const normalized = this.normalizePhone(phone);
        const courier = await this.prisma.courier.findUnique({ where: { phone: normalized } });
        if (!courier)
            throw new common_1.NotFoundException('No courier account with this phone');
        if (!courier.isActive)
            throw new common_1.UnauthorizedException('Courier suspended');
        if (courier.status !== client_1.CourierStatus.APPROVED) {
            throw new common_1.UnauthorizedException(`Courier account is ${courier.status}`);
        }
        await this.otp.requestOtp(phone, client_1.AccountType.COURIER, 'login', { courierId: courier.id });
        return { message: 'OTP sent' };
    }
    async verifyCourierOtp(phone, code, meta) {
        const normalized = await this.otp.verifyOtp(phone, code, client_1.AccountType.COURIER, 'login');
        const courier = await this.prisma.courier.findUnique({ where: { phone: normalized } });
        if (!courier)
            throw new common_1.UnauthorizedException('Courier not found');
        if (!courier.isActive)
            throw new common_1.UnauthorizedException('Courier suspended');
        if (courier.status !== client_1.CourierStatus.APPROVED) {
            throw new common_1.UnauthorizedException(`Courier status: ${courier.status}`);
        }
        if (!courier.phoneVerified) {
            await this.prisma.courier.update({
                where: { id: courier.id },
                data: { phoneVerified: true },
            });
        }
        const tokens = await this.tokens.issueTokens({
            sub: courier.id,
            accountType: client_1.AccountType.COURIER,
            regionId: courier.regionId,
            branchId: courier.branchId,
        }, meta);
        return { account: this.publicCourier(courier), accountType: client_1.AccountType.COURIER, ...tokens };
    }
    async registerCustomerDeviceToken(customerId, token, platform) {
        const now = new Date();
        try {
            const record = await this.prisma.deviceToken.upsert({
                where: { token },
                update: {
                    customerId,
                    courierId: null,
                    staffId: null,
                    platform,
                    accountType: client_1.AccountType.CUSTOMER,
                    isActive: true,
                    lastUsedAt: now,
                },
                create: {
                    token,
                    platform,
                    accountType: client_1.AccountType.CUSTOMER,
                    customerId,
                    isActive: true,
                    lastUsedAt: now,
                },
            });
            return { id: record.id, token: record.token, platform: record.platform };
        }
        catch (e) {
            if (e instanceof client_1.Prisma.PrismaClientKnownRequestError &&
                e.code === 'P2002') {
                const record = await this.prisma.deviceToken.update({
                    where: { token },
                    data: {
                        customerId,
                        courierId: null,
                        staffId: null,
                        platform,
                        accountType: client_1.AccountType.CUSTOMER,
                        isActive: true,
                        lastUsedAt: now,
                    },
                });
                return { id: record.id, token: record.token, platform: record.platform };
            }
            throw e;
        }
    }
    async removeCustomerDeviceToken(customerId, token) {
        await this.prisma.deviceToken.updateMany({
            where: { customerId, token },
            data: { isActive: false },
        });
        return { message: 'Device token removed' };
    }
    async requestCustomerOtp(phone) {
        const normalized = this.normalizePhone(phone);
        await this.otp.requestOtp(phone, client_1.AccountType.CUSTOMER, 'login');
        const existing = await this.prisma.customer.findUnique({
            where: { phone: normalized },
        });
        return {
            message: 'OTP sent',
            phone: normalized,
            isNewUser: !existing,
        };
    }
    async verifyCustomerOtp(phone, code, meta) {
        const normalized = await this.otp.verifyOtp(phone, code, client_1.AccountType.CUSTOMER, 'login');
        const customer = await this.prisma.customer.findUnique({
            where: { phone: normalized },
        });
        if (customer) {
            if (!customer.isActive) {
                throw new common_1.UnauthorizedException('Account disabled');
            }
            if (!customer.phoneVerified) {
                await this.prisma.customer.update({
                    where: { id: customer.id },
                    data: { phoneVerified: true },
                });
            }
            const tokens = await this.tokens.issueTokens({ sub: customer.id, accountType: client_1.AccountType.CUSTOMER }, meta);
            return {
                isNewUser: false,
                account: this.publicCustomer(customer),
                accountType: client_1.AccountType.CUSTOMER,
                ...tokens,
            };
        }
        const registrationToken = (0, crypto_1.randomUUID)();
        await this.redis.setex(`customer:register:${registrationToken}`, 600, JSON.stringify({ phone: normalized, verifiedAt: Date.now() }));
        return {
            isNewUser: true,
            requiresRegistration: true,
            registrationToken,
            phone: normalized,
            message: 'OTP verified. Complete your profile to finish registration.',
        };
    }
    async registerCustomer(registrationToken, dto, meta) {
        const stored = await this.redis.get(`customer:register:${registrationToken}`);
        if (!stored) {
            throw new common_1.UnauthorizedException('Registration session expired. Please verify OTP again.');
        }
        const { phone } = JSON.parse(stored);
        const existing = await this.prisma.customer.findUnique({ where: { phone } });
        if (existing) {
            await this.redis.del(`customer:register:${registrationToken}`);
            const tokens = await this.tokens.issueTokens({ sub: existing.id, accountType: client_1.AccountType.CUSTOMER }, meta);
            return {
                isNewUser: false,
                account: this.publicCustomer(existing),
                accountType: client_1.AccountType.CUSTOMER,
                ...tokens,
            };
        }
        const name = (dto.name || '').trim();
        if (name.length < 2) {
            throw new common_1.BadRequestException('Name is required (min 2 chars)');
        }
        const customer = await this.prisma.customer.create({
            data: {
                phone,
                name,
                email: dto.email || null,
                defaultAddress: dto.defaultAddress || null,
                defaultLat: dto.defaultLat ?? null,
                defaultLng: dto.defaultLng ?? null,
                phoneVerified: true,
                registeredByType: client_1.AccountType.CUSTOMER,
            },
        });
        await this.redis.del(`customer:register:${registrationToken}`);
        const tokens = await this.tokens.issueTokens({ sub: customer.id, accountType: client_1.AccountType.CUSTOMER }, meta);
        return {
            isNewUser: true,
            account: this.publicCustomer(customer),
            accountType: client_1.AccountType.CUSTOMER,
            ...tokens,
        };
    }
    async refresh(refreshToken, meta) {
        return this.tokens.rotate(refreshToken, meta);
    }
    async logout(refreshToken) {
        await this.tokens.revokeByRefreshToken(refreshToken);
        return { message: 'Logged out' };
    }
    async logoutAll(accountId, accountType) {
        await this.tokens.revokeAll(accountId, accountType);
        return { message: 'All sessions revoked' };
    }
    maskPhone(phone) {
        if (phone.length < 6)
            return phone;
        return phone.slice(0, 4) + '****' + phone.slice(-2);
    }
    publicStaff(s) {
        return {
            id: s.id,
            phone: s.phone,
            name: s.name,
            email: s.email,
            role: s.role,
            regionId: s.regionId,
            branchId: s.branchId,
            phoneVerified: s.phoneVerified,
            mustChangePassword: s.mustChangePassword,
        };
    }
    publicCourier(c) {
        return {
            id: c.id,
            phone: c.phone,
            name: c.name,
            email: c.email,
            regionId: c.regionId,
            branchId: c.branchId,
            vehicleType: c.vehicleType,
            status: c.status,
            rating: c.rating,
            totalDeliveries: c.totalDeliveries,
            phoneVerified: c.phoneVerified,
        };
    }
    publicCustomer(c) {
        return {
            id: c.id,
            phone: c.phone,
            name: c.name,
            email: c.email,
            phoneVerified: c.phoneVerified,
        };
    }
    async getCustomerProfile(customerId) {
        const c = await this.prisma.customer.findUnique({ where: { id: customerId } });
        if (!c)
            throw new common_1.UnauthorizedException('Customer not found');
        return {
            id: c.id,
            phone: c.phone,
            name: c.name,
            email: c.email,
            defaultAddress: c.defaultAddress,
            defaultLat: c.defaultLat,
            defaultLng: c.defaultLng,
            phoneVerified: c.phoneVerified,
            createdAt: c.createdAt,
        };
    }
    async updateCustomerProfile(customerId, dto) {
        const data = {};
        if (dto.name !== undefined)
            data.name = dto.name;
        if (dto.email !== undefined)
            data.email = dto.email;
        if (dto.defaultAddress !== undefined)
            data.defaultAddress = dto.defaultAddress;
        if (dto.defaultLat !== undefined)
            data.defaultLat = dto.defaultLat;
        if (dto.defaultLng !== undefined)
            data.defaultLng = dto.defaultLng;
        const updated = await this.prisma.customer.update({
            where: { id: customerId },
            data,
        });
        return this.publicCustomer(updated);
    }
    async checkCourierPhone(rawPhone) {
        const phone = this.normalizePhone(rawPhone);
        const courier = await this.prisma.courier.findUnique({
            where: { phone },
            select: {
                id: true,
                phone: true,
                name: true,
                status: true,
                isActive: true,
                phoneVerified: true,
                vehicleType: true,
                regionId: true,
                branchId: true,
            },
        });
        if (!courier) {
            return {
                phone,
                isCourier: false,
                exists: false,
                message: 'No courier account with this phone',
            };
        }
        return {
            phone,
            isCourier: true,
            exists: true,
            name: courier.name,
            status: courier.status,
            isActive: courier.isActive,
            phoneVerified: courier.phoneVerified,
            vehicleType: courier.vehicleType,
            regionId: courier.regionId,
            branchId: courier.branchId,
            canLogin: courier.isActive && courier.status === 'APPROVED',
        };
    }
    async registerCourierDeviceToken(courierId, token, platform) {
        const now = new Date();
        try {
            const record = await this.prisma.deviceToken.upsert({
                where: { token },
                update: {
                    courierId,
                    customerId: null,
                    staffId: null,
                    platform,
                    accountType: client_1.AccountType.COURIER,
                    isActive: true,
                    lastUsedAt: now,
                },
                create: {
                    token,
                    platform,
                    accountType: client_1.AccountType.COURIER,
                    courierId,
                    isActive: true,
                    lastUsedAt: now,
                },
            });
            return { id: record.id, token: record.token, platform: record.platform };
        }
        catch (e) {
            if (e instanceof client_1.Prisma.PrismaClientKnownRequestError &&
                e.code === 'P2002') {
                const record = await this.prisma.deviceToken.update({
                    where: { token },
                    data: {
                        courierId,
                        customerId: null,
                        staffId: null,
                        platform,
                        accountType: client_1.AccountType.COURIER,
                        isActive: true,
                        lastUsedAt: now,
                    },
                });
                return { id: record.id, token: record.token, platform: record.platform };
            }
            throw e;
        }
    }
    async removeCourierDeviceToken(courierId, token) {
        await this.prisma.deviceToken.updateMany({
            where: { courierId, token },
            data: { isActive: false },
        });
        return { message: 'Device token removed' };
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [otp_service_1.OtpService,
        token_service_1.TokenService,
        prisma_service_1.PrismaService,
        config_1.ConfigService,
        notifications_service_1.NotificationsService])
], AuthService);
//# sourceMappingURL=auth.service.js.map