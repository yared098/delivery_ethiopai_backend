import { OtpService } from './otp.service';
import { TokenService } from './token.service';
import { PrismaService } from '../prisma/prisma.service';
import { ConfigService } from '@nestjs/config';
import { NotificationsService } from 'src/notifications/notifications.service';
import { AccountType } from '@prisma/client';
interface Meta {
    userAgent?: string;
    ipAddress?: string;
}
export declare class AuthService {
    private otp;
    private tokens;
    private prisma;
    private config;
    private notifications;
    private redis;
    constructor(otp: OtpService, tokens: TokenService, prisma: PrismaService, config: ConfigService, notifications: NotificationsService);
    private normalizePhone;
    requestSuperAdminOtp(phone: string): Promise<{
        message: string;
    }>;
    verifySuperAdminOtp(phone: string, code: string, meta: Meta): Promise<{
        accessToken: string;
        refreshToken: string;
        account: {
            id: any;
            phone: any;
            name: any;
            email: any;
            role: any;
            regionId: any;
            branchId: any;
            phoneVerified: any;
            mustChangePassword: any;
        };
        accountType: "STAFF";
    }>;
    staffLoginStep1(phone: string, password: string): Promise<{
        requiresOtp: boolean;
        tempToken: `${string}-${string}-${string}-${string}-${string}`;
        phone: string;
        maskedPhone: string;
        message: string;
    }>;
    staffLoginStep2(tempToken: string, code: string, meta: Meta): Promise<{
        accessToken: string;
        refreshToken: string;
        account: {
            id: any;
            phone: any;
            name: any;
            email: any;
            role: any;
            regionId: any;
            branchId: any;
            phoneVerified: any;
            mustChangePassword: any;
        };
        accountType: "STAFF";
        mustChangePassword: boolean;
    }>;
    requestCourierOtp(phone: string): Promise<{
        message: string;
    }>;
    verifyCourierOtp(phone: string, code: string, meta: Meta): Promise<{
        accessToken: string;
        refreshToken: string;
        account: {
            id: any;
            phone: any;
            name: any;
            email: any;
            regionId: any;
            branchId: any;
            vehicleType: any;
            status: any;
            rating: any;
            totalDeliveries: any;
            phoneVerified: any;
        };
        accountType: "COURIER";
    }>;
    registerCustomerDeviceToken(customerId: string, token: string, platform: 'android' | 'ios' | 'web'): Promise<{
        id: string;
        token: string;
        platform: string;
    }>;
    removeCustomerDeviceToken(customerId: string, token: string): Promise<{
        message: string;
    }>;
    requestCustomerOtp(phone: string): Promise<{
        message: string;
        phone: string;
        isNewUser: boolean;
    }>;
    verifyCustomerOtp(phone: string, code: string, meta: Meta): Promise<{
        accessToken: string;
        refreshToken: string;
        isNewUser: boolean;
        account: {
            id: any;
            phone: any;
            name: any;
            email: any;
            phoneVerified: any;
        };
        accountType: "CUSTOMER";
        requiresRegistration?: undefined;
        registrationToken?: undefined;
        phone?: undefined;
        message?: undefined;
    } | {
        isNewUser: boolean;
        requiresRegistration: boolean;
        registrationToken: `${string}-${string}-${string}-${string}-${string}`;
        phone: string;
        message: string;
    }>;
    registerCustomer(registrationToken: string, dto: {
        name: string;
        email?: string;
        defaultAddress?: string;
        defaultLat?: number;
        defaultLng?: number;
    }, meta: Meta): Promise<{
        accessToken: string;
        refreshToken: string;
        isNewUser: boolean;
        account: {
            id: any;
            phone: any;
            name: any;
            email: any;
            phoneVerified: any;
        };
        accountType: "CUSTOMER";
    }>;
    refresh(refreshToken: string, meta: Meta): Promise<{
        accessToken: string;
        refreshToken: string;
    }>;
    logout(refreshToken: string): Promise<{
        message: string;
    }>;
    logoutAll(accountId: string, accountType: AccountType): Promise<{
        message: string;
    }>;
    private maskPhone;
    private publicStaff;
    private publicCourier;
    private publicCustomer;
    getCustomerProfile(customerId: string): Promise<{
        id: string;
        phone: string;
        name: string | null;
        email: string | null;
        defaultAddress: string | null;
        defaultLat: number | null;
        defaultLng: number | null;
        phoneVerified: boolean;
        createdAt: Date;
    }>;
    updateCustomerProfile(customerId: string, dto: any): Promise<{
        id: any;
        phone: any;
        name: any;
        email: any;
        phoneVerified: any;
    }>;
    checkCourierPhone(rawPhone: string): Promise<{
        phone: string;
        isCourier: boolean;
        exists: boolean;
        message: string;
        name?: undefined;
        status?: undefined;
        isActive?: undefined;
        phoneVerified?: undefined;
        vehicleType?: undefined;
        regionId?: undefined;
        branchId?: undefined;
        canLogin?: undefined;
    } | {
        phone: string;
        isCourier: boolean;
        exists: boolean;
        name: string;
        status: import("@prisma/client").$Enums.CourierStatus;
        isActive: boolean;
        phoneVerified: boolean;
        vehicleType: import("@prisma/client").$Enums.VehicleType;
        regionId: string;
        branchId: string;
        canLogin: boolean;
        message?: undefined;
    }>;
    registerCourierDeviceToken(courierId: string, token: string, platform: 'android' | 'ios' | 'web'): Promise<{
        id: string;
        token: string;
        platform: string;
    }>;
    removeCourierDeviceToken(courierId: string, token: string): Promise<{
        message: string;
    }>;
}
export {};
