import { OnModuleDestroy } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { AfroMessageService } from '../integrations/afromessage/afromessage.service';
import { ConfigService } from '@nestjs/config';
import { AccountType } from '@prisma/client';
export declare class OtpService implements OnModuleDestroy {
    private prisma;
    private sms;
    private config;
    private redis;
    constructor(prisma: PrismaService, sms: AfroMessageService, config: ConfigService);
    onModuleDestroy(): void;
    private normalizePhone;
    requestOtp(rawPhone: string, accountType: AccountType, purpose?: string, extraIds?: {
        staffId?: string;
        courierId?: string;
    }): Promise<void>;
    verifyOtp(rawPhone: string, code: string, accountType: AccountType, purpose?: string): Promise<string>;
}
