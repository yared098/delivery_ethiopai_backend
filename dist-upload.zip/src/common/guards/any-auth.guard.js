"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnyAuthGuard = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const prisma_service_1 = require("../../prisma/prisma.service");
let AnyAuthGuard = class AnyAuthGuard {
    constructor(jwt, prisma) {
        this.jwt = jwt;
        this.prisma = prisma;
    }
    async canActivate(ctx) {
        const req = ctx.switchToHttp().getRequest();
        const auth = req.headers.authorization;
        if (!auth || !auth.startsWith('Bearer ')) {
            throw new common_1.UnauthorizedException('Missing token');
        }
        const token = auth.slice(7);
        try {
            const payload = this.jwt.verify(token, {
                secret: process.env.JWT_ACCESS_SECRET,
            });
            const { sub, accountType } = payload;
            if (accountType === 'CUSTOMER') {
                const c = await this.prisma.customer.findUnique({ where: { id: sub } });
                if (!c || !c.isActive)
                    throw new common_1.UnauthorizedException('Invalid customer');
                req.customer = c;
            }
            else if (accountType === 'STAFF') {
                const s = await this.prisma.staff.findUnique({ where: { id: sub } });
                if (!s || !s.isActive)
                    throw new common_1.UnauthorizedException('Invalid staff');
                req.staff = s;
            }
            else if (accountType === 'COURIER') {
                const cr = await this.prisma.courier.findUnique({ where: { id: sub } });
                if (!cr || !cr.isActive)
                    throw new common_1.UnauthorizedException('Invalid courier');
                req.courier = cr;
            }
            else {
                throw new common_1.UnauthorizedException('Unknown account type');
            }
            req.user = payload;
            req.accountType = accountType;
            return true;
        }
        catch (e) {
            console.error('🔴 [AnyAuthGuard] FAILED:', {
                message: e.message,
                secretUsed: process.env.JWT_ACCESS_SECRET ? 'defined' : 'UNDEFINED',
                tokenPrefix: token.slice(0, 20),
            });
            throw new common_1.UnauthorizedException(e.message || 'Invalid token');
        }
    }
};
exports.AnyAuthGuard = AnyAuthGuard;
exports.AnyAuthGuard = AnyAuthGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [jwt_1.JwtService,
        prisma_service_1.PrismaService])
], AnyAuthGuard);
//# sourceMappingURL=any-auth.guard.js.map