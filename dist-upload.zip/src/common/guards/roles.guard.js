"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RolesGuard = void 0;
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const client_1 = require("@prisma/client");
const staff_roles_decorator_1 = require("../decorators/staff-roles.decorator");
const account_type_decorator_1 = require("../decorators/account-type.decorator");
let RolesGuard = class RolesGuard {
    constructor(reflector) {
        this.reflector = reflector;
    }
    canActivate(context) {
        const requiredStaffRoles = this.reflector.getAllAndOverride(staff_roles_decorator_1.STAFF_ROLES_KEY, [context.getHandler(), context.getClass()]);
        const requiredAccountTypes = this.reflector.getAllAndOverride(account_type_decorator_1.ACCOUNT_TYPE_KEY, [context.getHandler(), context.getClass()]);
        const { user } = context.switchToHttp().getRequest();
        console.log('🔍 RolesGuard:', {
            url: context.switchToHttp().getRequest().url,
            hasUser: !!user,
            user: user ? { id: user.id, accountType: user.accountType, role: user.role } : null,
            requiredStaffRoles,
            requiredAccountTypes,
        });
        if (!user) {
            throw new common_1.ForbiddenException('Not authenticated');
        }
        if (!requiredStaffRoles?.length && !requiredAccountTypes?.length) {
            return true;
        }
        if (requiredAccountTypes?.length) {
            if (!requiredAccountTypes.includes(user.accountType)) {
                throw new common_1.ForbiddenException(`Wrong account type: need ${requiredAccountTypes.join('/')}, got ${user.accountType}`);
            }
        }
        if (requiredStaffRoles?.length) {
            if (user.accountType !== client_1.AccountType.STAFF) {
                throw new common_1.ForbiddenException(`Staff access only (accountType=${user.accountType})`);
            }
            if (!requiredStaffRoles.includes(user.role)) {
                throw new common_1.ForbiddenException(`Insufficient role: need ${requiredStaffRoles.join('/')}, got ${user.role}`);
            }
        }
        return true;
    }
};
exports.RolesGuard = RolesGuard;
exports.RolesGuard = RolesGuard = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [core_1.Reflector])
], RolesGuard);
//# sourceMappingURL=roles.guard.js.map