"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequireAccount = exports.ACCOUNT_TYPE_KEY = void 0;
const common_1 = require("@nestjs/common");
exports.ACCOUNT_TYPE_KEY = 'accountType';
const RequireAccount = (...types) => (0, common_1.SetMetadata)(exports.ACCOUNT_TYPE_KEY, types);
exports.RequireAccount = RequireAccount;
//# sourceMappingURL=account-type.decorator.js.map