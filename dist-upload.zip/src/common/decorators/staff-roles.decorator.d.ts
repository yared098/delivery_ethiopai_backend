import { StaffRole } from '@prisma/client';
export declare const STAFF_ROLES_KEY = "staffRoles";
export declare const StaffRoles: (...roles: StaffRole[]) => import("@nestjs/common").CustomDecorator<string>;
