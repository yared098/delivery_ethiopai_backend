"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrentCourier = void 0;
const common_1 = require("@nestjs/common");
exports.CurrentCourier = (0, common_1.createParamDecorator)((_data, ctx) => ctx.switchToHttp().getRequest().user);
//# sourceMappingURL=current-courier.decorator.js.map