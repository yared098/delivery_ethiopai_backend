import { AccountType } from '@prisma/client';
export declare const ACCOUNT_TYPE_KEY = "accountType";
export declare const RequireAccount: (...types: AccountType[]) => import("@nestjs/common").CustomDecorator<string>;
