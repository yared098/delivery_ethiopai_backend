"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StaffRoles = exports.STAFF_ROLES_KEY = void 0;
const common_1 = require("@nestjs/common");
exports.STAFF_ROLES_KEY = 'staffRoles';
const StaffRoles = (...roles) => (0, common_1.SetMetadata)(exports.STAFF_ROLES_KEY, roles);
exports.StaffRoles = StaffRoles;
//# sourceMappingURL=staff-roles.decorator.js.map