export declare const CurrentCourier: (...dataOrPipes: unknown[]) => ParameterDecorator;
