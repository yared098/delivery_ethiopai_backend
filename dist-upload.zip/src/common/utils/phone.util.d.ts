export declare function normalizeEthiopianPhone(raw: string | null | undefined): string | null;
export declare function isValidEthiopianPhone(raw: string | null | undefined): boolean;
export declare function toLocalPhone(normalized: string): string;
