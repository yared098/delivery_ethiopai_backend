"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MAX_IMAGE_BYTES = void 0;
exports.compressImage = compressImage;
const sharp_1 = __importDefault(require("sharp"));
exports.MAX_IMAGE_BYTES = 2 * 1024 * 1024;
async function compressImage(inputBuffer, maxBytes = exports.MAX_IMAGE_BYTES) {
    const metadata = await (0, sharp_1.default)(inputBuffer).metadata();
    let width = metadata.width || 1920;
    let height = metadata.height || 1920;
    const maxDim = 1920;
    if (width > maxDim || height > maxDim) {
        if (width >= height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
        }
        else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
        }
    }
    let quality = 85;
    let buffer = await (0, sharp_1.default)(inputBuffer)
        .rotate()
        .resize(width, height, { fit: 'inside', withoutEnlargement: true })
        .jpeg({ quality, progressive: true, mozjpeg: true })
        .toBuffer();
    while (buffer.length > maxBytes && quality > 20) {
        quality -= 15;
        width = Math.round(width * 0.85);
        height = Math.round(height * 0.85);
        buffer = await (0, sharp_1.default)(inputBuffer)
            .rotate()
            .resize(width, height, { fit: 'inside', withoutEnlargement: true })
            .jpeg({ quality, progressive: true, mozjpeg: true })
            .toBuffer();
    }
    return buffer;
}
//# sourceMappingURL=image.util.js.map