export declare const MAX_IMAGE_BYTES: number;
export declare function compressImage(inputBuffer: Buffer, maxBytes?: number): Promise<Buffer>;
