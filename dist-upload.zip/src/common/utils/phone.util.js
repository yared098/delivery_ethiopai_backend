"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeEthiopianPhone = normalizeEthiopianPhone;
exports.isValidEthiopianPhone = isValidEthiopianPhone;
exports.toLocalPhone = toLocalPhone;
const ETHIOPIAN_COUNTRY_CODE = '251';
const MOBILE_PREFIX = '9';
const LOCAL_MOBILE_LENGTH = 10;
const NATIONAL_MOBILE_LENGTH = 9;
const INTERNATIONAL_MOBILE_LENGTH = 12;
function normalizeEthiopianPhone(raw) {
    if (!raw)
        return null;
    const digits = raw.replace(/\D/g, '');
    if (digits.length === INTERNATIONAL_MOBILE_LENGTH && digits.startsWith(ETHIOPIAN_COUNTRY_CODE + MOBILE_PREFIX)) {
        return digits;
    }
    if (digits.length === LOCAL_MOBILE_LENGTH && digits.startsWith('0' + MOBILE_PREFIX)) {
        return ETHIOPIAN_COUNTRY_CODE + digits.slice(1);
    }
    if (digits.length === NATIONAL_MOBILE_LENGTH && digits.startsWith(MOBILE_PREFIX)) {
        return ETHIOPIAN_COUNTRY_CODE + digits;
    }
    return null;
}
function isValidEthiopianPhone(raw) {
    return normalizeEthiopianPhone(raw) !== null;
}
function toLocalPhone(normalized) {
    if (normalized.startsWith(ETHIOPIAN_COUNTRY_CODE) && normalized.length === INTERNATIONAL_MOBILE_LENGTH) {
        return '0' + normalized.slice(ETHIOPIAN_COUNTRY_CODE.length);
    }
    return normalized;
}
//# sourceMappingURL=phone.util.js.map