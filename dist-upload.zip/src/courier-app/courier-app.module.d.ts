export declare class CourierAppModule {
}
