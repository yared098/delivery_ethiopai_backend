"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CourierAppController = void 0;
const common_1 = require("@nestjs/common");
const courier_app_service_1 = require("./courier-app.service");
const courier_jwt_guard_1 = require("../common/guards/courier-jwt.guard");
const current_courier_decorator_1 = require("../common/decorators/current-courier.decorator");
const update_courier_profile_dto_1 = require("./dto/update-courier-profile.dto");
const update_courier_location_dto_1 = require("./dto/update-courier-location.dto");
const toggle_online_dto_1 = require("./dto/toggle-online.dto");
const scan_qr_dto_1 = require("./dto/scan-qr.dto");
const scan_deliver_dto_1 = require("./dto/scan-deliver.dto");
const client_1 = require("@prisma/client");
let CourierAppController = class CourierAppController {
    constructor(courier) {
        this.courier = courier;
    }
    getMe(c) {
        return this.courier.getMe(c.id);
    }
    updateMe(c, dto) {
        return this.courier.updateMe(c.id, dto);
    }
    goOnline(c, dto) {
        return this.courier.goOnline(c.id, dto.lat, dto.lng);
    }
    goOffline(c) {
        return this.courier.goOffline(c.id);
    }
    updateLocation(c, dto) {
        return this.courier.updateLocation(c.id, dto);
    }
    scanQr(c, dto) {
        return this.courier.scanOrder(c.id, dto);
    }
    scanOrderQr(c, dto) {
        return this.courier.scanOrder(c.id, dto);
    }
    scanJobQr(c, dto) {
        return this.courier.scanOrder(c.id, dto);
    }
    scanPickupGeneral(c, dto) {
        return this.courier.scanOrder(c.id, { ...dto, action: 'pickup' });
    }
    scanJobPickupGeneral(c, dto) {
        return this.courier.scanOrder(c.id, { ...dto, action: 'pickup' });
    }
    scanPickupById(c, id, dto) {
        return this.courier.scanOrder(c.id, { ...dto, action: 'pickup' }, id);
    }
    scanJobPickupById(c, id, dto) {
        return this.courier.scanOrder(c.id, { ...dto, action: 'pickup' }, id);
    }
    scanDeliverById(c, id, dto) {
        return this.courier.scanDeliver(c.id, id, dto);
    }
    scanJobDeliverById(c, id, dto) {
        return this.courier.scanDeliver(c.id, id, dto);
    }
    listJobs(c, status = 'active', page = '1', limit = '20') {
        return this.courier.listJobs(c.id, status, Number(page), Number(limit));
    }
    getStats(c) {
        return this.courier.getStats(c.id);
    }
    getJob(c, id) {
        return this.courier.getJob(c.id, id);
    }
    listEarnings(c, status, page = '1', limit = '20') {
        return this.courier.listEarnings(c.id, status, Number(page), Number(limit));
    }
    getEarningsSummary(c) {
        return this.courier.getEarningsSummary(c.id);
    }
};
exports.CourierAppController = CourierAppController;
__decorate([
    (0, common_1.Get)('me'),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "getMe", null);
__decorate([
    (0, common_1.Patch)('me'),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, update_courier_profile_dto_1.UpdateCourierProfileDto]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "updateMe", null);
__decorate([
    (0, common_1.Post)('me/online'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, toggle_online_dto_1.ToggleOnlineDto]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "goOnline", null);
__decorate([
    (0, common_1.Post)('me/offline'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "goOffline", null);
__decorate([
    (0, common_1.Post)('me/location'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, update_courier_location_dto_1.UpdateCourierLocationDto]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "updateLocation", null);
__decorate([
    (0, common_1.Post)('scan'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, scan_qr_dto_1.ScanQrDto]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "scanQr", null);
__decorate([
    (0, common_1.Post)('orders/scan'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, scan_qr_dto_1.ScanQrDto]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "scanOrderQr", null);
__decorate([
    (0, common_1.Post)('jobs/scan'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, scan_qr_dto_1.ScanQrDto]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "scanJobQr", null);
__decorate([
    (0, common_1.Post)('orders/scan-pickup'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, scan_qr_dto_1.ScanQrDto]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "scanPickupGeneral", null);
__decorate([
    (0, common_1.Post)('jobs/scan-pickup'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, scan_qr_dto_1.ScanQrDto]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "scanJobPickupGeneral", null);
__decorate([
    (0, common_1.Post)('orders/:id/scan-pickup'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, scan_qr_dto_1.ScanQrDto]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "scanPickupById", null);
__decorate([
    (0, common_1.Post)('jobs/:id/scan-pickup'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, scan_qr_dto_1.ScanQrDto]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "scanJobPickupById", null);
__decorate([
    (0, common_1.Post)('orders/:id/scan-deliver'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, scan_deliver_dto_1.ScanDeliverDto]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "scanDeliverById", null);
__decorate([
    (0, common_1.Post)('jobs/:id/scan-deliver'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Param)('id')),
    __param(2, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, scan_deliver_dto_1.ScanDeliverDto]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "scanJobDeliverById", null);
__decorate([
    (0, common_1.Get)('jobs'),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Query)('status')),
    __param(2, (0, common_1.Query)('page')),
    __param(3, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object, Object]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "listJobs", null);
__decorate([
    (0, common_1.Get)('jobs/stats'),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)('jobs/:id'),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "getJob", null);
__decorate([
    (0, common_1.Get)('earnings'),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __param(1, (0, common_1.Query)('status')),
    __param(2, (0, common_1.Query)('page')),
    __param(3, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, Object, Object]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "listEarnings", null);
__decorate([
    (0, common_1.Get)('earnings/summary'),
    __param(0, (0, current_courier_decorator_1.CurrentCourier)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], CourierAppController.prototype, "getEarningsSummary", null);
exports.CourierAppController = CourierAppController = __decorate([
    (0, common_1.Controller)('courier'),
    (0, common_1.UseGuards)(courier_jwt_guard_1.CourierJwtGuard),
    __metadata("design:paramtypes", [courier_app_service_1.CourierAppService])
], CourierAppController);
//# sourceMappingURL=courier-app.controller.js.map