export declare class ScanDeliverDto {
    code?: string;
    signature?: string;
    lat?: number;
    lng?: number;
    deliveryOtp?: string;
    receiverConfirmed?: boolean;
    deliveryPhotoUrl?: string;
    deliverySignatureUrl?: string;
}
