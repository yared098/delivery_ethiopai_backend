export declare class ToggleOnlineDto {
    lat?: number;
    lng?: number;
}
