export declare class UpdateCourierLocationDto {
    lat: number;
    lng: number;
}
