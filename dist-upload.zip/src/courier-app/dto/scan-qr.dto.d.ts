export declare class ScanQrDto {
    code?: string;
    qrPayload?: string;
    trackingNumber?: string;
    signature?: string;
    lat?: number;
    lng?: number;
    action?: 'assign' | 'pickup' | 'scan';
}
