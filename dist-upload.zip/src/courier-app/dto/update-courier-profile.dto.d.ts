export declare class UpdateCourierProfileDto {
    name?: string;
    email?: string;
    vehiclePlate?: string;
    vehicleModel?: string;
    vehicleColor?: string;
}
