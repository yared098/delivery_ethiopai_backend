import { PrismaService } from '../prisma/prisma.service';
import { QrService } from '../qr/qr.service';
import { TrackingGateway } from '../tracking/tracking.gateway';
import { NotificationsService } from '../notifications/notifications.service';
import { UpdateCourierProfileDto } from './dto/update-courier-profile.dto';
import { UpdateCourierLocationDto } from './dto/update-courier-location.dto';
import { ScanQrDto } from './dto/scan-qr.dto';
import { ScanDeliverDto } from './dto/scan-deliver.dto';
import { EarningStatus } from '@prisma/client';
export declare class CourierAppService {
    private prisma;
    private qrService;
    private trackingWs;
    private notifications;
    private readonly logger;
    constructor(prisma: PrismaService, qrService: QrService, trackingWs: TrackingGateway, notifications: NotificationsService);
    getMe(courierId: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        status: import("@prisma/client").$Enums.CourierStatus;
        phone: string;
        email: string | null;
        regionId: string;
        branchId: string;
        isActive: boolean;
        phoneVerified: boolean;
        region: {
            id: string;
            code: string;
            name: string;
        };
        branch: {
            id: string;
            code: string;
            name: string;
        };
        vehicleType: import("@prisma/client").$Enums.VehicleType;
        vehiclePlate: string | null;
        vehicleModel: string | null;
        vehicleColor: string | null;
        rating: number;
        totalDeliveries: number;
        totalFailed: number;
        isOnline: boolean;
        currentLat: number | null;
        currentLng: number | null;
        lastSeenAt: Date | null;
    }>;
    updateMe(courierId: string, dto: UpdateCourierProfileDto): Promise<{
        id: string;
        name: string;
        updatedAt: Date;
        email: string | null;
        vehiclePlate: string | null;
        vehicleModel: string | null;
        vehicleColor: string | null;
    }>;
    goOnline(courierId: string, lat?: number, lng?: number): Promise<{
        isOnline: boolean;
        currentLat: number | null;
        currentLng: number | null;
        lastSeenAt: Date | null;
    }>;
    goOffline(courierId: string): Promise<{
        isOnline: boolean;
    }>;
    updateLocation(courierId: string, dto: UpdateCourierLocationDto): Promise<{
        lat: number | null;
        lng: number | null;
        currentLat: number | null;
        currentLng: number | null;
        lastSeenAt: Date | null;
    }>;
    listJobs(courierId: string, status?: 'active' | 'completed' | 'all', page?: number, limit?: number): Promise<{
        data: any[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    getJob(courierId: string, orderId: string): Promise<any>;
    getStats(courierId: string): Promise<{
        today: {
            assigned: number;
            completed: number;
            inProgress: number;
            earnings: number;
        };
        allTime: {
            totalDeliveries: number;
            totalFailed: number;
            rating: number;
        };
    }>;
    listEarnings(courierId: string, status?: EarningStatus, page?: number, limit?: number): Promise<{
        data: ({
            order: {
                trackingNumber: string;
                deliveryFee: number;
            } | null;
        } & {
            id: string;
            description: string | null;
            type: import("@prisma/client").$Enums.EarningType;
            createdAt: Date;
            updatedAt: Date;
            courierId: string;
            status: import("@prisma/client").$Enums.EarningStatus;
            paidAt: Date | null;
            orderId: string | null;
            amount: number;
            currency: string;
            releasedAt: Date | null;
            payoutId: string | null;
        })[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    getEarningsSummary(courierId: string): Promise<{
        pending: number;
        released: number;
        paid: number;
        currency: string;
    }>;
    resolveOrderFromScan(input: {
        code?: string;
        orderId?: string;
        signature?: string;
    }): Promise<{
        originBranch: {
            id: string;
            code: string;
            name: string;
        } | null;
        destBranch: {
            id: string;
            code: string;
            name: string;
        } | null;
        courier: {
            id: string;
            name: string;
            phone: string;
        } | null;
        items: {
            id: string;
            description: string | null;
            type: import("@prisma/client").$Enums.ItemType;
            isFragile: boolean;
            isRefrigerated: boolean;
            orderId: string;
            quantity: number;
            weightKg: number;
            lengthCm: number | null;
            widthCm: number | null;
            heightCm: number | null;
            volumeL: number | null;
            declaredValue: number | null;
            photoUrl: string | null;
        }[];
        payments: {
            id: string;
            createdById: string | null;
            createdAt: Date;
            updatedAt: Date;
            method: import("@prisma/client").$Enums.PaymentMethod;
            status: import("@prisma/client").$Enums.PaymentStatus;
            paidAt: Date | null;
            orderId: string;
            amount: number;
            currency: string;
            notes: string | null;
            party: import("@prisma/client").$Enums.PaymentParty;
            gatewayRef: string | null;
            gatewayPayload: import("@prisma/client/runtime/library").JsonValue | null;
            refundedAt: Date | null;
            refundAmount: number | null;
            refundReason: string | null;
        }[];
        events: {
            id: string;
            createdAt: Date;
            status: import("@prisma/client").$Enums.OrderStatus;
            lat: number | null;
            lng: number | null;
            orderId: string;
            isPublic: boolean;
            note: string | null;
            location: string | null;
            actorType: import("@prisma/client").$Enums.AccountType | null;
            actorId: string | null;
            actorName: string | null;
        }[];
    } & {
        id: string;
        createdById: string | null;
        createdAt: Date;
        trackingNumber: string;
        senderId: string | null;
        senderName: string;
        senderPhone: string;
        senderAddress: string | null;
        senderLat: number | null;
        senderLng: number | null;
        senderBranchId: string | null;
        receiverId: string | null;
        receiverName: string | null;
        receiverPhone: string;
        receiverAddress: string | null;
        receiverLat: number | null;
        receiverLng: number | null;
        receiverLocationSource: string | null;
        originBranchId: string | null;
        destBranchId: string | null;
        courierId: string | null;
        distanceKm: number | null;
        routeCategory: import("@prisma/client").$Enums.RouteCategory | null;
        pickupCityCode: string | null;
        deliveryCityCode: string | null;
        routeDistanceKm: number | null;
        estimatedHours: number | null;
        autoAssignAttempts: number;
        lastOfferedAt: Date | null;
        autoUnassignAt: Date | null;
        unassignReason: string | null;
        requiresReturn: boolean;
        totalWeightKg: number;
        totalVolumeL: number;
        isFragile: boolean;
        isRefrigerated: boolean;
        packageDescription: string | null;
        deliveryFee: number;
        codAmount: number;
        courierEarning: number;
        platformFee: number;
        pricingBreakdown: import("@prisma/client/runtime/library").JsonValue | null;
        paymentParty: import("@prisma/client").$Enums.PaymentParty;
        paymentMethod: import("@prisma/client").$Enums.PaymentMethod | null;
        paymentStatus: import("@prisma/client").$Enums.PaymentStatus;
        status: import("@prisma/client").$Enums.OrderStatus;
        paidAt: Date | null;
        assignedAt: Date | null;
        pickedUpAt: Date | null;
        deliveredAt: Date | null;
        failedAt: Date | null;
        cancelledAt: Date | null;
        deliveryPhotoUrl: string | null;
        deliverySignatureUrl: string | null;
        deliveryOtp: string | null;
        receiverConfirmed: boolean;
        failureReason: string | null;
        lastCourierLat: number | null;
        lastCourierLng: number | null;
        lastTrackedAt: Date | null;
        estimatedArrival: Date | null;
        trackingUrl: string | null;
        trackingToken: string | null;
        trackingTokenSetAt: Date | null;
        trackingTokenExpiresAt: Date | null;
        trackingTokenRevokedAt: Date | null;
        qrCodePayload: string | null;
        qrCodeSignature: string | null;
        qrCodeImageUrl: string | null;
    }>;
    scanOrder(courierId: string, dto: ScanQrDto, orderIdParam?: string): Promise<{
        success: boolean;
        message: string;
        reassigned: boolean;
        wasUnassigned: boolean;
        wasReassignedFromOther: boolean;
        previousCourier: {
            id: string;
            name: string;
        } | null;
        status: import("@prisma/client").$Enums.OrderStatus;
        order: any;
        job: any;
        data: any;
    }>;
    scanDeliver(courierId: string, orderIdParam: string, dto: ScanDeliverDto): Promise<{
        success: boolean;
        message: string;
        order: any;
        job: any;
        data: any;
    }>;
    private publicJob;
}
