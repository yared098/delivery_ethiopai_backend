"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CourierAppModule = void 0;
const common_1 = require("@nestjs/common");
const courier_app_controller_1 = require("./courier-app.controller");
const courier_app_service_1 = require("./courier-app.service");
const prisma_module_1 = require("../prisma/prisma.module");
const auth_module_1 = require("../auth/auth.module");
const qr_module_1 = require("../qr/qr.module");
const tracking_module_1 = require("../tracking/tracking.module");
let CourierAppModule = class CourierAppModule {
};
exports.CourierAppModule = CourierAppModule;
exports.CourierAppModule = CourierAppModule = __decorate([
    (0, common_1.Module)({
        imports: [prisma_module_1.PrismaModule, auth_module_1.AuthModule, qr_module_1.QrModule, tracking_module_1.TrackingModule],
        controllers: [courier_app_controller_1.CourierAppController],
        providers: [courier_app_service_1.CourierAppService],
        exports: [courier_app_service_1.CourierAppService],
    })
], CourierAppModule);
//# sourceMappingURL=courier-app.module.js.map