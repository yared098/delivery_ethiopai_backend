import { CourierAppService } from './courier-app.service';
import { UpdateCourierProfileDto } from './dto/update-courier-profile.dto';
import { UpdateCourierLocationDto } from './dto/update-courier-location.dto';
import { ToggleOnlineDto } from './dto/toggle-online.dto';
import { ScanQrDto } from './dto/scan-qr.dto';
import { ScanDeliverDto } from './dto/scan-deliver.dto';
import { EarningStatus } from '@prisma/client';
export declare class CourierAppController {
    private courier;
    constructor(courier: CourierAppService);
    getMe(c: any): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        status: import("@prisma/client").$Enums.CourierStatus;
        phone: string;
        email: string | null;
        regionId: string;
        branchId: string;
        isActive: boolean;
        phoneVerified: boolean;
        region: {
            id: string;
            code: string;
            name: string;
        };
        branch: {
            id: string;
            code: string;
            name: string;
        };
        vehicleType: import("@prisma/client").$Enums.VehicleType;
        vehiclePlate: string | null;
        vehicleModel: string | null;
        vehicleColor: string | null;
        rating: number;
        totalDeliveries: number;
        totalFailed: number;
        isOnline: boolean;
        currentLat: number | null;
        currentLng: number | null;
        lastSeenAt: Date | null;
    }>;
    updateMe(c: any, dto: UpdateCourierProfileDto): Promise<{
        id: string;
        name: string;
        updatedAt: Date;
        email: string | null;
        vehiclePlate: string | null;
        vehicleModel: string | null;
        vehicleColor: string | null;
    }>;
    goOnline(c: any, dto: ToggleOnlineDto): Promise<{
        isOnline: boolean;
        currentLat: number | null;
        currentLng: number | null;
        lastSeenAt: Date | null;
    }>;
    goOffline(c: any): Promise<{
        isOnline: boolean;
    }>;
    updateLocation(c: any, dto: UpdateCourierLocationDto): Promise<{
        lat: number | null;
        lng: number | null;
        currentLat: number | null;
        currentLng: number | null;
        lastSeenAt: Date | null;
    }>;
    scanQr(c: any, dto: ScanQrDto): Promise<{
        success: boolean;
        message: string;
        reassigned: boolean;
        wasUnassigned: boolean;
        wasReassignedFromOther: boolean;
        previousCourier: {
            id: string;
            name: string;
        } | null;
        status: import("@prisma/client").$Enums.OrderStatus;
        order: any;
        job: any;
        data: any;
    }>;
    scanOrderQr(c: any, dto: ScanQrDto): Promise<{
        success: boolean;
        message: string;
        reassigned: boolean;
        wasUnassigned: boolean;
        wasReassignedFromOther: boolean;
        previousCourier: {
            id: string;
            name: string;
        } | null;
        status: import("@prisma/client").$Enums.OrderStatus;
        order: any;
        job: any;
        data: any;
    }>;
    scanJobQr(c: any, dto: ScanQrDto): Promise<{
        success: boolean;
        message: string;
        reassigned: boolean;
        wasUnassigned: boolean;
        wasReassignedFromOther: boolean;
        previousCourier: {
            id: string;
            name: string;
        } | null;
        status: import("@prisma/client").$Enums.OrderStatus;
        order: any;
        job: any;
        data: any;
    }>;
    scanPickupGeneral(c: any, dto: ScanQrDto): Promise<{
        success: boolean;
        message: string;
        reassigned: boolean;
        wasUnassigned: boolean;
        wasReassignedFromOther: boolean;
        previousCourier: {
            id: string;
            name: string;
        } | null;
        status: import("@prisma/client").$Enums.OrderStatus;
        order: any;
        job: any;
        data: any;
    }>;
    scanJobPickupGeneral(c: any, dto: ScanQrDto): Promise<{
        success: boolean;
        message: string;
        reassigned: boolean;
        wasUnassigned: boolean;
        wasReassignedFromOther: boolean;
        previousCourier: {
            id: string;
            name: string;
        } | null;
        status: import("@prisma/client").$Enums.OrderStatus;
        order: any;
        job: any;
        data: any;
    }>;
    scanPickupById(c: any, id: string, dto: ScanQrDto): Promise<{
        success: boolean;
        message: string;
        reassigned: boolean;
        wasUnassigned: boolean;
        wasReassignedFromOther: boolean;
        previousCourier: {
            id: string;
            name: string;
        } | null;
        status: import("@prisma/client").$Enums.OrderStatus;
        order: any;
        job: any;
        data: any;
    }>;
    scanJobPickupById(c: any, id: string, dto: ScanQrDto): Promise<{
        success: boolean;
        message: string;
        reassigned: boolean;
        wasUnassigned: boolean;
        wasReassignedFromOther: boolean;
        previousCourier: {
            id: string;
            name: string;
        } | null;
        status: import("@prisma/client").$Enums.OrderStatus;
        order: any;
        job: any;
        data: any;
    }>;
    scanDeliverById(c: any, id: string, dto: ScanDeliverDto): Promise<{
        success: boolean;
        message: string;
        order: any;
        job: any;
        data: any;
    }>;
    scanJobDeliverById(c: any, id: string, dto: ScanDeliverDto): Promise<{
        success: boolean;
        message: string;
        order: any;
        job: any;
        data: any;
    }>;
    listJobs(c: any, status?: 'active' | 'completed' | 'all', page?: string, limit?: string): Promise<{
        data: any[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    getStats(c: any): Promise<{
        today: {
            assigned: number;
            completed: number;
            inProgress: number;
            earnings: number;
        };
        allTime: {
            totalDeliveries: number;
            totalFailed: number;
            rating: number;
        };
    }>;
    getJob(c: any, id: string): Promise<any>;
    listEarnings(c: any, status?: EarningStatus, page?: string, limit?: string): Promise<{
        data: ({
            order: {
                trackingNumber: string;
                deliveryFee: number;
            } | null;
        } & {
            id: string;
            description: string | null;
            type: import("@prisma/client").$Enums.EarningType;
            createdAt: Date;
            updatedAt: Date;
            courierId: string;
            status: import("@prisma/client").$Enums.EarningStatus;
            paidAt: Date | null;
            orderId: string | null;
            amount: number;
            currency: string;
            releasedAt: Date | null;
            payoutId: string | null;
        })[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    getEarningsSummary(c: any): Promise<{
        pending: number;
        released: number;
        paid: number;
        currency: string;
    }>;
}
