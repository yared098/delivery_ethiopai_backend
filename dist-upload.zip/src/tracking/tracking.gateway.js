"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var TrackingGateway_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrackingGateway = void 0;
const websockets_1 = require("@nestjs/websockets");
const socket_io_1 = require("socket.io");
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const config_1 = require("@nestjs/config");
let TrackingGateway = TrackingGateway_1 = class TrackingGateway {
    constructor(jwt, config) {
        this.jwt = jwt;
        this.config = config;
        this.logger = new common_1.Logger(TrackingGateway_1.name);
        this.connections = new Map();
    }
    async handleConnection(client) {
        try {
            const token = client.handshake.auth?.token ||
                client.handshake.headers?.authorization?.replace('Bearer ', '');
            if (token) {
                try {
                    const payload = await this.jwt.verifyAsync(token, {
                        secret: this.config.get('JWT_ACCESS_SECRET'),
                    });
                    this.connections.set(client.id, {
                        userId: payload.sub,
                        accountType: payload.accountType,
                        role: payload.role,
                    });
                    client.data.user = payload;
                    this.logger.log(` Socket connected: ${client.id} (user: ${payload.sub}, type: ${payload.accountType})`);
                }
                catch (err) {
                    this.connections.set(client.id, {});
                    this.logger.warn(`⚠️  Socket connected (public): ${client.id}`);
                }
            }
            else {
                this.connections.set(client.id, {});
                this.logger.log(`🔓 Socket connected (public): ${client.id}`);
            }
        }
        catch (err) {
            this.logger.error(`Socket connection error: ${err.message}`);
        }
    }
    handleDisconnect(client) {
        this.connections.delete(client.id);
        this.logger.log(`❌ Socket disconnected: ${client.id}`);
    }
    async handleSubscribe(client, data) {
        if (!data?.orderId) {
            return { success: false, error: 'orderId required' };
        }
        const room = `order:${data.orderId}`;
        await client.join(room);
        this.logger.log(`📌 Socket ${client.id} subscribed to ${room}`);
        return {
            success: true,
            room,
            message: `Subscribed to order ${data.orderId}`,
        };
    }
    async handleUnsubscribe(client, data) {
        if (!data?.orderId) {
            return { success: false, error: 'orderId required' };
        }
        const room = `order:${data.orderId}`;
        await client.leave(room);
        return { success: true };
    }
    emitStatus(orderIdOrTracking, status, note) {
        const room = `order:${orderIdOrTracking}`;
        this.server.to(room).emit('tracking:status', {
            orderId: orderIdOrTracking,
            status,
            note,
            timestamp: new Date().toISOString(),
        });
        this.logger.log(`🔄 Status emitted for ${room}: ${status}`);
    }
    broadcastLocationUpdate(orderId, data) {
        const room = `order:${orderId}`;
        this.server.to(room).emit('location:update', {
            orderId,
            ...data,
        });
        this.logger.debug(`📍 Location update for ${room}`);
    }
    broadcastStatusChange(orderId, data) {
        const room = `order:${orderId}`;
        this.server.to(room).emit('status:change', {
            orderId,
            ...data,
        });
        this.logger.log(`🔄 Status change for ${room}: ${data.status}`);
    }
    broadcastProximityAlert(orderId, data) {
        const room = `order:${orderId}`;
        this.server.to(room).emit('proximity:alert', {
            orderId,
            ...data,
        });
        this.logger.log(`🔔 Proximity alert for ${room}: ${data.level}`);
    }
    broadcastEvent(orderId, event) {
        const room = `order:${orderId}`;
        this.server.to(room).emit('order:event', {
            orderId,
            event,
        });
    }
    broadcastOrderEnd(orderId, data) {
        const room = `order:${orderId}`;
        this.server.to(room).emit('order:end', {
            orderId,
            ...data,
        });
    }
};
exports.TrackingGateway = TrackingGateway;
__decorate([
    (0, websockets_1.WebSocketServer)(),
    __metadata("design:type", socket_io_1.Server)
], TrackingGateway.prototype, "server", void 0);
__decorate([
    (0, websockets_1.SubscribeMessage)('order:subscribe'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], TrackingGateway.prototype, "handleSubscribe", null);
__decorate([
    (0, websockets_1.SubscribeMessage)('order:unsubscribe'),
    __param(0, (0, websockets_1.ConnectedSocket)()),
    __param(1, (0, websockets_1.MessageBody)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socket_io_1.Socket, Object]),
    __metadata("design:returntype", Promise)
], TrackingGateway.prototype, "handleUnsubscribe", null);
exports.TrackingGateway = TrackingGateway = TrackingGateway_1 = __decorate([
    (0, websockets_1.WebSocketGateway)({
        cors: {
            origin: [
                'http://localhost:5173',
                'http://localhost:3000',
                'http://127.0.0.1:5173',
            ],
            credentials: true,
        },
        namespace: 'tracking',
    }),
    __metadata("design:paramtypes", [jwt_1.JwtService,
        config_1.ConfigService])
], TrackingGateway);
//# sourceMappingURL=tracking.gateway.js.map