import { OnGatewayConnection, OnGatewayDisconnect } from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
export declare class TrackingGateway implements OnGatewayConnection, OnGatewayDisconnect {
    private jwt;
    private config;
    server: Server;
    private readonly logger;
    private connections;
    constructor(jwt: JwtService, config: ConfigService);
    handleConnection(client: Socket): Promise<void>;
    handleDisconnect(client: Socket): void;
    handleSubscribe(client: Socket, data: {
        orderId: string;
        trackingToken?: string;
    }): Promise<{
        success: boolean;
        error: string;
        room?: undefined;
        message?: undefined;
    } | {
        success: boolean;
        room: string;
        message: string;
        error?: undefined;
    }>;
    handleUnsubscribe(client: Socket, data: {
        orderId: string;
    }): Promise<{
        success: boolean;
        error: string;
    } | {
        success: boolean;
        error?: undefined;
    }>;
    emitStatus(orderIdOrTracking: string, status: string, note?: string): void;
    broadcastLocationUpdate(orderId: string, data: {
        lat: number;
        lng: number;
        courierId: string;
        courierName?: string;
        timestamp: string;
        distanceToReceiver?: number;
        etaMinutes?: number;
        status: string;
    }): void;
    broadcastStatusChange(orderId: string, data: {
        status: string;
        note?: string;
        location?: string;
        lat?: number;
        lng?: number;
        timestamp: string;
    }): void;
    broadcastProximityAlert(orderId: string, data: {
        level: 'NEARBY' | 'CLOSE' | 'ARRIVING' | 'AT_DOOR';
        distanceMeters: number;
        message: string;
    }): void;
    broadcastEvent(orderId: string, event: {
        id: string;
        status: string;
        note?: string;
        location?: string;
        createdAt: string;
        actorName?: string;
    }): void;
    broadcastOrderEnd(orderId: string, data: {
        outcome: 'DELIVERED' | 'CANCELLED' | 'FAILED' | 'RETURNED';
        message?: string;
    }): void;
}
