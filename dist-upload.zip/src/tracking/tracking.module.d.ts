export declare class TrackingModule {
}
