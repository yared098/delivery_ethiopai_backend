"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PricingService = void 0;
const common_1 = require("@nestjs/common");
const BASE_FEE = 50;
const PER_KM = 15;
const PER_KG = 20;
const MIN_PRICE = 100;
const FRAGILE_SURCHARGE = 30;
const REFRIGERATED_SURCHARGE = 50;
const ITEM_TYPE_FEES = {
    PARCEL: 0,
    DOCUMENT: 10,
    BOX: 15,
    ENVELOPE: 5,
    FOOD: 25,
    ELECTRONICS: 40,
    CLOTHING: 10,
    MEDICINE: 20,
    FRAGILE_ITEM: 30,
    OTHER: 0,
};
let PricingService = class PricingService {
    calculate(input) {
        if (input.distanceKm < 0 || input.totalWeightKg < 0) {
            throw new common_1.BadRequestException('Invalid pricing input');
        }
        const baseFee = BASE_FEE;
        const distanceCharge = input.distanceKm * PER_KM;
        const weightCharge = input.totalWeightKg * PER_KG;
        let itemSurcharges = 0;
        for (const item of input.items) {
            const qty = item.quantity || 1;
            itemSurcharges += (ITEM_TYPE_FEES[item.type] || 0) * qty;
            if (item.isFragile)
                itemSurcharges += FRAGILE_SURCHARGE * qty;
            if (item.isRefrigerated)
                itemSurcharges += REFRIGERATED_SURCHARGE * qty;
        }
        const subtotal = baseFee + distanceCharge + weightCharge + itemSurcharges;
        const regionMultiplier = input.regionMultiplier ?? 1.0;
        let total = subtotal * regionMultiplier;
        if (total < MIN_PRICE)
            total = MIN_PRICE;
        total = Math.round(total * 100) / 100;
        return {
            baseFee,
            distanceCharge: round2(distanceCharge),
            weightCharge: round2(weightCharge),
            itemSurcharges: round2(itemSurcharges),
            subtotal: round2(subtotal),
            regionMultiplier,
            total,
            currency: 'ETB',
        };
    }
    distanceKm(lat1, lng1, lat2, lng2) {
        const R = 6371;
        const dLat = toRad(lat2 - lat1);
        const dLng = toRad(lng2 - lng1);
        const a = Math.sin(dLat / 2) ** 2 +
            Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return Math.round(R * c * 100) / 100;
    }
    courierEarning(deliveryFee) {
        return Math.round(deliveryFee * 0.6 * 100) / 100;
    }
    platformFee(deliveryFee) {
        return Math.round(deliveryFee * 0.4 * 100) / 100;
    }
};
exports.PricingService = PricingService;
exports.PricingService = PricingService = __decorate([
    (0, common_1.Injectable)()
], PricingService);
function round2(n) {
    return Math.round(n * 100) / 100;
}
function toRad(deg) {
    return (deg * Math.PI) / 180;
}
//# sourceMappingURL=pricing.service.js.map