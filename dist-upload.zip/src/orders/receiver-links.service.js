"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReceiverLinksService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const tracking_number_service_1 = require("./tracking-number.service");
const afromessage_service_1 = require("../integrations/afromessage/afromessage.service");
const client_1 = require("@prisma/client");
const argon2 = __importStar(require("argon2"));
const crypto_1 = require("crypto");
const LINK_TTL_HOURS = 48;
const PUBLIC_WEB_URL = process.env.PUBLIC_WEB_URL || 'http://localhost:5173';
let ReceiverLinksService = class ReceiverLinksService {
    constructor(prisma, tracking, sms) {
        this.prisma = prisma;
        this.tracking = tracking;
        this.sms = sms;
    }
    async createForOrder(orderId, receiverPhone, createdById) {
        const order = await this.prisma.order.findUnique({ where: { id: orderId } });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        await this.prisma.receiverLink.updateMany({
            where: { orderId, status: client_1.ReceiverLinkStatus.ACTIVE },
            data: { status: client_1.ReceiverLinkStatus.REVOKED },
        });
        const shortCode = this.tracking.generateShortCode();
        const rawToken = (0, crypto_1.randomUUID)() + '-' + (0, crypto_1.randomUUID)();
        const tokenHash = await argon2.hash(rawToken);
        const expiresAt = new Date(Date.now() + LINK_TTL_HOURS * 60 * 60 * 1000);
        const link = await this.prisma.receiverLink.create({
            data: {
                orderId,
                shortCode,
                tokenHash,
                receiverPhone,
                expiresAt,
                createdById,
                status: client_1.ReceiverLinkStatus.ACTIVE,
            },
        });
        return {
            id: link.id,
            shortCode,
            url: `${PUBLIC_WEB_URL}/receiver/${shortCode}`,
            expiresAt,
        };
    }
    async findByShortCode(shortCode) {
        const link = await this.prisma.receiverLink.findUnique({
            where: { shortCode },
            include: {
                order: {
                    select: {
                        id: true,
                        trackingNumber: true,
                        senderName: true,
                        receiverName: true,
                        receiverPhone: true,
                        totalWeightKg: true,
                        packageDescription: true,
                        status: true,
                    },
                },
            },
        });
        if (!link)
            throw new common_1.NotFoundException('Link not found');
        if (link.expiresAt < new Date() && link.status === client_1.ReceiverLinkStatus.ACTIVE) {
            await this.prisma.receiverLink.update({
                where: { id: link.id },
                data: { status: client_1.ReceiverLinkStatus.EXPIRED },
            });
            throw new common_1.BadRequestException('Link has expired');
        }
        if (link.status !== client_1.ReceiverLinkStatus.ACTIVE) {
            throw new common_1.BadRequestException(`Link is ${link.status.toLowerCase()}`);
        }
        return link;
    }
    async markOpened(id, ip) {
        await this.prisma.receiverLink.update({
            where: { id },
            data: {
                openedAt: new Date(),
                openedIp: ip,
            },
        });
    }
    async markUsed(id, ip) {
        await this.prisma.receiverLink.update({
            where: { id },
            data: {
                status: client_1.ReceiverLinkStatus.USED,
                filledAt: new Date(),
                filledIp: ip,
            },
        });
    }
    async revoke(linkId) {
        await this.prisma.receiverLink.update({
            where: { id: linkId },
            data: { status: client_1.ReceiverLinkStatus.REVOKED },
        });
        return { message: 'Link revoked' };
    }
};
exports.ReceiverLinksService = ReceiverLinksService;
exports.ReceiverLinksService = ReceiverLinksService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        tracking_number_service_1.TrackingNumberService,
        afromessage_service_1.AfroMessageService])
], ReceiverLinksService);
//# sourceMappingURL=receiver-links.service.js.map