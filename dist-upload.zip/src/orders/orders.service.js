"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const tracking_number_service_1 = require("./tracking-number.service");
const pricing_service_1 = require("./pricing.service");
const receiver_links_service_1 = require("./receiver-links.service");
const tracking_gateway_1 = require("../tracking/tracking.gateway");
const qr_service_1 = require("../qr/qr.service");
const afromessage_service_1 = require("../integrations/afromessage/afromessage.service");
const notifications_service_1 = require("../notifications/notifications.service");
const client_1 = require("@prisma/client");
const branch_resolver_service_1 = require("./branch-resolver.service");
const staff_scan_dto_1 = require("./dto/staff-scan.dto");
let OrdersService = class OrdersService {
    constructor(prisma, tracking, pricing, receiverLinks, trackingWs, qr, sms, notifications, branchResolver) {
        this.prisma = prisma;
        this.tracking = tracking;
        this.pricing = pricing;
        this.receiverLinks = receiverLinks;
        this.trackingWs = trackingWs;
        this.qr = qr;
        this.sms = sms;
        this.notifications = notifications;
        this.branchResolver = branchResolver;
    }
    orderScope(currentUser) {
        if (currentUser.role === client_1.StaffRole.SUPER_ADMIN) {
            return {};
        }
        if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN) {
            if (currentUser.regionId) {
                return {
                    OR: [
                        { originBranch: { regionId: currentUser.regionId } },
                        { destBranch: { regionId: currentUser.regionId } },
                    ],
                };
            }
            return {};
        }
        if (currentUser.role === client_1.StaffRole.BRANCH_MANAGER) {
            if (currentUser.branchId) {
                return {
                    OR: [
                        { originBranchId: currentUser.branchId },
                        { destBranchId: currentUser.branchId },
                    ],
                };
            }
            if (currentUser.regionId) {
                return {
                    OR: [
                        { originBranch: { regionId: currentUser.regionId } },
                        { destBranch: { regionId: currentUser.regionId } },
                    ],
                };
            }
            return {};
        }
        return { id: '__no_access__' };
    }
    async assertOrderAccess(orderId, currentUser) {
        const order = await this.prisma.order.findFirst({
            where: { AND: [{ id: orderId }, this.orderScope(currentUser)] },
            select: { id: true },
        });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
    }
    async assertOriginBranchAccess(originBranchId, currentUser) {
        if (currentUser.accountType !== client_1.AccountType.STAFF)
            return;
        if (currentUser.role === client_1.StaffRole.SUPER_ADMIN)
            return;
        if (!originBranchId) {
            throw new common_1.BadRequestException('Staff-created orders require an origin branch');
        }
        const branch = await this.prisma.branch.findUnique({
            where: { id: originBranchId },
            select: { id: true, regionId: true },
        });
        if (!branch)
            throw new common_1.BadRequestException('Origin branch not found');
        if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN &&
            branch.regionId !== currentUser.regionId) {
            throw new common_1.ForbiddenException('You can only create orders in your region');
        }
        if (currentUser.role === client_1.StaffRole.BRANCH_MANAGER &&
            branch.id !== currentUser.branchId) {
            throw new common_1.ForbiddenException('You can only create orders in your branch');
        }
    }
    normalizePhone(phone) {
        const digits = phone.replace(/\D/g, '');
        if (digits.startsWith('251') && digits.length === 12)
            return digits;
        if (digits.startsWith('0') && digits.length === 10)
            return '251' + digits.slice(1);
        if (digits.length === 9)
            return '251' + digits;
        return '251' + digits;
    }
    async create(dto, currentUser) {
        const senderPhone = this.normalizePhone(dto.sender.phone);
        const receiverPhone = this.normalizePhone(dto.receiver.phone);
        const isStaff = currentUser?.accountType === client_1.AccountType.STAFF;
        const staffActorId = isStaff ? currentUser.id : null;
        const actorType = isStaff
            ? client_1.AccountType.STAFF
            : client_1.AccountType.CUSTOMER;
        const actorId = currentUser?.id ?? null;
        const actorName = currentUser?.name ?? 'System';
        const receiverComplete = !!dto.receiver.name &&
            !!dto.receiver.address &&
            dto.receiver.lat != null &&
            dto.receiver.lng != null;
        const totalWeightKg = dto.items.reduce((sum, it) => sum + it.weightKg * (it.quantity || 1), 0);
        const totalVolumeL = dto.items.reduce((sum, it) => sum + (it.volumeL || 0) * (it.quantity || 1), 0);
        const isFragile = dto.items.some((it) => it.isFragile);
        const isRefrigerated = dto.items.some((it) => it.isRefrigerated);
        let status = client_1.OrderStatus.DRAFT;
        if (receiverComplete) {
            status = client_1.OrderStatus.PENDING_PAYMENT;
        }
        else {
            status = client_1.OrderStatus.AWAITING_RECEIVER_LOCATION;
        }
        let distanceKm = null;
        if (dto.sender.lat != null &&
            dto.sender.lng != null &&
            dto.receiver.lat != null &&
            dto.receiver.lng != null) {
            distanceKm = this.pricing.distanceKm(dto.sender.lat, dto.sender.lng, dto.receiver.lat, dto.receiver.lng);
        }
        const pricingBreakdown = this.pricing.calculate({
            distanceKm: distanceKm || 0,
            totalWeightKg,
            items: dto.items.map((it) => ({
                type: it.type ?? 'OTHER',
                quantity: it.quantity || 1,
                isFragile: it.isFragile,
                isRefrigerated: it.isRefrigerated,
            })),
        });
        const deliveryFee = pricingBreakdown.total;
        const courierEarning = this.pricing.courierEarning(deliveryFee);
        const platformFee = this.pricing.platformFee(deliveryFee);
        let originBranchId = dto.originBranchId;
        if (currentUser.role === client_1.StaffRole.BRANCH_MANAGER) {
            originBranchId = currentUser.branchId;
        }
        else if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN &&
            !originBranchId) {
            if (!currentUser.regionId) {
                throw new common_1.BadRequestException('Regional Admin must be assigned to a region before creating orders');
            }
            const nearestRegionalBranch = await this.branchResolver.findNearestBranch(dto.sender.lat, dto.sender.lng, currentUser.regionId);
            const regionalBranch = nearestRegionalBranch ??
                (await this.branchResolver.findFirstActiveBranchInRegion(currentUser.regionId));
            if (!regionalBranch) {
                throw new common_1.BadRequestException('No active branch is configured in your region');
            }
            originBranchId = regionalBranch.id;
        }
        const resolved = await this.branchResolver.resolveForOrder({
            originBranchId,
            destBranchId: dto.destBranchId,
            senderLat: dto.sender.lat,
            senderLng: dto.sender.lng,
            receiverLat: dto.receiver.lat,
            receiverLng: dto.receiver.lng,
        });
        await this.assertOriginBranchAccess(resolved.originBranchId, currentUser);
        console.log('📍 Resolved branches:', {
            origin: resolved.originBranch?.name ?? 'none',
            originKm: resolved.originBranch?.distanceKm,
            dest: resolved.destBranch?.name ?? 'none',
            destKm: resolved.destBranch?.distanceKm,
        });
        const trackingNumber = await this.tracking.generate();
        const trackingToken = this.tracking.generateTrackingToken();
        let senderCustomerId = dto.sender.customerId;
        if (!senderCustomerId) {
            const existing = await this.prisma.customer.findUnique({
                where: { phone: senderPhone },
            });
            if (existing)
                senderCustomerId = existing.id;
        }
        let receiverCustomerId = dto.receiver.customerId;
        if (!receiverCustomerId) {
            const existing = await this.prisma.customer.findUnique({
                where: { phone: receiverPhone },
            });
            if (existing)
                receiverCustomerId = existing.id;
        }
        const order = await this.prisma.$transaction(async (tx) => {
            const created = await tx.order.create({
                data: {
                    trackingNumber,
                    trackingToken,
                    trackingUrl: `${process.env.PUBLIC_WEB_URL || 'http://localhost:5173'}/track/${trackingToken}`,
                    senderId: senderCustomerId,
                    senderName: dto.sender.name,
                    senderPhone,
                    senderAddress: dto.sender.address,
                    senderLat: dto.sender.lat,
                    senderLng: dto.sender.lng,
                    receiverId: receiverCustomerId,
                    receiverName: dto.receiver.name,
                    receiverPhone,
                    receiverAddress: dto.receiver.address,
                    receiverLat: dto.receiver.lat,
                    receiverLng: dto.receiver.lng,
                    receiverLocationSource: receiverComplete ? 'manual' : null,
                    originBranchId: resolved.originBranchId,
                    destBranchId: resolved.destBranchId,
                    distanceKm,
                    totalWeightKg,
                    totalVolumeL,
                    isFragile,
                    isRefrigerated,
                    packageDescription: dto.packageDescription,
                    deliveryFee,
                    courierEarning,
                    platformFee,
                    codAmount: dto.codAmount || 0,
                    pricingBreakdown,
                    paymentParty: dto.paymentParty || client_1.PaymentParty.SENDER,
                    status,
                    createdById: staffActorId,
                    items: {
                        create: dto.items.map((it) => ({
                            type: it.type ?? 'OTHER',
                            description: it.description,
                            quantity: it.quantity || 1,
                            weightKg: it.weightKg,
                            lengthCm: it.lengthCm,
                            widthCm: it.widthCm,
                            heightCm: it.heightCm,
                            volumeL: it.volumeL,
                            declaredValue: it.declaredValue,
                            isFragile: it.isFragile || false,
                            isRefrigerated: it.isRefrigerated || false,
                            photoUrl: it.photoUrl,
                        })),
                    },
                },
                include: {
                    items: true,
                    sender: { select: { id: true, name: true, phone: true } },
                    receiver: { select: { id: true, name: true, phone: true } },
                    originBranch: { select: { id: true, name: true, code: true } },
                    destBranch: { select: { id: true, name: true, code: true } },
                    createdBy: { select: { id: true, name: true } },
                },
            });
            await tx.orderEvent.create({
                data: {
                    orderId: created.id,
                    status,
                    note: status === client_1.OrderStatus.AWAITING_RECEIVER_LOCATION
                        ? 'Waiting for receiver to share location'
                        : 'Order created',
                    actorType,
                    actorId,
                    actorName,
                    isPublic: false,
                },
            });
            return created;
        });
        try {
            await this.qr.generateForOrder(order.id, trackingNumber);
        }
        catch (err) {
            console.error('QR generation failed:', err);
        }
        let trackingUrl = order.trackingUrl ?? null;
        if (!trackingUrl) {
            try {
                const trackingResult = await this.qr.generateTrackingToken(order.id);
                trackingUrl = trackingResult.url;
            }
            catch (err) {
                console.error('Tracking token generation failed:', err);
            }
        }
        let receiverLink = null;
        if (!receiverComplete) {
            try {
                const link = await this.receiverLinks.createForOrder(order.id, receiverPhone, currentUser.id);
                const smsSent = await this.sms.sendReceiverLink(receiverPhone, dto.sender.name, link.url);
                receiverLink = { ...link, smsSent };
                if (!smsSent) {
                    console.error(`Receiver link SMS was not accepted for order ${order.id}`);
                }
            }
            catch (err) {
                console.error(`Receiver link creation failed for order ${order.id}:`, err);
            }
        }
        if (dto.sender.phone && trackingUrl) {
            try {
                await this.sms.sendTrackingLink(dto.sender.phone, trackingNumber, trackingUrl);
            }
            catch (err) {
                console.error('Sender tracking SMS failed:', err);
            }
        }
        if (receiverPhone && trackingUrl && receiverComplete) {
            try {
                await this.sms.sendTrackingLink(receiverPhone, trackingNumber, trackingUrl);
            }
            catch (err) {
                console.error('Receiver tracking SMS failed:', err);
            }
        }
        let courierAssigned = null;
        if (status === client_1.OrderStatus.PENDING_PAYMENT) {
            if (dto.courierId) {
                try {
                    const courier = await this.prisma.courier.findUnique({
                        where: { id: dto.courierId },
                    });
                    if (courier && courier.status === 'APPROVED' && courier.isActive) {
                        await this.prisma.$transaction([
                            this.prisma.order.update({
                                where: { id: order.id },
                                data: {
                                    courierId: dto.courierId,
                                    status: client_1.OrderStatus.ASSIGNED,
                                    assignedAt: new Date(),
                                },
                            }),
                            this.prisma.orderEvent.create({
                                data: {
                                    orderId: order.id,
                                    status: client_1.OrderStatus.ASSIGNED,
                                    note: `Assigned to ${courier.name}`,
                                    actorType: client_1.AccountType.STAFF,
                                    actorId: currentUser.id,
                                    actorName: currentUser.name,
                                    isPublic: true,
                                },
                            }),
                        ]);
                        order.status = client_1.OrderStatus.ASSIGNED;
                        order.courierId = dto.courierId;
                        order.courier = {
                            id: courier.id,
                            name: courier.name,
                            phone: courier.phone,
                        };
                        courierAssigned = courier;
                        this.trackingWs.broadcastStatusChange(order.id, {
                            status: client_1.OrderStatus.ASSIGNED,
                            note: `Courier ${courier.name} assigned`,
                            timestamp: new Date().toISOString(),
                        });
                        await this.notifications.notifyOrderStatus({
                            id: order.id,
                            trackingNumber,
                            status: client_1.OrderStatus.ASSIGNED,
                            senderId: order.senderId,
                            receiverId: order.receiverId,
                            courierId: dto.courierId,
                            senderAddress: order.senderAddress,
                        });
                    }
                }
                catch (err) {
                    console.error('Courier manual assignment failed:', err);
                }
            }
            else if (dto.autoAssignCourier) {
                try {
                    await this.autoAssignCourier(order.id, currentUser);
                    const updated = await this.prisma.order.findUnique({
                        where: { id: order.id },
                        include: {
                            courier: {
                                select: {
                                    id: true,
                                    name: true,
                                    phone: true,
                                    currentLat: true,
                                    currentLng: true,
                                    lastSeenAt: true,
                                    isOnline: true,
                                },
                            },
                        },
                    });
                    if (updated) {
                        order.status = updated.status;
                        order.courierId = updated.courierId;
                        order.courier = updated.courier;
                        courierAssigned = updated.courier;
                    }
                }
                catch (err) {
                    console.error('Courier auto-assignment failed:', err);
                }
            }
        }
        const finalOrder = await this.prisma.order.findUnique({
            where: { id: order.id },
            include: {
                items: true,
                sender: { select: { id: true, name: true, phone: true } },
                receiver: { select: { id: true, name: true, phone: true } },
                originBranch: { select: { id: true, name: true, code: true } },
                destBranch: { select: { id: true, name: true, code: true } },
                courier: { select: { id: true, name: true, phone: true } },
                createdBy: { select: { id: true, name: true } },
            },
        });
        if (finalOrder && finalOrder.status !== client_1.OrderStatus.ASSIGNED) {
            await this.notifications.notifyOrderStatus(finalOrder);
        }
        return {
            order: finalOrder,
            receiverLink,
            courierAssigned,
        };
    }
    async findAll(query, currentUser) {
        const where = { AND: [this.orderScope(currentUser)] };
        if (query.status)
            where.status = query.status;
        if (query.senderId)
            where.senderId = query.senderId;
        if (query.receiverId)
            where.receiverId = query.receiverId;
        if (query.courierId)
            where.courierId = query.courierId;
        if (query.originBranchId) {
            where.AND.push({ originBranchId: query.originBranchId });
        }
        if (query.search) {
            where.OR = [
                { trackingNumber: { contains: query.search, mode: 'insensitive' } },
                { senderName: { contains: query.search, mode: 'insensitive' } },
                { senderPhone: { contains: query.search } },
                { receiverName: { contains: query.search, mode: 'insensitive' } },
                { receiverPhone: { contains: query.search } },
            ];
        }
        const page = query.page || 1;
        const limit = query.limit || 20;
        const skip = (page - 1) * limit;
        const [data, total] = await Promise.all([
            this.prisma.order.findMany({
                where,
                include: {
                    sender: { select: { id: true, name: true, phone: true } },
                    receiver: { select: { id: true, name: true, phone: true } },
                    courier: {
                        select: {
                            id: true,
                            name: true,
                            phone: true,
                            currentLat: true,
                            currentLng: true,
                            lastSeenAt: true,
                            isOnline: true,
                        },
                    },
                    originBranch: { select: { id: true, name: true, code: true } },
                    destBranch: { select: { id: true, name: true, code: true } },
                    _count: { select: { items: true } },
                },
                orderBy: { createdAt: 'desc' },
                skip,
                take: limit,
            }),
            this.prisma.order.count({ where }),
        ]);
        return { data, total, page, limit, pages: Math.ceil(total / limit) };
    }
    async findOne(id, currentUser) {
        const order = await this.prisma.order.findFirst({
            where: { AND: [{ id }, this.orderScope(currentUser)] },
            include: {
                items: true,
                sender: { select: { id: true, name: true, phone: true, email: true } },
                receiver: { select: { id: true, name: true, phone: true, email: true } },
                courier: {
                    select: {
                        id: true,
                        name: true,
                        phone: true,
                        vehicleType: true,
                        vehiclePlate: true,
                        rating: true,
                        currentLat: true,
                        currentLng: true,
                    },
                },
                originBranch: { select: { id: true, name: true, code: true } },
                destBranch: { select: { id: true, name: true, code: true } },
                createdBy: { select: { id: true, name: true } },
                events: { orderBy: { createdAt: 'desc' }, take: 50 },
                receiverLinks: {
                    orderBy: { createdAt: 'desc' },
                    select: {
                        id: true,
                        shortCode: true,
                        status: true,
                        expiresAt: true,
                        openedAt: true,
                        filledAt: true,
                        otpVerified: true,
                    },
                },
                payments: true,
            },
        });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        return order;
    }
    async update(id, dto, currentUser) {
        const existing = await this.prisma.order.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException('Order not found');
        await this.assertOrderAccess(id, currentUser);
        if (existing.status === client_1.OrderStatus.DELIVERED ||
            existing.status === client_1.OrderStatus.CANCELLED) {
            throw new common_1.BadRequestException(`Cannot edit a ${existing.status} order`);
        }
        const data = {};
        if (dto.senderName !== undefined)
            data.senderName = dto.senderName;
        if (dto.senderAddress !== undefined)
            data.senderAddress = dto.senderAddress;
        if (dto.receiverName !== undefined)
            data.receiverName = dto.receiverName;
        if (dto.receiverAddress !== undefined)
            data.receiverAddress = dto.receiverAddress;
        if (dto.receiverLat !== undefined)
            data.receiverLat = dto.receiverLat;
        if (dto.receiverLng !== undefined)
            data.receiverLng = dto.receiverLng;
        const receiverLat = dto.receiverLat ?? existing.receiverLat;
        const receiverLng = dto.receiverLng ?? existing.receiverLng;
        data.distanceKm =
            existing.senderLat != null &&
                existing.senderLng != null &&
                receiverLat != null &&
                receiverLng != null
                ? this.pricing.distanceKm(existing.senderLat, existing.senderLng, receiverLat, receiverLng)
                : null;
        if (dto.packageDescription !== undefined)
            data.packageDescription = dto.packageDescription;
        if (dto.paymentParty !== undefined)
            data.paymentParty = dto.paymentParty;
        if (dto.codAmount !== undefined)
            data.codAmount = dto.codAmount;
        const updated = await this.prisma.order.update({ where: { id }, data });
        this.trackingWs.broadcastStatusChange(id, {
            status: updated.status,
            note: 'Order updated',
            timestamp: new Date().toISOString(),
        });
        return updated;
    }
    async assignCourier(orderId, courierId, currentUser) {
        const order = await this.prisma.order.findUnique({ where: { id: orderId } });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        await this.assertOrderAccess(orderId, currentUser);
        if (order.status === client_1.OrderStatus.DELIVERED ||
            order.status === client_1.OrderStatus.CANCELLED) {
            throw new common_1.BadRequestException(`Cannot assign courier to a ${order.status} order`);
        }
        if (order.courierId) {
            throw new common_1.BadRequestException('Order already has a courier assigned');
        }
        const courier = await this.prisma.courier.findUnique({ where: { id: courierId } });
        if (!courier)
            throw new common_1.NotFoundException('Courier not found');
        if (currentUser.role === client_1.StaffRole.BRANCH_MANAGER &&
            courier.branchId !== currentUser.branchId) {
            throw new common_1.ForbiddenException('You can only assign couriers from your branch');
        }
        if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN) {
            const branch = order.originBranchId
                ? await this.prisma.branch.findUnique({
                    where: { id: order.originBranchId },
                    select: { regionId: true },
                })
                : null;
            if (courier.regionId !== currentUser.regionId ||
                !branch ||
                branch.regionId !== currentUser.regionId) {
                throw new common_1.ForbiddenException('Order and courier must be in your region');
            }
        }
        if (courier.status !== 'APPROVED') {
            throw new common_1.BadRequestException('Courier must be approved');
        }
        if (!courier.isActive) {
            throw new common_1.BadRequestException('Courier is suspended');
        }
        if (courier.maxWeightKg != null && order.totalWeightKg > courier.maxWeightKg) {
            throw new common_1.BadRequestException(`Courier capacity: ${courier.maxWeightKg} kg, order: ${order.totalWeightKg} kg`);
        }
        if (order.isFragile && !courier.handlesFragile) {
            throw new common_1.BadRequestException('Courier does not handle fragile items');
        }
        if (order.isRefrigerated && !courier.handlesRefrigerated) {
            throw new common_1.BadRequestException('Courier does not handle refrigerated items');
        }
        const updated = await this.prisma.$transaction(async (tx) => {
            const o = await tx.order.update({
                where: { id: orderId },
                data: {
                    courierId,
                    status: client_1.OrderStatus.ASSIGNED,
                    assignedAt: new Date(),
                },
                include: {
                    courier: { select: { id: true, name: true, phone: true } },
                },
            });
            await tx.orderEvent.create({
                data: {
                    orderId,
                    status: client_1.OrderStatus.ASSIGNED,
                    note: `Assigned to courier ${courier.name}`,
                    actorType: client_1.AccountType.STAFF,
                    actorId: currentUser.id,
                    actorName: currentUser.name,
                    isPublic: true,
                },
            });
            return o;
        });
        this.trackingWs.broadcastStatusChange(orderId, {
            status: client_1.OrderStatus.ASSIGNED,
            note: `Courier ${courier.name} assigned`,
            timestamp: new Date().toISOString(),
        });
        await this.notifications.notifyOrderStatus(updated);
        return updated;
    }
    async autoAssignCourier(orderId, currentUser) {
        const order = await this.prisma.order.findUnique({ where: { id: orderId } });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        await this.assertOrderAccess(orderId, currentUser);
        if (order.courierId) {
            throw new common_1.BadRequestException('Order already has a courier');
        }
        let requiredVehicles = [];
        if (order.totalWeightKg <= 25) {
            requiredVehicles = ['MOTORCYCLE', 'BICYCLE', 'CAR'];
        }
        else if (order.totalWeightKg <= 500) {
            requiredVehicles = ['CAR', 'VAN'];
        }
        else {
            requiredVehicles = ['VAN', 'TRUCK'];
        }
        const where = {
            status: 'APPROVED',
            isActive: true,
            vehicleType: { in: requiredVehicles },
        };
        if (order.originBranchId)
            where.branchId = order.originBranchId;
        if (order.isFragile)
            where.handlesFragile = true;
        if (order.isRefrigerated)
            where.handlesRefrigerated = true;
        const candidates = await this.prisma.courier.findMany({ where });
        if (!candidates.length) {
            throw new common_1.BadRequestException('No available courier matching requirements');
        }
        const sorted = candidates
            .map((c) => ({
            ...c,
            distance: c.currentLat != null &&
                c.currentLng != null &&
                order.senderLat != null &&
                order.senderLng != null
                ? this.pricing.distanceKm(c.currentLat, c.currentLng, order.senderLat, order.senderLng)
                : 999999,
        }))
            .sort((a, b) => a.distance - b.distance);
        return this.assignCourier(orderId, sorted[0].id, currentUser);
    }
    async updateCourierLocation(orderId, lat, lng, currentUser) {
        const order = await this.prisma.order.findUnique({ where: { id: orderId } });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        await this.assertOrderAccess(orderId, currentUser);
        if (!order.courierId)
            throw new common_1.BadRequestException('No courier assigned');
        if (lat < 3.4 || lat > 14.9 || lng < 32.9 || lng > 48.0) {
            throw new common_1.BadRequestException('Coordinates outside Ethiopia');
        }
        let distanceToReceiver;
        let etaMinutes;
        if (order.receiverLat != null && order.receiverLng != null) {
            distanceToReceiver = this.pricing.distanceKm(lat, lng, order.receiverLat, order.receiverLng);
            etaMinutes = Math.ceil((distanceToReceiver / 30) * 60);
        }
        await this.prisma.$transaction([
            this.prisma.courier.update({
                where: { id: order.courierId },
                data: {
                    currentLat: lat,
                    currentLng: lng,
                    lastSeenAt: new Date(),
                    isOnline: true,
                },
            }),
            this.prisma.order.update({
                where: { id: orderId },
                data: {
                    lastCourierLat: lat,
                    lastCourierLng: lng,
                    lastTrackedAt: new Date(),
                    estimatedArrival: etaMinutes
                        ? new Date(Date.now() + etaMinutes * 60 * 1000)
                        : undefined,
                },
            }),
        ]);
        this.trackingWs.broadcastLocationUpdate(orderId, {
            lat,
            lng,
            courierId: order.courierId,
            timestamp: new Date().toISOString(),
            distanceToReceiver,
            etaMinutes,
            status: order.status,
        });
        if (distanceToReceiver != null) {
            const distanceMeters = distanceToReceiver * 1000;
            if (distanceMeters < 20) {
                this.trackingWs.broadcastProximityAlert(orderId, {
                    level: 'AT_DOOR',
                    distanceMeters,
                    message: '🚪 Courier is at your door',
                });
            }
            else if (distanceMeters < 100) {
                this.trackingWs.broadcastProximityAlert(orderId, {
                    level: 'ARRIVING',
                    distanceMeters,
                    message: '🔔 Courier is arriving',
                });
            }
            else if (distanceMeters < 500) {
                this.trackingWs.broadcastProximityAlert(orderId, {
                    level: 'CLOSE',
                    distanceMeters,
                    message: '⏱️ Courier is 5 minutes away',
                });
            }
            else if (distanceMeters < 2000) {
                this.trackingWs.broadcastProximityAlert(orderId, {
                    level: 'NEARBY',
                    distanceMeters,
                    message: '📍 Courier is nearby',
                });
            }
        }
        return {
            lat,
            lng,
            distanceToReceiver,
            etaMinutes,
            timestamp: new Date().toISOString(),
        };
    }
    async sendReceiverLink(id, dto, currentUser) {
        const order = await this.prisma.order.findUnique({ where: { id } });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        await this.assertOrderAccess(id, currentUser);
        if (order.status !== client_1.OrderStatus.AWAITING_RECEIVER_LOCATION) {
            throw new common_1.BadRequestException('Order does not need receiver location');
        }
        const link = await this.receiverLinks.createForOrder(order.id, order.receiverPhone, currentUser.id);
        const smsSent = dto.sendSms === false
            ? null
            : await this.sms.sendReceiverLink(order.receiverPhone, order.senderName, link.url);
        if (smsSent === false) {
            console.error(`Receiver link SMS was not accepted for order ${order.id}`);
        }
        return { link, smsSent };
    }
    async cancel(id, currentUser) {
        const order = await this.prisma.order.findUnique({ where: { id } });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        await this.assertOrderAccess(id, currentUser);
        if (order.status === client_1.OrderStatus.DELIVERED) {
            throw new common_1.BadRequestException('Cannot cancel a delivered order');
        }
        await this.prisma.$transaction(async (tx) => {
            await tx.order.update({
                where: { id },
                data: {
                    status: client_1.OrderStatus.CANCELLED,
                    cancelledAt: new Date(),
                },
            });
            await tx.orderEvent.create({
                data: {
                    orderId: id,
                    status: client_1.OrderStatus.CANCELLED,
                    note: 'Order cancelled',
                    actorType: client_1.AccountType.STAFF,
                    actorId: currentUser.id,
                    actorName: currentUser.name,
                },
            });
        });
        this.trackingWs.broadcastOrderEnd(id, {
            outcome: 'CANCELLED',
            message: 'Order cancelled by staff',
        });
        await this.notifications.notifyOrderStatus({
            ...order,
            status: client_1.OrderStatus.CANCELLED,
        });
        return { message: 'Order cancelled' };
    }
    async unassignCourier(orderId, currentUser) {
        const order = await this.prisma.order.findUnique({ where: { id: orderId } });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        await this.assertOrderAccess(orderId, currentUser);
        if (!order.courierId) {
            throw new common_1.BadRequestException('Order has no courier assigned');
        }
        const blocked = [
            client_1.OrderStatus.PICKED_UP,
            client_1.OrderStatus.IN_TRANSIT,
            client_1.OrderStatus.OUT_FOR_DELIVERY,
            client_1.OrderStatus.DELIVERED,
            client_1.OrderStatus.CANCELLED,
        ];
        if (blocked.includes(order.status)) {
            throw new common_1.BadRequestException(`Cannot unassign courier when order is ${order.status.replace(/_/g, ' ')}`);
        }
        const previousCourier = await this.prisma.courier.findUnique({
            where: { id: order.courierId },
        });
        await this.prisma.$transaction(async (tx) => {
            await tx.order.update({
                where: { id: orderId },
                data: {
                    courierId: null,
                    status: client_1.OrderStatus.PENDING_PAYMENT,
                    assignedAt: null,
                },
            });
            await tx.orderEvent.create({
                data: {
                    orderId,
                    status: client_1.OrderStatus.PENDING_PAYMENT,
                    note: previousCourier
                        ? `Courier ${previousCourier.name} unassigned`
                        : 'Courier unassigned',
                    actorType: client_1.AccountType.STAFF,
                    actorId: currentUser.id,
                    actorName: currentUser.name,
                    isPublic: true,
                },
            });
        });
        this.trackingWs.broadcastStatusChange(orderId, {
            status: client_1.OrderStatus.PENDING_PAYMENT,
            note: 'Courier unassigned',
            timestamp: new Date().toISOString(),
        });
        return { message: 'Courier unassigned' };
    }
    async remove(id, currentUser) {
        const order = await this.prisma.order.findUnique({
            where: { id },
            include: {
                _count: {
                    select: {
                        items: true,
                        events: true,
                        receiverLinks: true,
                        payments: true,
                    },
                },
            },
        });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        if (currentUser.role !== client_1.StaffRole.SUPER_ADMIN) {
            throw new common_1.ForbiddenException('Only SUPER_ADMIN can delete orders');
        }
        const BLOCKED = [
            client_1.OrderStatus.PICKED_UP,
            client_1.OrderStatus.IN_TRANSIT,
            client_1.OrderStatus.OUT_FOR_DELIVERY,
            client_1.OrderStatus.DELIVERED,
        ];
        if (BLOCKED.includes(order.status)) {
            throw new common_1.BadRequestException(`Cannot delete an order with status ${order.status.replace(/_/g, ' ')}. Cancel it instead.`);
        }
        await this.prisma.$transaction(async (tx) => {
            await tx.orderEvent.deleteMany({ where: { orderId: id } });
            await tx.receiverLink.deleteMany({ where: { orderId: id } });
            await tx.payment.deleteMany({ where: { orderId: id } });
            await tx.orderItem.deleteMany({ where: { orderId: id } });
            await tx.order.delete({ where: { id } });
        });
        this.trackingWs.broadcastOrderEnd(id, {
            outcome: 'CANCELLED',
            message: 'Order was deleted',
        });
        return { message: 'Order deleted', id };
    }
    async resolveOrderFromScan(input) {
        const raw = (input.code ?? input.trackingNumber ?? input.orderId ?? '').trim();
        if (!raw) {
            throw new common_1.BadRequestException('QR code content, tracking number, or order ID is required');
        }
        let trackingNumber = input.trackingNumber;
        let trackingToken;
        let signature = input.signature;
        let orderId = input.orderId;
        if (raw.startsWith('http://') ||
            raw.startsWith('https://') ||
            raw.startsWith('/')) {
            try {
                const url = new URL(raw, 'https://dummy.local');
                if (!signature && url.searchParams.get('s')) {
                    signature = url.searchParams.get('s');
                }
                const pathname = url.pathname;
                const qMatch = pathname.match(/\/q\/([^/?#]+)/i);
                if (qMatch) {
                    trackingNumber = decodeURIComponent(qMatch[1]);
                }
                const tMatch = pathname.match(/\/(?:t|track)\/([^/?#]+)/i);
                if (tMatch) {
                    trackingToken = decodeURIComponent(tMatch[1]);
                }
                const oMatch = pathname.match(/\/orders\/([^/?#]+)/i);
                if (oMatch) {
                    orderId = decodeURIComponent(oMatch[1]);
                }
            }
            catch {
            }
        }
        if (raw.startsWith('{') && raw.endsWith('}')) {
            try {
                const parsed = JSON.parse(raw);
                if (parsed.trackingNumber)
                    trackingNumber = parsed.trackingNumber;
                if (parsed.trackingToken)
                    trackingToken = parsed.trackingToken;
                if (parsed.id)
                    orderId = parsed.id;
                if (parsed.signature && !signature)
                    signature = parsed.signature;
            }
            catch {
            }
        }
        if (!trackingNumber && raw.includes('?s=')) {
            const [part1, part2] = raw.split('?s=');
            trackingNumber = part1.trim();
            if (!signature)
                signature = part2.trim();
        }
        const candidates = [];
        if (orderId)
            candidates.push({ id: orderId });
        if (trackingNumber)
            candidates.push({ trackingNumber });
        if (trackingToken)
            candidates.push({ trackingToken });
        candidates.push({ trackingNumber: raw });
        candidates.push({ id: raw });
        candidates.push({ trackingToken: raw });
        candidates.push({ qrCodePayload: raw });
        candidates.push({ trackingUrl: raw });
        const order = await this.prisma.order.findFirst({
            where: {
                OR: candidates,
            },
            include: {
                originBranch: { select: { id: true, name: true, code: true } },
                destBranch: { select: { id: true, name: true, code: true } },
                courier: { select: { id: true, name: true, phone: true } },
            },
        });
        if (!order) {
            throw new common_1.NotFoundException(`Order not found for scanned code: ${raw}`);
        }
        if (signature) {
            const isQrValid = (order.qrCodeSignature && order.qrCodeSignature === signature) ||
                this.qr.verifySignature(order.trackingNumber, signature, 'qr');
            const isTrackingValid = order.trackingToken
                ? this.qr.verifySignature(order.trackingToken, signature, 'tracking')
                : false;
            if (!isQrValid && !isTrackingValid) {
                throw new common_1.BadRequestException('Invalid QR signature');
            }
        }
        return order;
    }
    async staffScanLookup(dto, currentUser) {
        const order = await this.resolveOrderFromScan({
            code: dto.code,
            signature: dto.signature,
            orderId: dto.orderId,
            trackingNumber: dto.trackingNumber,
        });
        const fullOrder = await this.prisma.order.findUnique({
            where: { id: order.id },
            include: {
                items: true,
                sender: { select: { id: true, name: true, phone: true } },
                receiver: { select: { id: true, name: true, phone: true } },
                courier: { select: { id: true, name: true, phone: true } },
                originBranch: { select: { id: true, name: true, code: true } },
                destBranch: { select: { id: true, name: true, code: true } },
            },
        });
        if (!fullOrder)
            throw new common_1.NotFoundException('Order not found');
        return {
            success: true,
            order: fullOrder,
        };
    }
    async staffScanIn(dto, currentUser) {
        const order = await this.resolveOrderFromScan({
            code: dto.code,
            signature: dto.signature,
            orderId: dto.orderId,
            trackingNumber: dto.trackingNumber,
        });
        if (order.status === client_1.OrderStatus.DELIVERED) {
            throw new common_1.BadRequestException('Order has already been delivered');
        }
        if (order.status === client_1.OrderStatus.CANCELLED ||
            order.status === client_1.OrderStatus.RETURNED) {
            throw new common_1.BadRequestException(`Cannot scan in order: order is ${order.status.toLowerCase()}`);
        }
        const staff = await this.prisma.staff.findUnique({
            where: { id: currentUser.id },
            include: { branch: true, region: true },
        });
        if (!staff)
            throw new common_1.NotFoundException('Staff not found');
        const branchName = staff.branch?.name ?? (staff.region ? `${staff.region.name} Warehouse` : 'Warehouse');
        const cityName = staff.branch?.city ?? staff.region?.name ?? 'Branch';
        const isOriginIntake = order.originBranchId === staff.branchId &&
            (order.status === client_1.OrderStatus.DRAFT ||
                order.status === client_1.OrderStatus.PENDING_PAYMENT ||
                order.status === client_1.OrderStatus.PAID ||
                order.status === client_1.OrderStatus.AWAITING_RECEIVER_LOCATION);
        const nextStatus = isOriginIntake
            ? (order.status === client_1.OrderStatus.DRAFT ? client_1.OrderStatus.PENDING_PAYMENT : order.status)
            : client_1.OrderStatus.OUT_FOR_DELIVERY;
        const eventNote = dto.note ??
            (isOriginIntake
                ? `Received at ${branchName} (${cityName}) by ${staff.name} — ready for driver pickup`
                : `Arrived at ${branchName} (${cityName}) and held by ${staff.name} — ready for customer pickup or dispatch`);
        let targetDestBranchId = order.destBranchId;
        if (!isOriginIntake && !targetDestBranchId) {
            if (staff.branchId) {
                targetDestBranchId = staff.branchId;
            }
            else if (staff.regionId) {
                const regionalBranch = await this.prisma.branch.findFirst({
                    where: { regionId: staff.regionId },
                    select: { id: true },
                });
                if (regionalBranch)
                    targetDestBranchId = regionalBranch.id;
            }
        }
        const updated = await this.prisma.$transaction(async (tx) => {
            const res = await tx.order.update({
                where: { id: order.id },
                data: {
                    status: nextStatus,
                    ...(!isOriginIntake && targetDestBranchId
                        ? { destBranchId: targetDestBranchId }
                        : {}),
                    ...(dto.lat != null ? { lastCourierLat: dto.lat } : {}),
                    ...(dto.lng != null ? { lastCourierLng: dto.lng } : {}),
                    ...(dto.lat != null || dto.lng != null
                        ? { lastTrackedAt: new Date() }
                        : {}),
                },
                include: {
                    items: true,
                    sender: { select: { id: true, name: true, phone: true } },
                    receiver: { select: { id: true, name: true, phone: true } },
                    originBranch: { select: { id: true, name: true, code: true } },
                    destBranch: { select: { id: true, name: true, code: true } },
                    courier: { select: { id: true, name: true, phone: true } },
                },
            });
            await tx.orderEvent.create({
                data: {
                    orderId: order.id,
                    status: nextStatus,
                    note: eventNote,
                    actorType: client_1.AccountType.STAFF,
                    actorId: staff.id,
                    actorName: staff.name,
                    location: `${branchName} (${cityName})`,
                    lat: dto.lat ?? staff.branch?.lat ?? undefined,
                    lng: dto.lng ?? staff.branch?.lng ?? undefined,
                    isPublic: true,
                },
            });
            return res;
        });
        this.trackingWs.broadcastStatusChange(order.id, {
            status: nextStatus,
            note: eventNote,
            location: `${branchName} (${cityName})`,
            lat: dto.lat ?? staff.branch?.lat ?? undefined,
            lng: dto.lng ?? staff.branch?.lng ?? undefined,
            timestamp: new Date().toISOString(),
        });
        if (isOriginIntake) {
            void this.sms
                .sendCustomSms(order.senderPhone, `Your package ${order.trackingNumber} has been received at ${branchName}. We will dispatch it shortly.`)
                .catch(() => { });
            void this.notifications.notifyCustomToCustomer(order.senderId, {
                title: `Package Received at ${branchName} 📦`,
                body: `Your package #${order.trackingNumber} was received at ${branchName}.`,
                data: {
                    type: 'ORDER_AT_WAREHOUSE',
                    orderId: order.id,
                    trackingNumber: order.trackingNumber,
                    branchName,
                },
            });
        }
        else {
            void this.sms
                .sendArrivedAtBranch(order.receiverPhone, order.trackingNumber, branchName, true)
                .catch(() => { });
            void this.notifications.notifyCustomToCustomer(order.receiverId, {
                title: `Package Arrived in ${cityName} 📍`,
                body: `Your package #${order.trackingNumber} has arrived at ${branchName}. It is ready for pickup at our office!`,
                data: {
                    type: 'ORDER_ARRIVED_BRANCH',
                    orderId: order.id,
                    trackingNumber: order.trackingNumber,
                    branchName,
                    city: cityName,
                },
            });
            void this.sms
                .sendArrivedAtBranch(order.senderPhone, order.trackingNumber, branchName, false)
                .catch(() => { });
            void this.notifications.notifyCustomToCustomer(order.senderId, {
                title: `Package Arrived at Destination 📍`,
                body: `Your package #${order.trackingNumber} has arrived at ${branchName} (${cityName}) and is ready for pickup.`,
                data: {
                    type: 'ORDER_ARRIVED_BRANCH',
                    orderId: order.id,
                    trackingNumber: order.trackingNumber,
                    branchName,
                    city: cityName,
                },
            });
        }
        return {
            success: true,
            action: isOriginIntake ? 'origin_intake' : 'destination_arrival',
            status: nextStatus,
            warehouse: branchName,
            city: cityName,
            staffName: staff.name,
            order: {
                id: updated.id,
                trackingNumber: updated.trackingNumber,
                status: updated.status,
                originBranch: updated.originBranch?.name,
                destBranch: updated.destBranch?.name,
                courier: updated.courier?.name,
                receiverName: updated.receiverName,
                receiverPhone: updated.receiverPhone,
                senderName: updated.senderName,
                senderPhone: updated.senderPhone,
            },
            message: isOriginIntake
                ? `Order ${order.trackingNumber} received at ${branchName} by ${staff.name}`
                : `Order ${order.trackingNumber} arrived at ${branchName} (${cityName}). Notifications sent to receiver and sender.`,
        };
    }
    async warehouseScope(query, currentUser) {
        const staff = await this.prisma.staff.findUnique({
            where: { id: currentUser.id },
            select: { id: true, name: true, branchId: true, regionId: true, role: true },
        });
        if (!staff)
            throw new common_1.NotFoundException('Staff not found');
        if (query.branchId) {
            if (staff.role === client_1.StaffRole.BRANCH_MANAGER && query.branchId !== staff.branchId) {
                throw new common_1.ForbiddenException('You can only view your own branch');
            }
            return {
                staff,
                branchFilter: { destBranchId: query.branchId },
                label: 'branch',
            };
        }
        if (staff.role === client_1.StaffRole.SUPER_ADMIN) {
            return { staff, branchFilter: {}, label: 'all' };
        }
        if (staff.role === client_1.StaffRole.REGIONAL_ADMIN) {
            if (!staff.regionId) {
                throw new common_1.ForbiddenException('Regional admin has no region assigned');
            }
            return {
                staff,
                branchFilter: { destBranch: { regionId: staff.regionId } },
                label: 'region',
            };
        }
        if (staff.role === client_1.StaffRole.BRANCH_MANAGER) {
            if (!staff.branchId) {
                throw new common_1.ForbiddenException('Branch manager has no branch assigned');
            }
            return {
                staff,
                branchFilter: { destBranchId: staff.branchId },
                label: 'branch',
            };
        }
        throw new common_1.ForbiddenException('You are not allowed to access warehouse inventory');
    }
    async warehouseInventory(query, currentUser) {
        const staff = await this.prisma.staff.findUnique({
            where: { id: currentUser.id },
            select: { id: true, name: true, branchId: true, regionId: true, role: true },
        });
        if (!staff)
            throw new common_1.NotFoundException('Staff not found');
        let scopeFilter;
        if (query.branchId) {
            if (staff.role === client_1.StaffRole.BRANCH_MANAGER &&
                query.branchId !== staff.branchId) {
                throw new common_1.ForbiddenException('You can only view your own branch');
            }
            scopeFilter = {
                OR: [
                    { destBranchId: query.branchId },
                    { originBranchId: query.branchId },
                ],
            };
        }
        else if (staff.role === client_1.StaffRole.SUPER_ADMIN) {
            scopeFilter = {};
        }
        else if (staff.role === client_1.StaffRole.REGIONAL_ADMIN) {
            if (!staff.regionId) {
                throw new common_1.ForbiddenException('Regional admin has no region assigned');
            }
            scopeFilter = {
                OR: [
                    { destBranch: { regionId: staff.regionId } },
                    { originBranch: { regionId: staff.regionId } },
                ],
            };
        }
        else if (staff.role === client_1.StaffRole.BRANCH_MANAGER) {
            if (!staff.branchId) {
                throw new common_1.ForbiddenException('Branch manager has no branch assigned');
            }
            scopeFilter = {
                OR: [
                    { destBranchId: staff.branchId },
                    { originBranchId: staff.branchId },
                ],
            };
        }
        else {
            throw new common_1.ForbiddenException('You are not allowed to access warehouse inventory');
        }
        const where = {
            AND: [
                scopeFilter,
                {
                    status: {
                        notIn: [
                            client_1.OrderStatus.CANCELLED,
                            client_1.OrderStatus.RETURNED,
                            client_1.OrderStatus.FAILED,
                        ],
                    },
                },
            ],
        };
        if (query.search) {
            where.AND.push({
                OR: [
                    { trackingNumber: { contains: query.search, mode: 'insensitive' } },
                    { senderName: { contains: query.search, mode: 'insensitive' } },
                    { receiverName: { contains: query.search, mode: 'insensitive' } },
                    { receiverPhone: { contains: query.search } },
                    { senderPhone: { contains: query.search } },
                ],
            });
        }
        const raw = await this.prisma.order.findMany({
            where,
            take: 500,
            orderBy: { createdAt: 'desc' },
            include: {
                items: { select: { id: true, description: true, quantity: true } },
                originBranch: { select: { id: true, name: true, code: true, city: true } },
                destBranch: { select: { id: true, name: true, code: true, city: true } },
                courier: { select: { id: true, name: true, phone: true } },
                events: {
                    where: { actorType: 'STAFF' },
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                    select: {
                        id: true, status: true, note: true,
                        actorName: true, actorId: true, createdAt: true,
                        location: true,
                    },
                },
            },
        });
        const myBranchId = staff.branchId;
        const isSuperAdmin = staff.role === client_1.StaffRole.SUPER_ADMIN;
        const postPickupStatuses = [
            client_1.OrderStatus.PICKED_UP,
            client_1.OrderStatus.IN_TRANSIT,
            client_1.OrderStatus.OUT_FOR_DELIVERY,
            client_1.OrderStatus.DELIVERED,
        ];
        const classify = (order, lastEvent) => {
            const note = lastEvent?.note ?? '';
            const isOriginIntake = note.startsWith('Received at');
            const isDestArrival = note.startsWith('Arrived at');
            const isDispatched = note.startsWith('Dispatched');
            const isHandedOver = note.startsWith('Handed over');
            const hasLeftOrigin = postPickupStatuses.includes(order.status);
            if (isOriginIntake) {
                if (isSuperAdmin)
                    return hasLeftOrigin ? 'LEFT_WAREHOUSE' : 'IN_WAREHOUSE';
                const isMyOrigin = order.originBranchId === myBranchId;
                if (!isMyOrigin)
                    return 'NOT_MINE';
                return hasLeftOrigin ? 'LEFT_WAREHOUSE' : 'IN_WAREHOUSE';
            }
            if (isDestArrival) {
                if (isSuperAdmin)
                    return 'IN_WAREHOUSE';
                return order.destBranchId === myBranchId ? 'IN_WAREHOUSE' : 'NOT_MINE';
            }
            if (isDispatched || isHandedOver) {
                if (isSuperAdmin)
                    return 'LEFT_WAREHOUSE';
                return order.destBranchId === myBranchId ? 'LEFT_WAREHOUSE' : 'NOT_MINE';
            }
            if (isSuperAdmin)
                return 'NOT_MINE';
            const isMyOrigin = order.originBranchId === myBranchId;
            return isMyOrigin && !hasLeftOrigin ? 'IN_WAREHOUSE' : 'NOT_MINE';
        };
        const classified = raw
            .map((o) => {
            const lastStaffEvent = o.events[0] ?? null;
            return {
                ...o,
                events: undefined,
                warehouseState: classify(o, lastStaffEvent),
                lastStaffEvent,
            };
        })
            .filter((o) => o.warehouseState !== 'NOT_MINE')
            .sort((a, b) => {
            const aT = a.lastStaffEvent?.createdAt?.getTime() ?? a.createdAt.getTime();
            const bT = b.lastStaffEvent?.createdAt?.getTime() ?? b.createdAt.getTime();
            return bT - aT;
        });
        const filtered = query.state === 'in' ? classified.filter((o) => o.warehouseState === 'IN_WAREHOUSE') :
            query.state === 'out' ? classified.filter((o) => o.warehouseState === 'LEFT_WAREHOUSE') :
                classified;
        const page = query.page ?? 1;
        const limit = query.limit ?? 20;
        const skip = (page - 1) * limit;
        const data = filtered.slice(skip, skip + limit);
        return {
            data,
            total: filtered.length,
            inWarehouse: classified.filter((o) => o.warehouseState === 'IN_WAREHOUSE').length,
            leftWarehouse: classified.filter((o) => o.warehouseState === 'LEFT_WAREHOUSE').length,
            page, limit,
            pages: Math.ceil(filtered.length / limit),
        };
    }
    async warehouseHistory(query, currentUser) {
        const staff = await this.prisma.staff.findUnique({
            where: { id: currentUser.id },
            select: { id: true, branchId: true, regionId: true, role: true },
        });
        if (!staff)
            throw new common_1.NotFoundException('Staff not found');
        let scopeFilter;
        if (staff.role === client_1.StaffRole.SUPER_ADMIN) {
            scopeFilter = {};
        }
        else if (staff.role === client_1.StaffRole.REGIONAL_ADMIN) {
            scopeFilter = {
                OR: [
                    { destBranch: { regionId: staff.regionId } },
                    { originBranch: { regionId: staff.regionId } },
                ],
            };
        }
        else if (staff.role === client_1.StaffRole.BRANCH_MANAGER) {
            scopeFilter = {
                OR: [
                    { destBranchId: staff.branchId },
                    { originBranchId: staff.branchId },
                ],
            };
        }
        else {
            throw new common_1.ForbiddenException('Access denied');
        }
        const where = {
            actorType: 'STAFF',
            OR: [
                { note: { startsWith: 'Received at' } },
                { note: { startsWith: 'Arrived at' } },
                { note: { startsWith: 'Dispatched' } },
                { note: { startsWith: 'Handed over' } },
            ],
            ...(query.from || query.to
                ? {
                    createdAt: {
                        ...(query.from ? { gte: new Date(query.from) } : {}),
                        ...(query.to ? { lte: new Date(query.to) } : {}),
                    },
                }
                : {}),
        };
        if (Object.keys(scopeFilter).length > 0) {
            where.order = scopeFilter;
        }
        const page = query.page ?? 1;
        const limit = query.limit ?? 30;
        const skip = (page - 1) * limit;
        const [data, total] = await Promise.all([
            this.prisma.orderEvent.findMany({
                where,
                orderBy: { createdAt: 'desc' },
                skip,
                take: limit,
                include: {
                    order: {
                        select: {
                            id: true, trackingNumber: true, status: true,
                            senderName: true, senderPhone: true,
                            receiverName: true, receiverPhone: true,
                            destBranch: { select: { id: true, name: true, code: true } },
                            originBranch: { select: { id: true, name: true, code: true } },
                        },
                    },
                },
            }),
            this.prisma.orderEvent.count({ where }),
        ]);
        const enriched = data.map((e) => {
            const n = e.note ?? '';
            const kind = n.startsWith('Received at') || n.startsWith('Arrived at') ? 'SCAN_IN'
                : n.startsWith('Dispatched') || n.startsWith('Handed over') ? 'SCAN_OUT'
                    : 'OTHER';
            return { ...e, kind };
        });
        return {
            data: enriched,
            total, page, limit,
            pages: Math.ceil(total / limit),
        };
    }
    async warehouseStats(currentUser) {
        const staff = await this.prisma.staff.findUnique({
            where: { id: currentUser.id },
            select: { id: true, name: true, branchId: true, regionId: true, role: true },
        });
        if (!staff)
            throw new common_1.NotFoundException('Staff not found');
        let scopeFilter;
        if (staff.role === client_1.StaffRole.SUPER_ADMIN) {
            scopeFilter = {};
        }
        else if (staff.role === client_1.StaffRole.REGIONAL_ADMIN) {
            if (!staff.regionId)
                throw new common_1.ForbiddenException('Regional admin has no region');
            scopeFilter = {
                OR: [
                    { destBranch: { regionId: staff.regionId } },
                    { originBranch: { regionId: staff.regionId } },
                ],
            };
        }
        else if (staff.role === client_1.StaffRole.BRANCH_MANAGER) {
            if (!staff.branchId)
                throw new common_1.ForbiddenException('Branch manager has no branch');
            scopeFilter = {
                OR: [
                    { destBranchId: staff.branchId },
                    { originBranchId: staff.branchId },
                ],
            };
        }
        else {
            throw new common_1.ForbiddenException('Access denied');
        }
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);
        const [scanIns, scanOuts, orders] = await Promise.all([
            this.prisma.orderEvent.count({
                where: {
                    actorType: 'STAFF',
                    createdAt: { gte: startOfDay },
                    OR: [
                        { note: { startsWith: 'Received at' } },
                        { note: { startsWith: 'Arrived at' } },
                    ],
                    ...(Object.keys(scopeFilter).length > 0 ? { order: scopeFilter } : {}),
                },
            }),
            this.prisma.orderEvent.count({
                where: {
                    actorType: 'STAFF',
                    createdAt: { gte: startOfDay },
                    OR: [
                        { note: { startsWith: 'Dispatched' } },
                        { note: { startsWith: 'Handed over' } },
                    ],
                    ...(Object.keys(scopeFilter).length > 0 ? { order: scopeFilter } : {}),
                },
            }),
            this.prisma.order.findMany({
                where: {
                    AND: [
                        scopeFilter,
                        {
                            status: {
                                notIn: [client_1.OrderStatus.CANCELLED, client_1.OrderStatus.RETURNED, client_1.OrderStatus.FAILED],
                            },
                        },
                    ],
                },
                take: 500,
                include: {
                    events: {
                        where: { actorType: 'STAFF' },
                        orderBy: { createdAt: 'desc' },
                        take: 1,
                        select: { note: true },
                    },
                },
            }),
        ]);
        const myBranchId = staff.branchId;
        const isSuperAdmin = staff.role === client_1.StaffRole.SUPER_ADMIN;
        const postPickupStatuses = [
            client_1.OrderStatus.PICKED_UP,
            client_1.OrderStatus.IN_TRANSIT,
            client_1.OrderStatus.OUT_FOR_DELIVERY,
            client_1.OrderStatus.DELIVERED,
        ];
        const isInWarehouse = (o) => {
            const note = o.events[0]?.note ?? '';
            const isOriginIntake = note.startsWith('Received at');
            const isDestArrival = note.startsWith('Arrived at');
            const hasLeft = postPickupStatuses.includes(o.status);
            if (isOriginIntake) {
                if (isSuperAdmin)
                    return !hasLeft;
                return o.originBranchId === myBranchId && !hasLeft;
            }
            if (isDestArrival) {
                if (isSuperAdmin)
                    return true;
                return o.destBranchId === myBranchId;
            }
            if (isSuperAdmin)
                return false;
            return o.originBranchId === myBranchId && !hasLeft;
        };
        const inWarehouse = orders.filter(isInWarehouse).length;
        return {
            today: { scanIns, scanOuts },
            currentlyInWarehouse: inWarehouse,
            pendingDispatch: inWarehouse,
        };
    }
    async staffScanOut(dto, currentUser) {
        const order = await this.resolveOrderFromScan({
            code: dto.code,
            signature: dto.signature,
            orderId: dto.orderId,
            trackingNumber: dto.trackingNumber,
        });
        if (order.status === client_1.OrderStatus.DELIVERED) {
            throw new common_1.BadRequestException('Order has already been delivered');
        }
        if (order.status === client_1.OrderStatus.CANCELLED ||
            order.status === client_1.OrderStatus.RETURNED) {
            throw new common_1.BadRequestException(`Cannot scan out order: order is ${order.status.toLowerCase()}`);
        }
        const staff = await this.prisma.staff.findUnique({
            where: { id: currentUser.id },
            include: { branch: true, region: true },
        });
        if (!staff)
            throw new common_1.NotFoundException('Staff not found');
        const branchName = staff.branch?.name ?? (staff.region ? `${staff.region.name} Warehouse` : 'Warehouse');
        const cityName = staff.branch?.city ?? staff.region?.name ?? 'Branch';
        const action = dto.action ??
            (dto.courierId
                ? staff_scan_dto_1.StaffScanOutAction.DISPATCH
                : staff_scan_dto_1.StaffScanOutAction.HANDOVER);
        if (action === staff_scan_dto_1.StaffScanOutAction.HANDOVER) {
            const updated = await this.prisma.$transaction(async (tx) => {
                const res = await tx.order.update({
                    where: { id: order.id },
                    data: {
                        status: client_1.OrderStatus.DELIVERED,
                        deliveredAt: new Date(),
                        receiverConfirmed: true,
                        ...(dto.lat != null ? { lastCourierLat: dto.lat } : {}),
                        ...(dto.lng != null ? { lastCourierLng: dto.lng } : {}),
                        ...(dto.lat != null || dto.lng != null
                            ? { lastTrackedAt: new Date() }
                            : {}),
                    },
                    include: {
                        items: true,
                        sender: { select: { id: true, name: true, phone: true } },
                        receiver: { select: { id: true, name: true, phone: true } },
                        originBranch: { select: { id: true, name: true, code: true } },
                        destBranch: { select: { id: true, name: true, code: true } },
                        courier: { select: { id: true, name: true, phone: true } },
                    },
                });
                const eventNote = dto.note ??
                    `Handed over to receiver at ${branchName} (${cityName}) by ${staff.name}`;
                await tx.orderEvent.create({
                    data: {
                        orderId: order.id,
                        status: client_1.OrderStatus.DELIVERED,
                        note: eventNote,
                        actorType: client_1.AccountType.STAFF,
                        actorId: staff.id,
                        actorName: staff.name,
                        location: `${branchName} (${cityName})`,
                        lat: dto.lat ?? staff.branch?.lat ?? undefined,
                        lng: dto.lng ?? staff.branch?.lng ?? undefined,
                        isPublic: true,
                    },
                });
                if (order.courierEarning > 0) {
                    const pendingEarnings = await tx.courierEarning.findMany({
                        where: { orderId: order.id, status: client_1.EarningStatus.PENDING },
                    });
                    if (pendingEarnings.length > 0) {
                        await tx.courierEarning.updateMany({
                            where: { orderId: order.id, status: client_1.EarningStatus.PENDING },
                            data: {
                                status: client_1.EarningStatus.RELEASED,
                                releasedAt: new Date(),
                            },
                        });
                    }
                    else if (order.courierId) {
                        await tx.courierEarning.create({
                            data: {
                                courierId: order.courierId,
                                orderId: order.id,
                                amount: order.courierEarning,
                                currency: 'ETB',
                                type: 'DELIVERY',
                                status: client_1.EarningStatus.RELEASED,
                                releasedAt: new Date(),
                            },
                        });
                    }
                }
                return res;
            });
            this.trackingWs.broadcastOrderEnd(order.id, {
                outcome: 'DELIVERED',
                message: `Order delivered to receiver at ${branchName}`,
            });
            void this.sms
                .sendHandedOver(order.senderPhone, order.trackingNumber, branchName, false)
                .catch(() => { });
            void this.notifications.notifyCustomToCustomer(order.senderId, {
                title: `Package Delivered 🎉`,
                body: `Your package #${order.trackingNumber} was collected by the receiver at ${branchName}.`,
                data: {
                    type: 'ORDER_DELIVERED',
                    orderId: order.id,
                    trackingNumber: order.trackingNumber,
                    branchName,
                },
            });
            void this.sms
                .sendHandedOver(order.receiverPhone, order.trackingNumber, branchName, true)
                .catch(() => { });
            void this.notifications.notifyCustomToCustomer(order.receiverId, {
                title: `Package Collected 🎉`,
                body: `Package #${order.trackingNumber} has been handed over to you at ${branchName}. Thank you!`,
                data: {
                    type: 'ORDER_DELIVERED',
                    orderId: order.id,
                    trackingNumber: order.trackingNumber,
                    branchName,
                },
            });
            return {
                success: true,
                action: staff_scan_dto_1.StaffScanOutAction.HANDOVER,
                status: client_1.OrderStatus.DELIVERED,
                warehouse: branchName,
                city: cityName,
                staffName: staff.name,
                order: {
                    id: updated.id,
                    trackingNumber: updated.trackingNumber,
                    status: updated.status,
                    deliveredAt: updated.deliveredAt,
                    originBranch: updated.originBranch?.name,
                    destBranch: updated.destBranch?.name,
                    receiverName: updated.receiverName,
                    receiverPhone: updated.receiverPhone,
                    senderName: updated.senderName,
                    senderPhone: updated.senderPhone,
                },
                message: `Order ${order.trackingNumber} handed over to receiver at ${branchName} by ${staff.name}`,
            };
        }
        if (action === staff_scan_dto_1.StaffScanOutAction.DISPATCH) {
            if (!dto.courierId) {
                throw new common_1.BadRequestException('courierId is required for dispatch scan-out');
            }
            const courier = await this.prisma.courier.findUnique({
                where: { id: dto.courierId },
            });
            if (!courier) {
                throw new common_1.NotFoundException(`Courier ${dto.courierId} not found`);
            }
            const previousCourierId = order.courierId;
            const isReassigned = previousCourierId != null && previousCourierId !== courier.id;
            const updated = await this.prisma.$transaction(async (tx) => {
                const res = await tx.order.update({
                    where: { id: order.id },
                    data: {
                        courierId: courier.id,
                        status: client_1.OrderStatus.OUT_FOR_DELIVERY,
                        assignedAt: new Date(),
                    },
                    include: {
                        items: true,
                        sender: { select: { id: true, name: true, phone: true } },
                        receiver: { select: { id: true, name: true, phone: true } },
                        originBranch: { select: { id: true, name: true, code: true } },
                        destBranch: { select: { id: true, name: true, code: true } },
                        courier: { select: { id: true, name: true, phone: true } },
                    },
                });
                const eventNote = dto.note ??
                    `Dispatched to last-mile courier ${courier.name} at ${branchName} (${cityName}) by ${staff.name}`;
                await tx.orderEvent.create({
                    data: {
                        orderId: order.id,
                        status: client_1.OrderStatus.OUT_FOR_DELIVERY,
                        note: eventNote,
                        actorType: client_1.AccountType.STAFF,
                        actorId: staff.id,
                        actorName: staff.name,
                        location: `${branchName} (${cityName})`,
                        lat: dto.lat ?? staff.branch?.lat ?? undefined,
                        lng: dto.lng ?? staff.branch?.lng ?? undefined,
                        isPublic: true,
                    },
                });
                if (isReassigned && previousCourierId) {
                    await tx.courierEarning.updateMany({
                        where: {
                            orderId: order.id,
                            courierId: previousCourierId,
                            status: client_1.EarningStatus.PENDING,
                        },
                        data: { status: client_1.EarningStatus.CANCELLED },
                    });
                }
                if (order.courierEarning > 0) {
                    const myEarning = await tx.courierEarning.findFirst({
                        where: { orderId: order.id, courierId: courier.id },
                    });
                    if (!myEarning) {
                        await tx.courierEarning.create({
                            data: {
                                courierId: courier.id,
                                orderId: order.id,
                                amount: order.courierEarning,
                                currency: 'ETB',
                                type: 'DELIVERY',
                                status: client_1.EarningStatus.PENDING,
                            },
                        });
                    }
                    else if (myEarning.status === client_1.EarningStatus.CANCELLED) {
                        await tx.courierEarning.update({
                            where: { id: myEarning.id },
                            data: { status: client_1.EarningStatus.PENDING },
                        });
                    }
                }
                return res;
            });
            this.trackingWs.broadcastStatusChange(order.id, {
                status: client_1.OrderStatus.OUT_FOR_DELIVERY,
                note: `Dispatched to courier ${courier.name} at ${branchName}`,
                location: `${branchName} (${cityName})`,
                lat: dto.lat ?? staff.branch?.lat ?? undefined,
                lng: dto.lng ?? staff.branch?.lng ?? undefined,
                timestamp: new Date().toISOString(),
            });
            void this.sms
                .sendCourierAssigned(order.receiverPhone, order.trackingNumber, courier.name, courier.phone)
                .catch(() => { });
            void this.notifications.notifyCustomToCustomer(order.receiverId, {
                title: `Out for Delivery 🛵`,
                body: `Courier ${courier.name} (${courier.phone}) has been dispatched with your package #${order.trackingNumber}.`,
                data: {
                    type: 'COURIER_ASSIGNED',
                    orderId: order.id,
                    trackingNumber: order.trackingNumber,
                    courierName: courier.name,
                    courierPhone: courier.phone,
                },
            });
            return {
                success: true,
                action: staff_scan_dto_1.StaffScanOutAction.DISPATCH,
                status: client_1.OrderStatus.OUT_FOR_DELIVERY,
                warehouse: branchName,
                city: cityName,
                staffName: staff.name,
                order: {
                    id: updated.id,
                    trackingNumber: updated.trackingNumber,
                    status: updated.status,
                    originBranch: updated.originBranch?.name,
                    destBranch: updated.destBranch?.name,
                    courier: { id: courier.id, name: courier.name, phone: courier.phone },
                    receiverName: updated.receiverName,
                    receiverPhone: updated.receiverPhone,
                    senderName: updated.senderName,
                    senderPhone: updated.senderPhone,
                },
                courier: { id: courier.id, name: courier.name, phone: courier.phone },
                message: `Order ${order.trackingNumber} dispatched to last-mile courier ${courier.name}`,
            };
        }
        throw new common_1.BadRequestException(`Unknown scan-out action: ${action}`);
    }
};
exports.OrdersService = OrdersService;
exports.OrdersService = OrdersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        tracking_number_service_1.TrackingNumberService,
        pricing_service_1.PricingService,
        receiver_links_service_1.ReceiverLinksService,
        tracking_gateway_1.TrackingGateway,
        qr_service_1.QrService,
        afromessage_service_1.AfroMessageService,
        notifications_service_1.NotificationsService,
        branch_resolver_service_1.BranchResolverService])
], OrdersService);
//# sourceMappingURL=orders.service.js.map