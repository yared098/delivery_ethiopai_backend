import { PrismaService } from '../prisma/prisma.service';
export declare class TrackingNumberService {
    private prisma;
    constructor(prisma: PrismaService);
    generate(): Promise<string>;
    generateTrackingToken(): string;
    generateShortCode(): string;
    private randomCode;
}
