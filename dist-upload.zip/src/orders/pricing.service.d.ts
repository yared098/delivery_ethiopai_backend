import { ItemType } from '@prisma/client';
interface PricingInput {
    distanceKm: number;
    totalWeightKg: number;
    items: Array<{
        type: ItemType;
        quantity: number;
        isFragile?: boolean;
        isRefrigerated?: boolean;
    }>;
    regionMultiplier?: number;
}
export interface PricingBreakdown {
    baseFee: number;
    distanceCharge: number;
    weightCharge: number;
    itemSurcharges: number;
    subtotal: number;
    regionMultiplier: number;
    total: number;
    currency: string;
    [key: string]: any;
}
export declare class PricingService {
    calculate(input: PricingInput): PricingBreakdown;
    distanceKm(lat1: number, lng1: number, lat2: number, lng2: number): number;
    courierEarning(deliveryFee: number): number;
    platformFee(deliveryFee: number): number;
}
export {};
