export declare class SendReceiverLinkDto {
    sendSms?: boolean;
    sendTelegram?: boolean;
    sendWhatsapp?: boolean;
}
