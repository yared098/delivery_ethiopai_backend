import { ItemType, PaymentParty } from '@prisma/client';
export declare class CreateOrderItemDto {
    type?: ItemType;
    description: string;
    quantity?: number;
    weightKg: number;
    lengthCm?: number;
    widthCm?: number;
    heightCm?: number;
    volumeL?: number;
    declaredValue?: number;
    isFragile?: boolean;
    isRefrigerated?: boolean;
    photoUrl?: string;
}
export declare class SenderDto {
    customerId?: string;
    name: string;
    phone: string;
    address?: string;
    lat?: number;
    lng?: number;
}
export declare class ReceiverDto {
    customerId?: string;
    name?: string;
    phone: string;
    address?: string;
    lat?: number;
    lng?: number;
}
export declare class CreateOrderDto {
    sender: SenderDto;
    receiver: ReceiverDto;
    items: CreateOrderItemDto[];
    originBranchId?: string;
    destBranchId?: string;
    packageDescription?: string;
    paymentParty?: PaymentParty;
    sendReceiverLink?: boolean;
    codAmount?: number;
    notes?: string;
    courierId?: string;
    autoAssignCourier?: boolean;
}
