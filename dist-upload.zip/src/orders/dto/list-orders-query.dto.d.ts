import { OrderStatus } from '@prisma/client';
export declare class ListOrdersQueryDto {
    status?: OrderStatus;
    senderId?: string;
    receiverId?: string;
    courierId?: string;
    originBranchId?: string;
    search?: string;
    page?: number;
    limit?: number;
}
