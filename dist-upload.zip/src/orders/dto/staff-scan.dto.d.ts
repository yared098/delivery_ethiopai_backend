export declare enum StaffScanOutAction {
    HANDOVER = "handover",
    DISPATCH = "dispatch"
}
export declare class StaffScanInDto {
    code?: string;
    trackingNumber?: string;
    orderId?: string;
    signature?: string;
    note?: string;
    lat?: number;
    lng?: number;
}
export declare class StaffScanOutDto extends StaffScanInDto {
    action?: StaffScanOutAction;
    courierId?: string;
}
