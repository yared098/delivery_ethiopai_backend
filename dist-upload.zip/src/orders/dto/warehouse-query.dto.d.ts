export declare class WarehouseQueryDto {
    search?: string;
    branchId?: string;
    state?: 'in' | 'out' | 'all';
    page?: number;
    limit?: number;
}
export declare class WarehouseHistoryQueryDto extends WarehouseQueryDto {
    from?: string;
    to?: string;
}
