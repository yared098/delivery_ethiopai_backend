import { PaymentParty } from '@prisma/client';
export declare class UpdateOrderDto {
    senderName?: string;
    senderAddress?: string;
    receiverName?: string;
    receiverAddress?: string;
    receiverLat?: number;
    receiverLng?: number;
    packageDescription?: string;
    paymentParty?: PaymentParty;
    codAmount?: number;
}
