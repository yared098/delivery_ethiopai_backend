"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrackingNumberService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const crypto_1 = require("crypto");
let TrackingNumberService = class TrackingNumberService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async generate() {
        const year = new Date().getFullYear();
        const prefix = `ETH-${year}-`;
        for (let attempt = 0; attempt < 10; attempt++) {
            const code = this.randomCode(6);
            const candidate = prefix + code;
            const existing = await this.prisma.order.findUnique({
                where: { trackingNumber: candidate },
            });
            if (!existing)
                return candidate;
        }
        throw new Error('Failed to generate unique tracking number');
    }
    generateTrackingToken() {
        return (0, crypto_1.randomBytes)(16).toString('hex');
    }
    generateShortCode() {
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        let code = '';
        for (let i = 0; i < 8; i++) {
            code += chars[Math.floor(Math.random() * chars.length)];
        }
        return code;
    }
    randomCode(length) {
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
        let out = '';
        for (let i = 0; i < length; i++) {
            out += chars[Math.floor(Math.random() * chars.length)];
        }
        return out;
    }
};
exports.TrackingNumberService = TrackingNumberService;
exports.TrackingNumberService = TrackingNumberService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], TrackingNumberService);
//# sourceMappingURL=tracking-number.service.js.map