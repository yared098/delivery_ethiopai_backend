"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersModule = void 0;
const afromessage_module_1 = require("../integrations/afromessage/afromessage.module");
const auth_module_1 = require("../auth/auth.module");
const prisma_module_1 = require("../prisma/prisma.module");
const common_1 = require("@nestjs/common");
const orders_service_1 = require("./orders.service");
const orders_controller_1 = require("./orders.controller");
const pricing_service_1 = require("./pricing.service");
const tracking_number_service_1 = require("./tracking-number.service");
const receiver_links_service_1 = require("./receiver-links.service");
const receiver_link_controller_1 = require("../receiver-links/receiver-link.controller");
const tracking_module_1 = require("../tracking/tracking.module");
const qr_module_1 = require("../qr/qr.module");
const notifications_module_1 = require("../notifications/notifications.module");
const branch_resolver_service_1 = require("./branch-resolver.service");
let OrdersModule = class OrdersModule {
};
exports.OrdersModule = OrdersModule;
exports.OrdersModule = OrdersModule = __decorate([
    (0, common_1.Module)({
        imports: [
            tracking_module_1.TrackingModule,
            qr_module_1.QrModule,
            prisma_module_1.PrismaModule,
            auth_module_1.AuthModule,
            afromessage_module_1.AfroMessageModule,
            notifications_module_1.NotificationsModule,
        ],
        controllers: [
            orders_controller_1.OrdersController,
            receiver_link_controller_1.ReceiverLinkController,
        ],
        providers: [
            orders_service_1.OrdersService,
            pricing_service_1.PricingService,
            tracking_number_service_1.TrackingNumberService,
            receiver_links_service_1.ReceiverLinksService,
            branch_resolver_service_1.BranchResolverService,
        ],
        exports: [
            orders_service_1.OrdersService,
            pricing_service_1.PricingService,
            receiver_links_service_1.ReceiverLinksService,
            branch_resolver_service_1.BranchResolverService,
        ],
    })
], OrdersModule);
//# sourceMappingURL=orders.module.js.map