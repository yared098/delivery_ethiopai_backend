"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersController = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const orders_service_1 = require("./orders.service");
const create_order_dto_1 = require("./dto/create-order.dto");
const update_order_dto_1 = require("./dto/update-order.dto");
const list_orders_query_dto_1 = require("./dto/list-orders-query.dto");
const send_receiver_link_dto_1 = require("./dto/send-receiver-link.dto");
const staff_scan_dto_1 = require("./dto/staff-scan.dto");
const jwt_auth_guard_1 = require("../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../common/guards/roles.guard");
const staff_roles_decorator_1 = require("../common/decorators/staff-roles.decorator");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const client_1 = require("@prisma/client");
const warehouse_query_dto_1 = require("./dto/warehouse-query.dto");
class LocationDto {
}
__decorate([
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], LocationDto.prototype, "lat", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], LocationDto.prototype, "lng", void 0);
class AssignCourierDto {
}
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], AssignCourierDto.prototype, "courierId", void 0);
let OrdersController = class OrdersController {
    constructor(orders) {
        this.orders = orders;
    }
    scanLookup(dto, user) {
        return this.orders.staffScanLookup(dto, user);
    }
    scanIn(dto, user) {
        return this.orders.staffScanIn(dto, user);
    }
    scanOut(dto, user) {
        return this.orders.staffScanOut(dto, user);
    }
    create(dto, user) {
        return this.orders.create(dto, user);
    }
    findAll(query, user) {
        return this.orders.findAll(query, user);
    }
    findOne(id, user) {
        return this.orders.findOne(id, user);
    }
    update(id, dto, user) {
        return this.orders.update(id, dto, user);
    }
    assignCourier(id, dto, user) {
        return this.orders.assignCourier(id, dto.courierId, user);
    }
    autoAssign(id, user) {
        return this.orders.autoAssignCourier(id, user);
    }
    unassignCourier(id, user) {
        return this.orders.unassignCourier(id, user);
    }
    updateLocation(id, dto, user) {
        return this.orders.updateCourierLocation(id, dto.lat, dto.lng, user);
    }
    sendReceiverLink(id, dto, user) {
        return this.orders.sendReceiverLink(id, dto, user);
    }
    cancel(id, user) {
        return this.orders.cancel(id, user);
    }
    remove(id, user) {
        return this.orders.remove(id, user);
    }
    warehouseInventory(q, user) {
        return this.orders.warehouseInventory(q, user);
    }
    warehouseHistory(q, user) {
        return this.orders.warehouseHistory(q, user);
    }
    warehouseStats(user) {
        return this.orders.warehouseStats(user);
    }
};
exports.OrdersController = OrdersController;
__decorate([
    (0, common_1.Post)('scan-lookup'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [staff_scan_dto_1.StaffScanInDto, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "scanLookup", null);
__decorate([
    (0, common_1.Post)('scan-in'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [staff_scan_dto_1.StaffScanInDto, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "scanIn", null);
__decorate([
    (0, common_1.Post)('scan-out'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [staff_scan_dto_1.StaffScanOutDto, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "scanOut", null);
__decorate([
    (0, common_1.Post)(),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_order_dto_1.CreateOrderDto, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_orders_query_dto_1.ListOrdersQueryDto, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_order_dto_1.UpdateOrderDto, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "update", null);
__decorate([
    (0, common_1.Post)(':id/assign-courier'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, AssignCourierDto, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "assignCourier", null);
__decorate([
    (0, common_1.Post)(':id/auto-assign'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "autoAssign", null);
__decorate([
    (0, common_1.Post)(':id/unassign-courier'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "unassignCourier", null);
__decorate([
    (0, common_1.Post)(':id/location'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, LocationDto, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "updateLocation", null);
__decorate([
    (0, common_1.Post)(':id/send-receiver-link'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, send_receiver_link_dto_1.SendReceiverLinkDto, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "sendReceiverLink", null);
__decorate([
    (0, common_1.Post)(':id/cancel'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "cancel", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "remove", null);
__decorate([
    (0, common_1.Get)('warehouse/inventory'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [warehouse_query_dto_1.WarehouseQueryDto, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "warehouseInventory", null);
__decorate([
    (0, common_1.Get)('warehouse/history'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [warehouse_query_dto_1.WarehouseHistoryQueryDto, Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "warehouseHistory", null);
__decorate([
    (0, common_1.Get)('warehouse/stats'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], OrdersController.prototype, "warehouseStats", null);
exports.OrdersController = OrdersController = __decorate([
    (0, common_1.Controller)(['admin/orders', 'orders']),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    __metadata("design:paramtypes", [orders_service_1.OrdersService])
], OrdersController);
//# sourceMappingURL=orders.controller.js.map