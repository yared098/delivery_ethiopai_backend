import { PrismaService } from '../prisma/prisma.service';
import { TrackingNumberService } from './tracking-number.service';
import { AfroMessageService } from '../integrations/afromessage/afromessage.service';
export declare class ReceiverLinksService {
    private prisma;
    private tracking;
    private sms;
    constructor(prisma: PrismaService, tracking: TrackingNumberService, sms: AfroMessageService);
    createForOrder(orderId: string, receiverPhone: string, createdById?: string): Promise<{
        id: string;
        shortCode: string;
        url: string;
        expiresAt: Date;
    }>;
    findByShortCode(shortCode: string): Promise<{
        order: {
            id: string;
            trackingNumber: string;
            senderName: string;
            receiverName: string | null;
            receiverPhone: string;
            totalWeightKg: number;
            packageDescription: string | null;
            status: import("@prisma/client").$Enums.OrderStatus;
        };
    } & {
        id: string;
        createdById: string | null;
        createdAt: Date;
        receiverPhone: string;
        status: import("@prisma/client").$Enums.ReceiverLinkStatus;
        purpose: string;
        expiresAt: Date;
        tokenHash: string;
        orderId: string;
        shortCode: string;
        sentViaSms: boolean;
        sentViaTelegram: boolean;
        sentViaWhatsapp: boolean;
        openedAt: Date | null;
        openedIp: string | null;
        filledAt: Date | null;
        filledIp: string | null;
        otpVerified: boolean;
        otpVerifiedAt: Date | null;
        capturedLat: number | null;
        capturedLng: number | null;
        capturedAccuracy: number | null;
        capturedSource: string | null;
    }>;
    markOpened(id: string, ip: string): Promise<void>;
    markUsed(id: string, ip: string): Promise<void>;
    revoke(linkId: string): Promise<{
        message: string;
    }>;
}
