"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var BranchResolverService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BranchResolverService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
let BranchResolverService = BranchResolverService_1 = class BranchResolverService {
    constructor(prisma) {
        this.prisma = prisma;
        this.logger = new common_1.Logger(BranchResolverService_1.name);
        this.MAX_RADIUS_KM = 500;
    }
    async findNearestBranch(lat, lng, regionId) {
        if (lat == null || lng == null)
            return null;
        if (lat === 0 && lng === 0)
            return null;
        if (lat < -90 || lat > 90 || lng < -180 || lng > 180)
            return null;
        try {
            const rows = await this.prisma.$queryRaw `
        SELECT
          b.id,
          b."regionId",
          b.name,
          b.code,
          b.city,
          (
            6371 * acos(
              LEAST(1, GREATEST(-1,
                cos(radians(${lat})) *
                cos(radians(b.lat)) *
                cos(radians(b.lng) - radians(${lng})) +
                sin(radians(${lat})) *
                sin(radians(b.lat))
              ))
            )
          ) AS distance_km
        FROM branches b
        WHERE b.lat IS NOT NULL
          AND b.lng IS NOT NULL
          AND b."isActive" = true
          AND (${regionId ?? null}::text IS NULL OR b."regionId" = ${regionId ?? null})
        ORDER BY distance_km ASC
        LIMIT 1
      `;
            const row = rows[0];
            if (!row)
                return null;
            if (row.distance_km > this.MAX_RADIUS_KM) {
                this.logger.warn(`Nearest branch ${row.name} is ${row.distance_km.toFixed(1)}km — too far`);
                return null;
            }
            return {
                id: row.id,
                regionId: row.regionId,
                name: row.name,
                code: row.code,
                city: row.city,
                distanceKm: Math.round(row.distance_km * 100) / 100,
            };
        }
        catch (e) {
            this.logger.error(`findNearestBranch failed: ${e.message}`);
            return null;
        }
    }
    async findFirstActiveBranchInRegion(regionId) {
        const branch = await this.prisma.branch.findFirst({
            where: { regionId, isActive: true },
            orderBy: { name: 'asc' },
            select: {
                id: true,
                regionId: true,
                name: true,
                code: true,
                city: true,
            },
        });
        if (!branch)
            return null;
        return { ...branch, distanceKm: 0 };
    }
    async resolveForOrder(input) {
        let originBranch = null;
        let destBranch = null;
        if (input.originBranchId) {
            originBranch = await this.getBranchById(input.originBranchId);
        }
        if (!originBranch) {
            originBranch = await this.findNearestBranch(input.senderLat, input.senderLng);
        }
        if (input.destBranchId) {
            destBranch = await this.getBranchById(input.destBranchId);
        }
        if (!destBranch) {
            destBranch = await this.findNearestBranch(input.receiverLat, input.receiverLng);
        }
        return {
            originBranchId: originBranch?.id ?? null,
            destBranchId: destBranch?.id ?? null,
            originBranch,
            destBranch,
        };
    }
    async getBranchById(id) {
        const b = await this.prisma.branch.findUnique({
            where: { id },
            select: {
                id: true,
                regionId: true,
                name: true,
                code: true,
                city: true,
                isActive: true,
            },
        });
        if (!b || !b.isActive)
            return null;
        return {
            id: b.id,
            regionId: b.regionId,
            name: b.name,
            code: b.code,
            city: b.city,
            distanceKm: 0,
        };
    }
};
exports.BranchResolverService = BranchResolverService;
exports.BranchResolverService = BranchResolverService = BranchResolverService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], BranchResolverService);
//# sourceMappingURL=branch-resolver.service.js.map