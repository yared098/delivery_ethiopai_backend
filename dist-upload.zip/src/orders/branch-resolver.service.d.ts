import { PrismaService } from '../prisma/prisma.service';
export interface ResolvedBranch {
    id: string;
    regionId: string;
    name: string;
    code: string;
    city: string | null;
    distanceKm: number;
}
export declare class BranchResolverService {
    private prisma;
    private readonly logger;
    private readonly MAX_RADIUS_KM;
    constructor(prisma: PrismaService);
    findNearestBranch(lat: number | null | undefined, lng: number | null | undefined, regionId?: string): Promise<ResolvedBranch | null>;
    findFirstActiveBranchInRegion(regionId: string): Promise<ResolvedBranch | null>;
    resolveForOrder(input: {
        originBranchId?: string | null;
        destBranchId?: string | null;
        senderLat?: number | null;
        senderLng?: number | null;
        receiverLat?: number | null;
        receiverLng?: number | null;
    }): Promise<{
        originBranchId: string | null;
        destBranchId: string | null;
        originBranch: ResolvedBranch | null;
        destBranch: ResolvedBranch | null;
    }>;
    private getBranchById;
}
