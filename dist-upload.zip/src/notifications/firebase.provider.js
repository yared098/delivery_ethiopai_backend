"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.firebaseProvider = exports.FIREBASE_MESSAGING = void 0;
const fs_1 = require("fs");
const path_1 = require("path");
const app_1 = require("firebase-admin/app");
const messaging_1 = require("firebase-admin/messaging");
exports.FIREBASE_MESSAGING = 'FIREBASE_MESSAGING';
exports.firebaseProvider = {
    provide: exports.FIREBASE_MESSAGING,
    useFactory: () => {
        if (!(0, app_1.getApps)().length) {
            const jsonPath = (0, path_1.join)(process.cwd(), 'secrets', 'firebase-service-account.json');
            let credential;
            try {
                const serviceAccount = JSON.parse((0, fs_1.readFileSync)(jsonPath, 'utf-8'));
                credential = (0, app_1.cert)(serviceAccount);
                console.log('🔥 Firebase Admin initialized (from JSON file)');
            }
            catch (err) {
                const projectId = process.env.FIREBASE_PROJECT_ID;
                const clientEmail = process.env.FIREBASE_CLIENT_EMAIL;
                const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n');
                if (!projectId || !clientEmail || !privateKey) {
                    throw new Error('Missing Firebase credentials: neither secrets/firebase-service-account.json nor env vars found');
                }
                credential = (0, app_1.cert)({ projectId, clientEmail, privateKey });
                console.log('🔥 Firebase Admin initialized (from env vars)');
            }
            (0, app_1.initializeApp)({ credential });
        }
        return (0, messaging_1.getMessaging)();
    },
};
//# sourceMappingURL=firebase.provider.js.map