export declare class UnregisterDeviceTokenDto {
    token: string;
}
