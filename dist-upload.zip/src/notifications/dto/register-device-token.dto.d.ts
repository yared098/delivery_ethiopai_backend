import { AccountType } from '@prisma/client';
export declare class RegisterDeviceTokenDto {
    token: string;
    platform: 'android' | 'ios' | 'web';
    accountType: AccountType;
}
