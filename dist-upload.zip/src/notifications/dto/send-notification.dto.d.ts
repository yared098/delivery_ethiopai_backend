import { AccountType } from '@prisma/client';
export declare class SendNotificationDto {
    accountType: AccountType;
    accountId: string;
    title: string;
    body: string;
    imageUrl?: string;
    data?: Record<string, string>;
}
export declare class BroadcastNotificationDto {
    title: string;
    body: string;
    topic?: string;
}
