import type { Messaging } from 'firebase-admin/messaging';
import { AccountType, OrderStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { TelegramNotifierService } from '../telegram/telegram-notifier.service';
export type SendOptions = {
    title: string;
    body: string;
    data?: Record<string, string>;
    imageUrl?: string;
};
export type OrderNotifyPayload = {
    id: string;
    trackingNumber: string;
    status: OrderStatus;
    senderId?: string | null;
    receiverId?: string | null;
    courierId?: string | null;
    senderAddress?: string | null;
};
export declare class NotificationsService {
    private readonly messaging;
    private readonly prisma;
    private readonly telegram;
    private readonly logger;
    constructor(messaging: Messaging, prisma: PrismaService, telegram: TelegramNotifierService);
    sendToToken(token: string, opts: SendOptions): Promise<{
        success: boolean;
        messageId: string;
        error?: undefined;
    } | {
        success: boolean;
        error: any;
        messageId?: undefined;
    }>;
    sendToAccount(accountType: AccountType, accountId: string, opts: SendOptions): Promise<{
        success: boolean;
        error: string;
        sent?: undefined;
        failed?: undefined;
    } | {
        success: boolean;
        sent: number;
        failed: number;
        error?: undefined;
    }>;
    sendToTopic(topic: string, opts: SendOptions): Promise<{
        success: boolean;
        messageId: string;
        error?: undefined;
    } | {
        success: boolean;
        error: any;
        messageId?: undefined;
    }>;
    subscribeToTopic(tokens: string[], topic: string): Promise<void>;
    unsubscribeFromTopic(tokens: string[], topic: string): Promise<void>;
    sendToCourier(courierId: string, payload: {
        title: string;
        body: string;
        data?: any;
    }): Promise<{
        success: boolean;
        error: string;
        sent?: undefined;
        failed?: undefined;
    } | {
        success: boolean;
        sent: number;
        failed: number;
        error?: undefined;
    }>;
    broadcastToStaff(payload: {
        title: string;
        body: string;
        data?: any;
    }): Promise<{
        success: boolean;
        sent: number;
        failed: number;
    }>;
    notifyCustomerWelcome(customerId: string, name?: string): Promise<{
        success: boolean;
        error: string;
        sent?: undefined;
        failed?: undefined;
    } | {
        success: boolean;
        sent: number;
        failed: number;
        error?: undefined;
    }>;
    notifyCustomToCustomer(customerId: string | null | undefined, opts: {
        title: string;
        body: string;
        data?: Record<string, string>;
    }): Promise<{
        success: boolean;
        error?: undefined;
    } | {
        success: boolean;
        error: any;
    }>;
    notifyOrderStatus(order: OrderNotifyPayload): Promise<{
        success: boolean;
        error: string;
        recipients?: undefined;
        processed?: undefined;
        pushSent?: undefined;
    } | {
        success: boolean;
        recipients: number;
        processed: number;
        pushSent: number;
        error?: undefined;
    }>;
    notifyCourierApproved(courierId: string): Promise<{
        success: boolean;
        error: string;
        sent?: undefined;
        failed?: undefined;
    } | {
        success: boolean;
        sent: number;
        failed: number;
        error?: undefined;
    }>;
    notifyCourierRejected(courierId: string, reason?: string): Promise<{
        success: boolean;
        error: string;
        sent?: undefined;
        failed?: undefined;
    } | {
        success: boolean;
        sent: number;
        failed: number;
        error?: undefined;
    }>;
    notifyPayoutPaid(courierId: string, amount: number, currency?: string): Promise<{
        success: boolean;
        error: string;
        sent?: undefined;
        failed?: undefined;
    } | {
        success: boolean;
        sent: number;
        failed: number;
        error?: undefined;
    }>;
    notifyReceiverLink(receiverPhone: string, shortCode: string): Promise<{
        success: boolean;
        error: string;
        sent?: undefined;
        failed?: undefined;
    } | {
        success: boolean;
        sent: number;
        failed: number;
        error?: undefined;
    }>;
    private handleDeadToken;
}
