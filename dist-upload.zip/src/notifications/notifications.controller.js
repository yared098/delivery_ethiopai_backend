"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var NotificationsController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationsController = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const notifications_service_1 = require("./notifications.service");
const prisma_service_1 = require("../prisma/prisma.service");
const register_device_token_dto_1 = require("./dto/register-device-token.dto");
const unregister_device_token_dto_1 = require("./dto/unregister-device-token.dto");
const send_notification_dto_1 = require("./dto/send-notification.dto");
const jwt_auth_guard_1 = require("../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../common/guards/roles.guard");
const staff_roles_decorator_1 = require("../common/decorators/staff-roles.decorator");
let NotificationsController = NotificationsController_1 = class NotificationsController {
    constructor(notifications, prisma) {
        this.notifications = notifications;
        this.prisma = prisma;
        this.logger = new common_1.Logger(NotificationsController_1.name);
    }
    async registerToken(dto, req) {
        const { id, type } = req.user;
        this.logger.log(`📱 register-token: account=${id} type=${dto.accountType} platform=${dto.platform} tokenPrefix=${dto.token.slice(0, 20)}...`);
        const data = {
            token: dto.token,
            platform: dto.platform,
            accountType: dto.accountType,
            isActive: true,
            lastUsedAt: new Date(),
            customerId: null,
            courierId: null,
            staffId: null,
        };
        if (dto.accountType === 'CUSTOMER')
            data.customerId = id;
        if (dto.accountType === 'COURIER')
            data.courierId = id;
        if (dto.accountType === 'STAFF')
            data.staffId = id;
        const saved = await this.prisma.deviceToken.upsert({
            where: { token: dto.token },
            update: data,
            create: data,
        });
        this.logger.log(`💾 Token saved (id=${saved.id})`);
        const where = {
            accountType: dto.accountType,
            isActive: true,
            NOT: { id: saved.id },
        };
        if (dto.accountType === 'CUSTOMER')
            where.customerId = id;
        if (dto.accountType === 'COURIER')
            where.courierId = id;
        if (dto.accountType === 'STAFF')
            where.staffId = id;
        const otherTokens = await this.prisma.deviceToken.findMany({
            where,
            orderBy: { lastUsedAt: 'desc' },
        });
        if (otherTokens.length > 1) {
            const toDeactivate = otherTokens.slice(1).map((t) => t.id);
            await this.prisma.deviceToken.updateMany({
                where: { id: { in: toDeactivate } },
                data: { isActive: false },
            });
            this.logger.log(`🧹 Deactivated ${toDeactivate.length} old token(s)`);
        }
        const topicMap = {
            CUSTOMER: 'customers',
            COURIER: 'couriers',
            STAFF: 'staff',
        };
        const topic = topicMap[dto.accountType];
        if (topic) {
            try {
                await this.notifications.subscribeToTopic([dto.token], topic);
                this.logger.log(`🔔 Subscribed ${dto.token.slice(0, 20)}... to "${topic}"`);
            }
            catch (e) {
                this.logger.error(`❌ Subscribe failed: ${e.message}`);
            }
        }
        else {
            this.logger.warn(`⚠️ No topic mapping for accountType=${dto.accountType}`);
        }
        return { ok: true, id: saved.id, platform: saved.platform, topic };
    }
    async unregisterToken(dto) {
        await this.prisma.deviceToken.updateMany({
            where: { token: dto.token },
            data: { isActive: false },
        });
        return { ok: true };
    }
    async test(req) {
        const { id, type } = req.user;
        this.logger.log(`🧪 test notification for ${type} ${id}`);
        return this.notifications.sendToAccount(type, id, {
            title: 'Test Notification 🔔',
            body: 'If you see this, FCM is working perfectly.',
            data: { type: 'TEST' },
        });
    }
    async sendManual(dto) {
        this.logger.log(`📤 send to ${dto.accountType} ${dto.accountId}: "${dto.title}"`);
        return this.notifications.sendToAccount(dto.accountType, dto.accountId, {
            title: dto.title,
            body: dto.body,
            imageUrl: dto.imageUrl,
            data: dto.data,
        });
    }
    async broadcast(dto) {
        if (!dto.topic) {
            return { success: false, error: 'Topic is required for broadcast' };
        }
        this.logger.log(`📢 broadcast to topic="${dto.topic}" title="${dto.title}"`);
        return this.notifications.sendToTopic(dto.topic, {
            title: dto.title,
            body: dto.body,
        });
    }
    async adminList(accountType, type, unread, search, page = '1', limit = '20') {
        const where = {};
        if (accountType)
            where.accountType = accountType;
        if (type)
            where.type = type;
        if (unread === 'true')
            where.isRead = false;
        if (search) {
            where.OR = [
                { title: { contains: search, mode: 'insensitive' } },
                { body: { contains: search, mode: 'insensitive' } },
            ];
        }
        const p = Math.max(1, Number(page));
        const l = Math.min(100, Math.max(1, Number(limit)));
        const skip = (p - 1) * l;
        const [data, total] = await Promise.all([
            this.prisma.notification.findMany({
                where,
                include: {
                    customer: { select: { id: true, name: true, phone: true } },
                    courier: { select: { id: true, name: true, phone: true } },
                    staff: { select: { id: true, name: true, phone: true } },
                    order: {
                        select: { id: true, trackingNumber: true, status: true },
                    },
                },
                orderBy: { createdAt: 'desc' },
                skip,
                take: l,
            }),
            this.prisma.notification.count({ where }),
        ]);
        return {
            data,
            total,
            page: p,
            limit: l,
            pages: Math.ceil(total / l),
        };
    }
    async adminStats() {
        const startOfToday = new Date();
        startOfToday.setHours(0, 0, 0, 0);
        const [total, unread, pushed, failed, todayCount] = await Promise.all([
            this.prisma.notification.count(),
            this.prisma.notification.count({ where: { isRead: false } }),
            this.prisma.notification.count({ where: { pushSent: true } }),
            this.prisma.notification.count({
                where: { pushError: { not: null } },
            }),
            this.prisma.notification.count({
                where: { createdAt: { gte: startOfToday } },
            }),
        ]);
        return { total, unread, pushed, failed, today: todayCount };
    }
    async listMine(req, unread, limit) {
        const { id, type } = req.user;
        const where = { accountType: type };
        if (type === 'CUSTOMER')
            where.customerId = id;
        if (type === 'COURIER')
            where.courierId = id;
        if (type === 'STAFF')
            where.staffId = id;
        if (unread === 'true')
            where.isRead = false;
        return this.prisma.notification.findMany({
            where,
            orderBy: { createdAt: 'desc' },
            take: Math.min(Number(limit) || 20, 100),
        });
    }
    async unreadCount(req) {
        const { id, type } = req.user;
        const where = { accountType: type, isRead: false };
        if (type === 'CUSTOMER')
            where.customerId = id;
        if (type === 'COURIER')
            where.courierId = id;
        if (type === 'STAFF')
            where.staffId = id;
        const count = await this.prisma.notification.count({ where });
        return { count };
    }
    async searchAccounts(type, q, limit = '20') {
        const l = Math.min(50, Math.max(1, Number(limit)));
        const query = (q || '').trim();
        const where = {};
        if (query) {
            where.OR = [
                { phone: { contains: query, mode: 'insensitive' } },
                { name: { contains: query, mode: 'insensitive' } },
            ];
        }
        if (type === 'CUSTOMER') {
            return this.prisma.customer.findMany({
                where,
                select: {
                    id: true,
                    name: true,
                    phone: true,
                    email: true,
                },
                take: l,
                orderBy: { createdAt: 'desc' },
            });
        }
        if (type === 'COURIER') {
            return this.prisma.courier.findMany({
                where,
                select: {
                    id: true,
                    name: true,
                    phone: true,
                    email: true,
                    regionId: true,
                    branchId: true,
                },
                take: l,
                orderBy: { createdAt: 'desc' },
            });
        }
        if (type === 'STAFF') {
            return this.prisma.staff.findMany({
                where,
                select: {
                    id: true,
                    name: true,
                    phone: true,
                    email: true,
                    role: true,
                },
                take: l,
                orderBy: { createdAt: 'desc' },
            });
        }
        return [];
    }
    async markRead(id, req) {
        const { id: accountId, type } = req.user;
        const where = { id, accountType: type };
        if (type === 'CUSTOMER')
            where.customerId = accountId;
        if (type === 'COURIER')
            where.courierId = accountId;
        if (type === 'STAFF')
            where.staffId = accountId;
        return this.prisma.notification.updateMany({
            where,
            data: { isRead: true, readAt: new Date() },
        });
    }
    async markAllRead(req) {
        const { id, type } = req.user;
        const where = { accountType: type, isRead: false };
        if (type === 'CUSTOMER')
            where.customerId = id;
        if (type === 'COURIER')
            where.courierId = id;
        if (type === 'STAFF')
            where.staffId = id;
        return this.prisma.notification.updateMany({
            where,
            data: { isRead: true, readAt: new Date() },
        });
    }
    async subscribeTopic(body, req) {
        const { id, type } = req.user;
        const where = { accountType: type, isActive: true };
        if (type === 'CUSTOMER')
            where.customerId = id;
        if (type === 'COURIER')
            where.courierId = id;
        if (type === 'STAFF')
            where.staffId = id;
        const tokens = await this.prisma.deviceToken.findMany({ where });
        const tokenStrings = tokens.map((t) => t.token);
        if (!tokenStrings.length) {
            return { ok: false, error: 'No active tokens' };
        }
        await this.notifications.subscribeToTopic(tokenStrings, body.topic);
        this.logger.log(`🔔 manually subscribed ${tokenStrings.length} token(s) to "${body.topic}"`);
        return { ok: true, subscribed: tokenStrings.length, topic: body.topic };
    }
    async unsubscribeTopic(body, req) {
        const { id, type } = req.user;
        const where = { accountType: type, isActive: true };
        if (type === 'CUSTOMER')
            where.customerId = id;
        if (type === 'COURIER')
            where.courierId = id;
        if (type === 'STAFF')
            where.staffId = id;
        const tokens = await this.prisma.deviceToken.findMany({ where });
        const tokenStrings = tokens.map((t) => t.token);
        if (!tokenStrings.length) {
            return { ok: false, error: 'No active tokens' };
        }
        await this.notifications.unsubscribeFromTopic(tokenStrings, body.topic);
        this.logger.log(`🔕 manually unsubscribed ${tokenStrings.length} token(s) from "${body.topic}"`);
        return { ok: true, unsubscribed: tokenStrings.length, topic: body.topic };
    }
};
exports.NotificationsController = NotificationsController;
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Post)('register-token'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [register_device_token_dto_1.RegisterDeviceTokenDto, Object]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "registerToken", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Post)('unregister-token'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [unregister_device_token_dto_1.UnregisterDeviceTokenDto]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "unregisterToken", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Post)('test'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "test", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    (0, common_1.Post)('send'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [send_notification_dto_1.SendNotificationDto]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "sendManual", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    (0, common_1.Post)('broadcast'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [send_notification_dto_1.BroadcastNotificationDto]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "broadcast", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    (0, common_1.Get)('admin/list'),
    __param(0, (0, common_1.Query)('accountType')),
    __param(1, (0, common_1.Query)('type')),
    __param(2, (0, common_1.Query)('unread')),
    __param(3, (0, common_1.Query)('search')),
    __param(4, (0, common_1.Query)('page')),
    __param(5, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, Object, Object]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "adminList", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    (0, common_1.Get)('admin/stats'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "adminStats", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)(),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Query)('unread')),
    __param(2, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "listMine", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('unread-count'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "unreadCount", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    (0, common_1.Get)('admin/search-accounts'),
    __param(0, (0, common_1.Query)('type')),
    __param(1, (0, common_1.Query)('q')),
    __param(2, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "searchAccounts", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Patch)(':id/read'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "markRead", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Patch)('read-all'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "markAllRead", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Post)('subscribe-topic'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "subscribeTopic", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Post)('unsubscribe-topic'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], NotificationsController.prototype, "unsubscribeTopic", null);
exports.NotificationsController = NotificationsController = NotificationsController_1 = __decorate([
    (0, common_1.Controller)('notifications'),
    __metadata("design:paramtypes", [notifications_service_1.NotificationsService,
        prisma_service_1.PrismaService])
], NotificationsController);
//# sourceMappingURL=notifications.controller.js.map