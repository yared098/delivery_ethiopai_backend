import { Messaging } from 'firebase-admin/messaging';
export declare const FIREBASE_MESSAGING = "FIREBASE_MESSAGING";
export declare const firebaseProvider: {
    provide: string;
    useFactory: () => Messaging;
};
