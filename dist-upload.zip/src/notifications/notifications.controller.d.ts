import { AccountType, NotificationType } from '@prisma/client';
import { NotificationsService } from './notifications.service';
import { PrismaService } from '../prisma/prisma.service';
import { RegisterDeviceTokenDto } from './dto/register-device-token.dto';
import { UnregisterDeviceTokenDto } from './dto/unregister-device-token.dto';
import { SendNotificationDto, BroadcastNotificationDto } from './dto/send-notification.dto';
export declare class NotificationsController {
    private readonly notifications;
    private readonly prisma;
    private readonly logger;
    constructor(notifications: NotificationsService, prisma: PrismaService);
    registerToken(dto: RegisterDeviceTokenDto, req: any): Promise<{
        ok: boolean;
        id: string;
        platform: string;
        topic: string;
    }>;
    unregisterToken(dto: UnregisterDeviceTokenDto): Promise<{
        ok: boolean;
    }>;
    test(req: any): Promise<{
        success: boolean;
        error: string;
        sent?: undefined;
        failed?: undefined;
    } | {
        success: boolean;
        sent: number;
        failed: number;
        error?: undefined;
    }>;
    sendManual(dto: SendNotificationDto): Promise<{
        success: boolean;
        error: string;
        sent?: undefined;
        failed?: undefined;
    } | {
        success: boolean;
        sent: number;
        failed: number;
        error?: undefined;
    }>;
    broadcast(dto: BroadcastNotificationDto): Promise<{
        success: boolean;
        messageId: string;
        error?: undefined;
    } | {
        success: boolean;
        error: any;
        messageId?: undefined;
    }>;
    adminList(accountType?: AccountType, type?: NotificationType, unread?: string, search?: string, page?: string, limit?: string): Promise<{
        data: ({
            order: {
                id: string;
                trackingNumber: string;
                status: import("@prisma/client").$Enums.OrderStatus;
            } | null;
            courier: {
                id: string;
                name: string;
                phone: string;
            } | null;
            staff: {
                id: string;
                name: string;
                phone: string;
            } | null;
            customer: {
                id: string;
                name: string | null;
                phone: string;
            } | null;
        } & {
            id: string;
            type: import("@prisma/client").$Enums.NotificationType;
            createdAt: Date;
            courierId: string | null;
            data: import("@prisma/client/runtime/library").JsonValue | null;
            accountType: import("@prisma/client").$Enums.AccountType;
            expiresAt: Date | null;
            staffId: string | null;
            customerId: string | null;
            title: string;
            body: string;
            imageUrl: string | null;
            isRead: boolean;
            readAt: Date | null;
            pushSent: boolean;
            pushSentAt: Date | null;
            pushError: string | null;
            orderId: string | null;
        })[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    adminStats(): Promise<{
        total: number;
        unread: number;
        pushed: number;
        failed: number;
        today: number;
    }>;
    listMine(req: any, unread?: string, limit?: string): Promise<{
        id: string;
        type: import("@prisma/client").$Enums.NotificationType;
        createdAt: Date;
        courierId: string | null;
        data: import("@prisma/client/runtime/library").JsonValue | null;
        accountType: import("@prisma/client").$Enums.AccountType;
        expiresAt: Date | null;
        staffId: string | null;
        customerId: string | null;
        title: string;
        body: string;
        imageUrl: string | null;
        isRead: boolean;
        readAt: Date | null;
        pushSent: boolean;
        pushSentAt: Date | null;
        pushError: string | null;
        orderId: string | null;
    }[]>;
    unreadCount(req: any): Promise<{
        count: number;
    }>;
    searchAccounts(type: AccountType, q?: string, limit?: string): Promise<{
        id: string;
        name: string | null;
        phone: string;
        email: string | null;
    }[]>;
    markRead(id: string, req: any): Promise<import("@prisma/client").Prisma.BatchPayload>;
    markAllRead(req: any): Promise<import("@prisma/client").Prisma.BatchPayload>;
    subscribeTopic(body: {
        topic: string;
    }, req: any): Promise<{
        ok: boolean;
        error: string;
        subscribed?: undefined;
        topic?: undefined;
    } | {
        ok: boolean;
        subscribed: number;
        topic: string;
        error?: undefined;
    }>;
    unsubscribeTopic(body: {
        topic: string;
    }, req: any): Promise<{
        ok: boolean;
        error: string;
        unsubscribed?: undefined;
        topic?: undefined;
    } | {
        ok: boolean;
        unsubscribed: number;
        topic: string;
        error?: undefined;
    }>;
}
