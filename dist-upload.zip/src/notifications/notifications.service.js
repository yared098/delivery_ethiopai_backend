"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var NotificationsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationsService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../prisma/prisma.service");
const telegram_notifier_service_1 = require("../telegram/telegram-notifier.service");
const firebase_provider_1 = require("./firebase.provider");
const notification_templates_1 = require("./constants/notification-templates");
let NotificationsService = NotificationsService_1 = class NotificationsService {
    constructor(messaging, prisma, telegram) {
        this.messaging = messaging;
        this.prisma = prisma;
        this.telegram = telegram;
        this.logger = new common_1.Logger(NotificationsService_1.name);
    }
    async sendToToken(token, opts) {
        try {
            const messageId = await this.messaging.send({
                token,
                notification: {
                    title: opts.title,
                    body: opts.body,
                    imageUrl: opts.imageUrl,
                },
                data: opts.data ?? {},
                android: {
                    priority: 'high',
                    notification: { channelId: 'default', sound: 'default' },
                },
                apns: { payload: { aps: { sound: 'default', badge: 1 } } },
            });
            return { success: true, messageId };
        }
        catch (err) {
            await this.handleDeadToken(err, token);
            if (err.code !== 'messaging/registration-token-not-registered') {
                this.logger.error(`FCM send error: ${err.message}`);
            }
            return { success: false, error: err.message };
        }
    }
    async sendToAccount(accountType, accountId, opts) {
        const where = { accountType, isActive: true };
        if (accountType === 'CUSTOMER')
            where.customerId = accountId;
        if (accountType === 'COURIER')
            where.courierId = accountId;
        if (accountType === 'STAFF')
            where.staffId = accountId;
        const tokens = await this.prisma.deviceToken.findMany({ where });
        if (!tokens.length) {
            this.logger.warn(`No active tokens for ${accountType} ${accountId}`);
            return { success: false, error: 'No tokens' };
        }
        const messages = tokens.map((t) => ({
            token: t.token,
            notification: {
                title: opts.title,
                body: opts.body,
                imageUrl: opts.imageUrl,
            },
            data: opts.data ?? {},
            android: {
                priority: 'high',
                notification: { channelId: 'default', sound: 'default' },
            },
            apns: { payload: { aps: { sound: 'default', badge: 1 } } },
        }));
        const res = await this.messaging.sendEach(messages);
        const dead = [];
        res.responses.forEach((r, i) => {
            if (!r.success &&
                (r.error?.code === 'messaging/registration-token-not-registered' ||
                    r.error?.code === 'messaging/invalid-registration-token')) {
                dead.push(tokens[i].token);
            }
        });
        if (dead.length) {
            await this.prisma.deviceToken.updateMany({
                where: { token: { in: dead } },
                data: { isActive: false },
            });
            this.logger.warn(`Deactivated ${dead.length} dead token(s)`);
        }
        return {
            success: true,
            sent: res.successCount,
            failed: res.failureCount,
        };
    }
    async sendToTopic(topic, opts) {
        try {
            const messageId = await this.messaging.send({
                topic,
                notification: { title: opts.title, body: opts.body },
                data: opts.data ?? {},
            });
            return { success: true, messageId };
        }
        catch (err) {
            this.logger.error(`FCM topic error: ${err.message}`);
            return { success: false, error: err.message };
        }
    }
    async subscribeToTopic(tokens, topic) {
        if (!tokens.length)
            return;
        try {
            await this.messaging.subscribeToTopic(tokens, topic);
        }
        catch (err) {
            this.logger.error(`subscribeToTopic error: ${err.message}`);
        }
    }
    async unsubscribeFromTopic(tokens, topic) {
        if (!tokens.length)
            return;
        try {
            await this.messaging.unsubscribeFromTopic(tokens, topic);
        }
        catch (err) {
            this.logger.error(`unsubscribeFromTopic error: ${err.message}`);
        }
    }
    async sendToCourier(courierId, payload) {
        const data = {};
        if (payload.data) {
            for (const [k, v] of Object.entries(payload.data)) {
                data[k] = typeof v === 'string' ? v : JSON.stringify(v);
            }
        }
        try {
            await this.prisma.notification.create({
                data: {
                    type: 'ORDER_OFFER',
                    accountType: 'COURIER',
                    courierId,
                    title: payload.title,
                    body: payload.body,
                    data: data,
                },
            });
        }
        catch (e) {
            this.logger.error(`Failed to save notification: ${e.message}`);
        }
        return this.sendToAccount('COURIER', courierId, {
            title: payload.title,
            body: payload.body,
            data,
        });
    }
    async broadcastToStaff(payload) {
        const staff = await this.prisma.staff.findMany({
            where: { isActive: true },
            select: { id: true },
        });
        if (staff.length === 0) {
            return { success: true, sent: 0, failed: 0 };
        }
        const data = {};
        if (payload.data) {
            for (const [k, v] of Object.entries(payload.data)) {
                data[k] = typeof v === 'string' ? v : JSON.stringify(v);
            }
        }
        try {
            await this.prisma.notification.createMany({
                data: staff.map((s) => ({
                    type: 'SYSTEM',
                    accountType: 'STAFF',
                    staffId: s.id,
                    title: payload.title,
                    body: payload.body,
                    data,
                })),
            });
        }
        catch (e) {
            this.logger.error(`Failed to save staff notifications: ${e.message}`);
        }
        const results = await Promise.allSettled(staff.map((s) => this.sendToAccount('STAFF', s.id, {
            title: payload.title,
            body: payload.body,
            data,
        })));
        const sent = results.filter((r) => r.status === 'fulfilled' && r.value.success).length;
        return {
            success: true,
            sent,
            failed: staff.length - sent,
        };
    }
    async notifyCustomerWelcome(customerId, name) {
        const t = notification_templates_1.TEMPLATES.WELCOME_CUSTOMER;
        return this.sendToAccount('CUSTOMER', customerId, {
            title: t.title,
            body: name ? `Hi ${name}, ${t.body}` : t.body,
            data: { type: 'WELCOME' },
        });
    }
    async notifyCustomToCustomer(customerId, opts) {
        if (!customerId)
            return { success: false, error: 'No customerId' };
        try {
            await this.sendToAccount('CUSTOMER', customerId, opts);
            void this.telegram
                .notifyCustomerId(customerId, `🔔 ${opts.title}\n${opts.body}`)
                .catch(() => { });
            return { success: true };
        }
        catch (err) {
            this.logger.error(`Failed to notify customer ${customerId}: ${err.message}`);
            return { success: false, error: err.message };
        }
    }
    async notifyOrderStatus(order) {
        const template = notification_templates_1.ORDER_STATUS_TEMPLATES[order.status];
        if (!template)
            return { success: false, error: 'No template' };
        void this.telegram
            .notifyOrderStatus({
            id: order.id,
            trackingNumber: order.trackingNumber,
            status: order.status,
            senderId: order.senderId,
            receiverId: order.receiverId,
        })
            .catch((err) => {
            this.logger.error(`Telegram order status push failed: ${err instanceof Error ? err.message : String(err)}`);
        });
        const data = {
            type: 'ORDER_STATUS',
            orderId: order.id,
            status: order.status,
            trackingNumber: order.trackingNumber,
        };
        const notificationType = order.status === client_1.OrderStatus.ASSIGNED
            ? client_1.NotificationType.ORDER_ASSIGNED
            : order.status === client_1.OrderStatus.PICKED_UP
                ? client_1.NotificationType.ORDER_PICKED_UP
                : order.status === client_1.OrderStatus.DELIVERED
                    ? client_1.NotificationType.ORDER_DELIVERED
                    : order.status === client_1.OrderStatus.FAILED
                        ? client_1.NotificationType.ORDER_FAILED
                        : order.status === client_1.OrderStatus.CANCELLED
                            ? client_1.NotificationType.ORDER_CANCELLED
                            : client_1.NotificationType.ORDER_STATUS_CHANGED;
        const recipients = new Map();
        const addCustomer = (customerId) => {
            if (!customerId)
                return;
            recipients.set(`CUSTOMER:${customerId}`, {
                accountType: client_1.AccountType.CUSTOMER,
                accountId: customerId,
                title: template.title,
                body: `${template.body} (#${order.trackingNumber})`,
                data,
            });
        };
        addCustomer(order.senderId);
        addCustomer(order.receiverId);
        if (order.courierId) {
            const isAssignment = order.status === client_1.OrderStatus.ASSIGNED;
            recipients.set(`COURIER:${order.courierId}`, {
                accountType: client_1.AccountType.COURIER,
                accountId: order.courierId,
                title: isAssignment ? notification_templates_1.TEMPLATES.NEW_ASSIGNMENT.title : template.title,
                body: isAssignment
                    ? `Pickup from ${order.senderAddress ?? 'sender'} (#${order.trackingNumber})`
                    : `${template.body} (#${order.trackingNumber})`,
                data: isAssignment
                    ? {
                        type: 'NEW_ASSIGNMENT',
                        orderId: order.id,
                        trackingNumber: order.trackingNumber,
                    }
                    : data,
            });
        }
        const results = await Promise.allSettled(Array.from(recipients.values()).map(async (recipient) => {
            let notificationId;
            try {
                const saved = await this.prisma.notification.create({
                    data: {
                        type: notificationType,
                        accountType: recipient.accountType,
                        ...(recipient.accountType === client_1.AccountType.CUSTOMER
                            ? { customerId: recipient.accountId }
                            : { courierId: recipient.accountId }),
                        title: recipient.title,
                        body: recipient.body,
                        data: recipient.data,
                        orderId: order.id,
                    },
                    select: { id: true },
                });
                notificationId = saved.id;
            }
            catch (error) {
                this.logger.error(`Failed to save order notification for ${recipient.accountType} ${recipient.accountId}: ${error instanceof Error ? error.message : String(error)}`);
            }
            let pushResult;
            try {
                pushResult = await this.sendToAccount(recipient.accountType, recipient.accountId, {
                    title: recipient.title,
                    body: recipient.body,
                    data: recipient.data,
                });
            }
            catch (error) {
                this.logger.error(`Failed to send order push to ${recipient.accountType} ${recipient.accountId}: ${error instanceof Error ? error.message : String(error)}`);
            }
            const pushSent = pushResult?.success === true && (pushResult.sent ?? 0) > 0;
            if (notificationId) {
                const pushError = pushSent
                    ? (pushResult?.failed ?? 0) > 0
                        ? `${pushResult?.failed} device push(es) failed`
                        : null
                    : pushResult?.error ?? 'No push notifications delivered';
                try {
                    await this.prisma.notification.update({
                        where: { id: notificationId },
                        data: {
                            pushSent,
                            pushSentAt: pushSent ? new Date() : null,
                            pushError,
                        },
                    });
                }
                catch (error) {
                    this.logger.error(`Failed to update order notification delivery status ${notificationId}: ${error instanceof Error ? error.message : String(error)}`);
                }
            }
            return { pushSent };
        }));
        return {
            success: true,
            recipients: recipients.size,
            processed: results.filter((result) => result.status === 'fulfilled').length,
            pushSent: results.filter((result) => result.status === 'fulfilled' && result.value.pushSent).length,
        };
    }
    async notifyCourierApproved(courierId) {
        const t = notification_templates_1.TEMPLATES.COURIER_APPROVED;
        return this.sendToAccount('COURIER', courierId, {
            title: t.title,
            body: t.body,
            data: { type: 'ACCOUNT_APPROVED' },
        });
    }
    async notifyCourierRejected(courierId, reason) {
        const t = notification_templates_1.TEMPLATES.COURIER_REJECTED;
        return this.sendToAccount('COURIER', courierId, {
            title: t.title,
            body: reason ?? t.body,
            data: { type: 'ACCOUNT_REJECTED' },
        });
    }
    async notifyPayoutPaid(courierId, amount, currency = 'ETB') {
        const t = notification_templates_1.TEMPLATES.PAYOUT_PAID;
        return this.sendToAccount('COURIER', courierId, {
            title: t.title,
            body: `${amount} ${currency} has been sent to your account.`,
            data: { type: 'PAYOUT_PAID', amount: String(amount) },
        });
    }
    async notifyReceiverLink(receiverPhone, shortCode) {
        const customer = await this.prisma.customer.findUnique({
            where: { phone: receiverPhone },
        });
        if (!customer)
            return { success: false, error: 'No customer with phone' };
        const t = notification_templates_1.TEMPLATES.RECEIVER_LINK;
        return this.sendToAccount('CUSTOMER', customer.id, {
            title: t.title,
            body: t.body,
            data: { type: 'RECEIVER_LINK', shortCode },
        });
    }
    async handleDeadToken(err, token) {
        if (err.code === 'messaging/registration-token-not-registered' ||
            err.code === 'messaging/invalid-registration-token') {
            await this.prisma.deviceToken.updateMany({
                where: { token },
                data: { isActive: false },
            });
            this.logger.warn(`Deactivated dead token: ${token.slice(0, 20)}...`);
        }
    }
};
exports.NotificationsService = NotificationsService;
exports.NotificationsService = NotificationsService = NotificationsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(firebase_provider_1.FIREBASE_MESSAGING)),
    __metadata("design:paramtypes", [Function, prisma_service_1.PrismaService,
        telegram_notifier_service_1.TelegramNotifierService])
], NotificationsService);
//# sourceMappingURL=notifications.service.js.map