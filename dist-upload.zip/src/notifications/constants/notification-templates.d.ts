import { OrderStatus } from '@prisma/client';
export type Template = {
    title: string;
    body: string;
};
export declare const ORDER_STATUS_TEMPLATES: Partial<Record<OrderStatus, Template>>;
export declare const TEMPLATES: {
    readonly WELCOME_CUSTOMER: {
        readonly title: "Welcome to Truest Express 🎉";
        readonly body: "Your account is ready. Start sending parcels today!";
    };
    readonly COURIER_APPROVED: {
        readonly title: "Account Approved 🎉";
        readonly body: "You can now start accepting deliveries.";
    };
    readonly COURIER_REJECTED: {
        readonly title: "Application Rejected";
        readonly body: "Your courier application was not approved.";
    };
    readonly NEW_ASSIGNMENT: {
        readonly title: "New Delivery Assigned 📦";
        readonly body: "You have a new pickup waiting.";
    };
    readonly PAYOUT_PAID: {
        readonly title: "Payout Sent 💰";
        readonly body: "Your payout has been processed.";
    };
    readonly RECEIVER_LINK: {
        readonly title: "Share Your Location 📍";
        readonly body: "Tap to share your delivery location.";
    };
    readonly TEST: {
        readonly title: "Test Notification 🔔";
        readonly body: "If you see this, FCM is working perfectly.";
    };
};
