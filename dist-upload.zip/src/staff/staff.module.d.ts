export declare class StaffModule {
}
