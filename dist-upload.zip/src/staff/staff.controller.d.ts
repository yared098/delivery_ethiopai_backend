import { StaffService } from './staff.service';
export declare class StaffController {
    private staff;
    constructor(staff: StaffService);
    me(id: string): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        phone: string;
        email: string | null;
        mustChangePassword: boolean;
        role: import("@prisma/client").$Enums.StaffRole;
        regionId: string | null;
        branchId: string | null;
        isActive: boolean;
        phoneVerified: boolean;
        region: {
            id: string;
            code: string;
            name: string;
        } | null;
        branch: {
            id: string;
            code: string;
            name: string;
        } | null;
    }>;
}
