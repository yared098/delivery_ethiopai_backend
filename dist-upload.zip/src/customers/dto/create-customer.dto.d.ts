export declare class CreateCustomerDto {
    phone: string;
    name: string;
    email?: string;
    defaultAddress?: string;
    defaultLat?: number;
    defaultLng?: number;
}
