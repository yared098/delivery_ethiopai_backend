export declare class ListCustomersQueryDto {
    search?: string;
    isActive?: boolean;
    page?: number;
    limit?: number;
}
