import { PrismaService } from '../prisma/prisma.service';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { ListCustomersQueryDto } from './dto/list-customers-query.dto';
export declare class CustomersService {
    private prisma;
    constructor(prisma: PrismaService);
    private normalizePhone;
    create(dto: CreateCustomerDto, currentUser: any): Promise<{
        id: string;
        name: string | null;
        createdAt: Date;
        updatedAt: Date;
        phone: string;
        email: string | null;
        isActive: boolean;
        phoneVerified: boolean;
        emailVerified: boolean;
        defaultAddress: string | null;
        defaultLat: number | null;
        defaultLng: number | null;
        registeredById: string | null;
        registeredByType: import("@prisma/client").$Enums.AccountType | null;
        registeredBy: {
            id: string;
            name: string;
        } | null;
    }>;
    private regionScope;
    findAll(query: ListCustomersQueryDto, currentUser: any): Promise<{
        data: {
            id: string;
            name: string | null;
            createdAt: Date;
            updatedAt: Date;
            phone: string;
            email: string | null;
            isActive: boolean;
            phoneVerified: boolean;
            emailVerified: boolean;
            defaultAddress: string | null;
            defaultLat: number | null;
            defaultLng: number | null;
            registeredById: string | null;
            registeredByType: import("@prisma/client").$Enums.AccountType | null;
            registeredBy: {
                id: string;
                name: string;
            } | null;
        }[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    findOne(id: string, currentUser: any): Promise<{
        id: string;
        name: string | null;
        createdAt: Date;
        updatedAt: Date;
        _count: {
            ordersSent: number;
            ordersReceived: number;
        };
        phone: string;
        email: string | null;
        isActive: boolean;
        phoneVerified: boolean;
        emailVerified: boolean;
        defaultAddress: string | null;
        defaultLat: number | null;
        defaultLng: number | null;
        registeredById: string | null;
        registeredByType: import("@prisma/client").$Enums.AccountType | null;
        registeredBy: {
            id: string;
            name: string;
        } | null;
    }>;
    findByPhone(phone: string, currentUser: any): Promise<{
        id: string;
        name: string | null;
        createdAt: Date;
        updatedAt: Date;
        phone: string;
        email: string | null;
        isActive: boolean;
        phoneVerified: boolean;
        emailVerified: boolean;
        defaultAddress: string | null;
        defaultLat: number | null;
        defaultLng: number | null;
        registeredById: string | null;
        registeredByType: import("@prisma/client").$Enums.AccountType | null;
        registeredBy: {
            id: string;
            name: string;
        } | null;
    } | null>;
    update(id: string, dto: UpdateCustomerDto, currentUser: any): Promise<{
        id: string;
        name: string | null;
        createdAt: Date;
        updatedAt: Date;
        phone: string;
        email: string | null;
        isActive: boolean;
        phoneVerified: boolean;
        emailVerified: boolean;
        defaultAddress: string | null;
        defaultLat: number | null;
        defaultLng: number | null;
        registeredById: string | null;
        registeredByType: import("@prisma/client").$Enums.AccountType | null;
        registeredBy: {
            id: string;
            name: string;
        } | null;
    }>;
    suspend(id: string, currentUser: any): Promise<{
        message: string;
    }>;
    reactivate(id: string, currentUser: any): Promise<{
        message: string;
    }>;
    remove(id: string, currentUser: any): Promise<{
        message: string;
    }>;
    private publicSelect;
}
