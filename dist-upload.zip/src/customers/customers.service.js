"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomersService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const client_1 = require("@prisma/client");
let CustomersService = class CustomersService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    normalizePhone(phone) {
        const digits = phone.replace(/\D/g, '');
        if (digits.startsWith('251') && digits.length === 12)
            return digits;
        if (digits.startsWith('0') && digits.length === 10)
            return '251' + digits.slice(1);
        if (digits.length === 9)
            return '251' + digits;
        throw new common_1.BadRequestException('Invalid phone');
    }
    async create(dto, currentUser) {
        const phone = this.normalizePhone(dto.phone);
        const existing = await this.prisma.customer.findUnique({ where: { phone } });
        if (existing) {
            throw new common_1.ConflictException('A customer with this phone already exists');
        }
        if (dto.email) {
            const emailExists = await this.prisma.customer.findUnique({
                where: { email: dto.email },
            });
            if (emailExists)
                throw new common_1.ConflictException('Email already in use');
        }
        return this.prisma.customer.create({
            data: {
                phone,
                name: dto.name,
                email: dto.email,
                defaultAddress: dto.defaultAddress,
                defaultLat: dto.defaultLat,
                defaultLng: dto.defaultLng,
                registeredById: currentUser.id,
                registeredByType: client_1.AccountType.STAFF,
                isActive: true,
            },
            select: this.publicSelect(),
        });
    }
    regionScope(currentUser) {
        if (currentUser.role === client_1.StaffRole.SUPER_ADMIN)
            return {};
        if (!currentUser.regionId) {
            throw new common_1.ForbiddenException('Your staff account is not assigned to a region');
        }
        return {
            registeredBy: {
                is: { regionId: currentUser.regionId },
            },
        };
    }
    async findAll(query, currentUser) {
        const where = this.regionScope(currentUser);
        if (query.isActive !== undefined)
            where.isActive = query.isActive;
        if (query.search) {
            where.OR = [
                { phone: { contains: query.search } },
                { name: { contains: query.search, mode: 'insensitive' } },
                { email: { contains: query.search, mode: 'insensitive' } },
            ];
        }
        const page = query.page || 1;
        const limit = query.limit || 20;
        const skip = (page - 1) * limit;
        const [data, total] = await Promise.all([
            this.prisma.customer.findMany({
                where,
                select: this.publicSelect(),
                orderBy: { createdAt: 'desc' },
                skip,
                take: limit,
            }),
            this.prisma.customer.count({ where }),
        ]);
        return {
            data,
            total,
            page,
            limit,
            pages: Math.ceil(total / limit),
        };
    }
    async findOne(id, currentUser) {
        const customer = await this.prisma.customer.findFirst({
            where: { id, ...this.regionScope(currentUser) },
            select: {
                ...this.publicSelect(),
                _count: {
                    select: {
                        ordersSent: true,
                        ordersReceived: true,
                    },
                },
            },
        });
        if (!customer)
            throw new common_1.NotFoundException('Customer not found');
        return customer;
    }
    async findByPhone(phone, currentUser) {
        const normalized = this.normalizePhone(phone);
        const customer = await this.prisma.customer.findFirst({
            where: { phone: normalized, ...this.regionScope(currentUser) },
            select: this.publicSelect(),
        });
        return customer;
    }
    async update(id, dto, currentUser) {
        const existing = await this.prisma.customer.findFirst({
            where: { id, ...this.regionScope(currentUser) },
        });
        if (!existing)
            throw new common_1.NotFoundException('Customer not found');
        const data = {};
        if (dto.name !== undefined)
            data.name = dto.name;
        if (dto.email !== undefined)
            data.email = dto.email;
        if (dto.defaultAddress !== undefined)
            data.defaultAddress = dto.defaultAddress;
        if (dto.defaultLat !== undefined)
            data.defaultLat = dto.defaultLat;
        if (dto.defaultLng !== undefined)
            data.defaultLng = dto.defaultLng;
        if (dto.phone) {
            const phone = this.normalizePhone(dto.phone);
            if (phone !== existing.phone) {
                const dup = await this.prisma.customer.findUnique({ where: { phone } });
                if (dup)
                    throw new common_1.ConflictException('Phone already in use');
            }
            data.phone = phone;
        }
        if (dto.email && dto.email !== existing.email) {
            const dup = await this.prisma.customer.findUnique({
                where: { email: dto.email },
            });
            if (dup)
                throw new common_1.ConflictException('Email already in use');
        }
        return this.prisma.customer.update({
            where: { id },
            data,
            select: this.publicSelect(),
        });
    }
    async suspend(id, currentUser) {
        const existing = await this.prisma.customer.findFirst({
            where: { id, ...this.regionScope(currentUser) },
        });
        if (!existing)
            throw new common_1.NotFoundException('Customer not found');
        await this.prisma.customer.update({
            where: { id },
            data: { isActive: false },
        });
        await this.prisma.refreshToken.updateMany({
            where: { accountId: id, accountType: client_1.AccountType.CUSTOMER, revokedAt: null },
            data: { revokedAt: new Date() },
        });
        return { message: 'Customer suspended' };
    }
    async reactivate(id, currentUser) {
        const existing = await this.prisma.customer.findFirst({
            where: { id, ...this.regionScope(currentUser) },
        });
        if (!existing)
            throw new common_1.NotFoundException('Customer not found');
        await this.prisma.customer.update({
            where: { id },
            data: { isActive: true },
        });
        return { message: 'Customer reactivated' };
    }
    async remove(id, currentUser) {
        const customer = await this.prisma.customer.findFirst({
            where: { id, ...this.regionScope(currentUser) },
            include: {
                _count: { select: { ordersSent: true, ordersReceived: true } },
            },
        });
        if (!customer)
            throw new common_1.NotFoundException('Customer not found');
        const totalOrders = customer._count.ordersSent + customer._count.ordersReceived;
        if (totalOrders > 0) {
            throw new common_1.BadRequestException(`Cannot delete customer with ${totalOrders} orders. Suspend instead.`);
        }
        await this.prisma.refreshToken.deleteMany({
            where: { accountId: id, accountType: client_1.AccountType.CUSTOMER },
        });
        await this.prisma.otpCode.deleteMany({ where: { customerId: id } });
        await this.prisma.customer.delete({ where: { id } });
        return { message: 'Customer deleted' };
    }
    publicSelect() {
        return {
            id: true,
            phone: true,
            name: true,
            email: true,
            phoneVerified: true,
            emailVerified: true,
            isActive: true,
            defaultAddress: true,
            defaultLat: true,
            defaultLng: true,
            registeredById: true,
            registeredByType: true,
            registeredBy: { select: { id: true, name: true } },
            createdAt: true,
            updatedAt: true,
        };
    }
};
exports.CustomersService = CustomersService;
exports.CustomersService = CustomersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], CustomersService);
//# sourceMappingURL=customers.service.js.map