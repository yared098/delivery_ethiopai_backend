"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CustomersController = void 0;
const common_1 = require("@nestjs/common");
const customers_service_1 = require("./customers.service");
const create_customer_dto_1 = require("./dto/create-customer.dto");
const update_customer_dto_1 = require("./dto/update-customer.dto");
const list_customers_query_dto_1 = require("./dto/list-customers-query.dto");
const jwt_auth_guard_1 = require("../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../common/guards/roles.guard");
const staff_roles_decorator_1 = require("../common/decorators/staff-roles.decorator");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const client_1 = require("@prisma/client");
let CustomersController = class CustomersController {
    constructor(customers) {
        this.customers = customers;
    }
    create(dto, user) {
        return this.customers.create(dto, user);
    }
    findAll(query, user) {
        return this.customers.findAll(query, user);
    }
    lookup(phone, user) {
        return this.customers.findByPhone(phone, user);
    }
    findOne(id, user) {
        return this.customers.findOne(id, user);
    }
    update(id, dto, user) {
        return this.customers.update(id, dto, user);
    }
    suspend(id, user) {
        return this.customers.suspend(id, user);
    }
    reactivate(id, user) {
        return this.customers.reactivate(id, user);
    }
    remove(id, user) {
        return this.customers.remove(id, user);
    }
};
exports.CustomersController = CustomersController;
__decorate([
    (0, common_1.Post)(),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_customer_dto_1.CreateCustomerDto, Object]),
    __metadata("design:returntype", void 0)
], CustomersController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_customers_query_dto_1.ListCustomersQueryDto, Object]),
    __metadata("design:returntype", void 0)
], CustomersController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('lookup'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Query)('phone')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], CustomersController.prototype, "lookup", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], CustomersController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_customer_dto_1.UpdateCustomerDto, Object]),
    __metadata("design:returntype", void 0)
], CustomersController.prototype, "update", null);
__decorate([
    (0, common_1.Post)(':id/suspend'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], CustomersController.prototype, "suspend", null);
__decorate([
    (0, common_1.Post)(':id/reactivate'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], CustomersController.prototype, "reactivate", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], CustomersController.prototype, "remove", null);
exports.CustomersController = CustomersController = __decorate([
    (0, common_1.Controller)('admin/customers'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    __metadata("design:paramtypes", [customers_service_1.CustomersService])
], CustomersController);
//# sourceMappingURL=customers.controller.js.map