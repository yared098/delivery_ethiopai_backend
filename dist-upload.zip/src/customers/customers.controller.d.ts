import { CustomersService } from './customers.service';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { ListCustomersQueryDto } from './dto/list-customers-query.dto';
export declare class CustomersController {
    private customers;
    constructor(customers: CustomersService);
    create(dto: CreateCustomerDto, user: any): Promise<{
        id: string;
        name: string | null;
        createdAt: Date;
        updatedAt: Date;
        phone: string;
        email: string | null;
        isActive: boolean;
        phoneVerified: boolean;
        emailVerified: boolean;
        defaultAddress: string | null;
        defaultLat: number | null;
        defaultLng: number | null;
        registeredById: string | null;
        registeredByType: import("@prisma/client").$Enums.AccountType | null;
        registeredBy: {
            id: string;
            name: string;
        } | null;
    }>;
    findAll(query: ListCustomersQueryDto, user: any): Promise<{
        data: {
            id: string;
            name: string | null;
            createdAt: Date;
            updatedAt: Date;
            phone: string;
            email: string | null;
            isActive: boolean;
            phoneVerified: boolean;
            emailVerified: boolean;
            defaultAddress: string | null;
            defaultLat: number | null;
            defaultLng: number | null;
            registeredById: string | null;
            registeredByType: import("@prisma/client").$Enums.AccountType | null;
            registeredBy: {
                id: string;
                name: string;
            } | null;
        }[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    lookup(phone: string, user: any): Promise<{
        id: string;
        name: string | null;
        createdAt: Date;
        updatedAt: Date;
        phone: string;
        email: string | null;
        isActive: boolean;
        phoneVerified: boolean;
        emailVerified: boolean;
        defaultAddress: string | null;
        defaultLat: number | null;
        defaultLng: number | null;
        registeredById: string | null;
        registeredByType: import("@prisma/client").$Enums.AccountType | null;
        registeredBy: {
            id: string;
            name: string;
        } | null;
    } | null>;
    findOne(id: string, user: any): Promise<{
        id: string;
        name: string | null;
        createdAt: Date;
        updatedAt: Date;
        _count: {
            ordersSent: number;
            ordersReceived: number;
        };
        phone: string;
        email: string | null;
        isActive: boolean;
        phoneVerified: boolean;
        emailVerified: boolean;
        defaultAddress: string | null;
        defaultLat: number | null;
        defaultLng: number | null;
        registeredById: string | null;
        registeredByType: import("@prisma/client").$Enums.AccountType | null;
        registeredBy: {
            id: string;
            name: string;
        } | null;
    }>;
    update(id: string, dto: UpdateCustomerDto, user: any): Promise<{
        id: string;
        name: string | null;
        createdAt: Date;
        updatedAt: Date;
        phone: string;
        email: string | null;
        isActive: boolean;
        phoneVerified: boolean;
        emailVerified: boolean;
        defaultAddress: string | null;
        defaultLat: number | null;
        defaultLng: number | null;
        registeredById: string | null;
        registeredByType: import("@prisma/client").$Enums.AccountType | null;
        registeredBy: {
            id: string;
            name: string;
        } | null;
    }>;
    suspend(id: string, user: any): Promise<{
        message: string;
    }>;
    reactivate(id: string, user: any): Promise<{
        message: string;
    }>;
    remove(id: string, user: any): Promise<{
        message: string;
    }>;
}
