"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const common_1 = require("@nestjs/common");
const helmet_1 = __importDefault(require("helmet"));
const cookie_parser_1 = __importDefault(require("cookie-parser"));
const app_module_1 = require("./app.module");
const os = __importStar(require("os"));
const path_1 = require("path");
async function bootstrap() {
    const app = await core_1.NestFactory.create(app_module_1.AppModule);
    app.use((0, helmet_1.default)({
        contentSecurityPolicy: false,
        crossOriginResourcePolicy: { policy: 'cross-origin' },
    }));
    app.use((0, cookie_parser_1.default)());
    app.enableCors({
        origin: true,
        credentials: true,
        methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization'],
    });
    const startedAt = Date.now();
    app.use('/health', (req, res) => {
        const uptimeMs = Date.now() - startedAt;
        const uptimeSec = Math.floor(uptimeMs / 1000);
        const uptimeMin = Math.floor(uptimeSec / 60);
        const uptimeHr = Math.floor(uptimeMin / 60);
        const uptimeDay = Math.floor(uptimeHr / 24);
        const mem = process.memoryUsage();
        res.status(200).json({
            status: 'ok',
            service: 'delivery-ethiopia-api',
            version: process.env.npm_package_version || '0.1.0',
            environment: process.env.NODE_ENV || 'production',
            timestamp: new Date().toISOString(),
            uptime: {
                seconds: uptimeSec,
                human: `${uptimeDay}d ${uptimeHr % 24}h ${uptimeMin % 60}m ${uptimeSec % 60}s`,
            },
            memory: {
                rss_mb: Math.round(mem.rss / 1024 / 1024),
                heap_used_mb: Math.round(mem.heapUsed / 1024 / 1024),
                heap_total_mb: Math.round(mem.heapTotal / 1024 / 1024),
            },
            node: process.version,
            pid: process.pid,
        });
    });
    app.use('/healthz', (req, res) => res.redirect(307, '/health'));
    app.useStaticAssets((0, path_1.join)(process.cwd(), 'uploads'), {
        prefix: '/uploads/',
    });
    app.setGlobalPrefix('api/v1', {
        exclude: [
            'health',
            'healthz',
            'uploads/(.*)',
        ],
    });
    app.useGlobalPipes(new common_1.ValidationPipe({
        whitelist: true,
        forbidNonWhitelisted: true,
        transform: true,
    }));
    const port = Number(process.env.PORT) || 3000;
    await app.listen(port, '0.0.0.0');
    const logger = new common_1.Logger('Bootstrap');
    if (process.env.RENDER || process.env.NODE_ENV === 'production') {
        logger.log(`🚀 API running on port ${port}`);
        logger.log(`🩺 Health:  http://localhost:${port}/health`);
        return;
    }
    const nets = os.networkInterfaces();
    const lanIps = [];
    for (const name of Object.keys(nets)) {
        for (const net of nets[name] ?? []) {
            if (net.family === 'IPv4' && !net.internal) {
                lanIps.push(net.address);
            }
        }
    }
    logger.log(`🚀 Local:   http://localhost:${port}/api/v1`);
    for (const ip of lanIps) {
        logger.log(`📱 LAN:     http://${ip}:${port}/api/v1`);
    }
    logger.log(`🤖 Emu:     http://10.0.2.2:${port}/api/v1  (Android emulator)`);
    logger.log(`🖼️  Files:   http://localhost:${port}/uploads/...`);
    logger.log(`🩺 Health:  http://localhost:${port}/health`);
}
bootstrap();
//# sourceMappingURL=main.js.map