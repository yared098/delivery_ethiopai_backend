export declare class UploadsController {
    uploadCourierFile(file: Express.Multer.File): {
        url: string;
        filename: string;
        size: number;
        mimetype: string;
    };
    uploadProviderLogo(file: Express.Multer.File): {
        url: string;
        filename: string;
        size: number;
        mimetype: string;
    };
}
