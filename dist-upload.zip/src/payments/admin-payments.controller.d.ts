import { PaymentsService } from './payments.service';
export declare class AdminPaymentsController {
    private payments;
    constructor(payments: PaymentsService);
    listForOrder(orderId: string): Promise<{
        id: string;
        createdById: string | null;
        createdAt: Date;
        updatedAt: Date;
        method: import("@prisma/client").$Enums.PaymentMethod;
        status: import("@prisma/client").$Enums.PaymentStatus;
        paidAt: Date | null;
        orderId: string;
        amount: number;
        currency: string;
        notes: string | null;
        party: import("@prisma/client").$Enums.PaymentParty;
        gatewayRef: string | null;
        gatewayPayload: import("@prisma/client/runtime/library").JsonValue | null;
        refundedAt: Date | null;
        refundAmount: number | null;
        refundReason: string | null;
    }[]>;
    refund(id: string, body: {
        reason: string;
        amount?: number;
    }, req: any): Promise<{
        message: string;
    }>;
    listAll(page?: string, limit?: string, status?: string, method?: string, search?: string, from?: string, to?: string): Promise<{
        data: ({
            createdBy: {
                id: string;
                name: string;
            } | null;
            order: {
                id: string;
                trackingNumber: string;
                senderName: string;
                senderPhone: string;
                receiverName: string | null;
                receiverPhone: string;
                deliveryFee: number;
                courierEarning: number;
                status: import("@prisma/client").$Enums.OrderStatus;
            };
        } & {
            id: string;
            createdById: string | null;
            createdAt: Date;
            updatedAt: Date;
            method: import("@prisma/client").$Enums.PaymentMethod;
            status: import("@prisma/client").$Enums.PaymentStatus;
            paidAt: Date | null;
            orderId: string;
            amount: number;
            currency: string;
            notes: string | null;
            party: import("@prisma/client").$Enums.PaymentParty;
            gatewayRef: string | null;
            gatewayPayload: import("@prisma/client/runtime/library").JsonValue | null;
            refundedAt: Date | null;
            refundAmount: number | null;
            refundReason: string | null;
        })[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    stats(): Promise<{
        totalCount: number;
        totalPaidAmount: number;
        totalPaidCount: number;
        pendingCount: number;
        failedCount: number;
        refundedAmount: number;
        refundedCount: number;
    }>;
}
