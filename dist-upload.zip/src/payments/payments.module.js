"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentsModule = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const config_1 = require("@nestjs/config");
const payments_service_1 = require("./payments.service");
const chapa_service_1 = require("./chapa.service");
const payments_controller_1 = require("./payments.controller");
const chapa_webhook_controller_1 = require("./chapa-webhook.controller");
const admin_payments_controller_1 = require("./admin-payments.controller");
const prisma_module_1 = require("../prisma/prisma.module");
const payment_providers_module_1 = require("../payment-providers/payment-providers.module");
const any_auth_guard_1 = require("../common/guards/any-auth.guard");
const auto_assign_module_1 = require("../auto-assign/auto-assign.module");
let PaymentsModule = class PaymentsModule {
};
exports.PaymentsModule = PaymentsModule;
exports.PaymentsModule = PaymentsModule = __decorate([
    (0, common_1.Module)({
        imports: [
            prisma_module_1.PrismaModule,
            payment_providers_module_1.PaymentProvidersModule,
            config_1.ConfigModule,
            auto_assign_module_1.AutoAssignModule,
            jwt_1.JwtModule.registerAsync({
                useFactory: () => ({
                    secret: process.env.JWT_ACCESS_SECRET,
                    signOptions: { expiresIn: '15m' },
                }),
            }),
        ],
        controllers: [
            payments_controller_1.PaymentsController,
            chapa_webhook_controller_1.ChapaWebhookController,
            admin_payments_controller_1.AdminPaymentsController,
        ],
        providers: [payments_service_1.PaymentsService, chapa_service_1.ChapaService, any_auth_guard_1.AnyAuthGuard],
        exports: [payments_service_1.PaymentsService, chapa_service_1.ChapaService],
    })
], PaymentsModule);
//# sourceMappingURL=payments.module.js.map