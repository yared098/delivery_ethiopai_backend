"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var PaymentsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentsService = void 0;
const common_1 = require("@nestjs/common");
const crypto_1 = require("crypto");
const prisma_service_1 = require("../prisma/prisma.service");
const chapa_service_1 = require("./chapa.service");
const auto_assign_service_1 = require("../auto-assign/auto-assign.service");
const notifications_service_1 = require("../notifications/notifications.service");
const client_1 = require("@prisma/client");
let PaymentsService = PaymentsService_1 = class PaymentsService {
    constructor(prisma, chapa, autoAssign, notifications) {
        this.prisma = prisma;
        this.chapa = chapa;
        this.autoAssign = autoAssign;
        this.notifications = notifications;
        this.logger = new common_1.Logger(PaymentsService_1.name);
    }
    async initChapaPayment(dto, customerId) {
        const order = await this.prisma.order.findUnique({
            where: { id: dto.orderId },
            include: { sender: true, receiver: true },
        });
        if (!order)
            throw new common_1.NotFoundException('Order not found');
        if (order.paymentStatus === client_1.PaymentStatus.PAID)
            throw new common_1.BadRequestException('Order already paid');
        const provider = await this.chapa.getChapaProvider();
        const amount = dto.amount ??
            order.codAmount ??
            order.deliveryFee ??
            0;
        if (!amount || amount <= 0)
            throw new common_1.BadRequestException('Invalid payment amount');
        if (provider.minAmount && amount < provider.minAmount)
            throw new common_1.BadRequestException(`Minimum amount is ${provider.minAmount} ETB`);
        if (provider.maxAmount && amount > provider.maxAmount)
            throw new common_1.BadRequestException(`Maximum amount is ${provider.maxAmount} ETB`);
        const txRef = `DEL-${order.trackingNumber}-${(0, crypto_1.randomUUID)().slice(0, 8)}`;
        const party = order.paymentParty || client_1.PaymentParty.SENDER;
        const payment = await this.prisma.payment.create({
            data: {
                orderId: order.id,
                amount,
                currency: 'ETB',
                method: client_1.PaymentMethod.CHAPA,
                party,
                status: client_1.PaymentStatus.PENDING,
                gatewayRef: txRef,
                notes: 'Chapa checkout initialized',
            },
        });
        const payer = party === client_1.PaymentParty.RECEIVER ? order.receiver : order.sender;
        const email = dto.email ||
            payer?.email ||
            'yades.dev@gmail.com';
        const firstName = dto.firstName || payer?.name?.split(' ')[0] || 'Customer';
        const lastName = dto.lastName || payer?.name?.split(' ').slice(1).join(' ') || 'User';
        const phone = dto.phone || payer?.phone || order.senderPhone;
        const BACKEND_URL = process.env.BACKEND_URL ||
            process.env.APP_URL ||
            'http://localhost:3000';
        const FRONTEND_URL = process.env.FRONTEND_URL ||
            process.env.APP_URL ||
            'http://localhost:5174';
        const webhookUrl = provider.webhookUrl ||
            `${BACKEND_URL}/api/v1/payments/chapa/webhook`;
        const returnUrl = dto.returnUrl ||
            `${FRONTEND_URL}/payment/success?tx_ref=${txRef}`;
        const { checkoutUrl } = await this.chapa.initialize({
            amount,
            email,
            firstName,
            lastName,
            phone,
            txRef,
            callbackUrl: webhookUrl,
            returnUrl,
            title: 'Truest Express',
            description: `Order ${order.trackingNumber}`,
            provider,
        });
        return {
            paymentId: payment.id,
            txRef,
            checkoutUrl,
            amount,
            currency: 'ETB',
        };
    }
    async verifyChapaPayment(txRef) {
        const payment = await this.prisma.payment.findFirst({
            where: { gatewayRef: txRef },
        });
        if (!payment)
            throw new common_1.NotFoundException('Payment not found');
        if (payment.status === client_1.PaymentStatus.PAID) {
            return { status: payment.status, verified: true, alreadyPaid: true };
        }
        const result = await this.chapa.verify(txRef);
        const newStatus = result.verified
            ? client_1.PaymentStatus.PAID
            : client_1.PaymentStatus.FAILED;
        const updatedOrder = await this.prisma.$transaction(async (tx) => {
            await tx.payment.update({
                where: { id: payment.id },
                data: {
                    status: newStatus,
                    paidAt: result.verified ? new Date() : null,
                    gatewayPayload: result.raw,
                },
            });
            if (!result.verified)
                return null;
            const updated = await tx.order.update({
                where: { id: payment.orderId },
                data: {
                    paymentStatus: client_1.PaymentStatus.PAID,
                    paymentMethod: client_1.PaymentMethod.CHAPA,
                    paidAt: new Date(),
                    status: client_1.OrderStatus.PAID,
                },
            });
            await tx.orderEvent.create({
                data: {
                    orderId: payment.orderId,
                    status: client_1.OrderStatus.PAID,
                    note: `Payment received via Chapa (${txRef})`,
                    isPublic: true,
                },
            });
            return updated;
        });
        if (updatedOrder) {
            await this.notifications.notifyOrderStatus(updatedOrder);
        }
        if (result.verified) {
            try {
                await this.autoAssign.tryAutoAssign(payment.orderId);
            }
            catch (e) {
                this.logger.error(`Auto-assign failed for order ${payment.orderId}: ${e.message}`);
            }
        }
        return {
            status: newStatus,
            verified: result.verified,
            amount: result.amount,
            paymentMethod: result.paymentMethod,
        };
    }
    async handleChapaWebhook(body) {
        this.logger.log('Chapa webhook received: ' + JSON.stringify(body));
        const txRef = body?.tx_ref || body?.trx_ref || body?.data?.tx_ref || body?.reference;
        if (!txRef) {
            this.logger.warn('Chapa webhook: no tx_ref found');
            return { ok: true };
        }
        try {
            await this.verifyChapaPayment(txRef);
        }
        catch (e) {
            this.logger.error(`Webhook verify failed for ${txRef}: ${e.message}`);
        }
        return { ok: true };
    }
    async listOrderPayments(orderId) {
        return this.prisma.payment.findMany({
            where: { orderId },
            orderBy: { createdAt: 'desc' },
        });
    }
    async listMyPayments(userId, accountType) {
        if (accountType === 'COURIER') {
            return this.prisma.payment.findMany({
                where: {
                    order: { courierId: userId },
                },
                orderBy: { createdAt: 'desc' },
                include: {
                    order: {
                        select: {
                            id: true,
                            trackingNumber: true,
                            senderName: true,
                            receiverName: true,
                            deliveryFee: true,
                            courierEarning: true,
                        },
                    },
                },
                take: 100,
            });
        }
        return this.prisma.payment.findMany({
            where: {
                order: {
                    OR: [
                        { senderId: userId },
                        { receiverId: userId },
                    ],
                },
            },
            orderBy: { createdAt: 'desc' },
            include: {
                order: {
                    select: {
                        id: true,
                        trackingNumber: true,
                        senderName: true,
                        receiverName: true,
                        deliveryFee: true,
                        courierEarning: true,
                    },
                },
            },
            take: 100,
        });
    }
    async markRefunded(paymentId, reason, amount, staffId) {
        this.logger.log(`markRefunded: paymentId=${paymentId}, staffId=${staffId || '(none)'}`);
        const payment = await this.prisma.payment.findUnique({
            where: { id: paymentId },
        });
        if (!payment)
            throw new common_1.NotFoundException('Payment not found');
        if (payment.status !== client_1.PaymentStatus.PAID)
            throw new common_1.BadRequestException('Only PAID payments can be refunded');
        let validStaffId = undefined;
        if (staffId) {
            const staff = await this.prisma.staff.findUnique({
                where: { id: staffId },
                select: { id: true },
            });
            if (staff) {
                validStaffId = staff.id;
            }
            else {
                this.logger.warn(`⚠️  Staff "${staffId}" not found — refund will be recorded WITHOUT createdById`);
            }
        }
        await this.prisma.payment.update({
            where: { id: paymentId },
            data: {
                status: client_1.PaymentStatus.REFUNDED,
                refundedAt: new Date(),
                refundAmount: amount ?? payment.amount,
                refundReason: reason,
                ...(validStaffId ? { createdById: validStaffId } : {}),
            },
        });
        await this.prisma.order.update({
            where: { id: payment.orderId },
            data: { paymentStatus: client_1.PaymentStatus.REFUNDED },
        });
        return { message: 'Payment marked as refunded' };
    }
    async listAllPayments(filters) {
        const { page, limit, status, method, search, from, to } = filters;
        const skip = (page - 1) * limit;
        const where = {};
        if (status)
            where.status = status;
        if (method)
            where.method = method;
        if (from || to) {
            where.createdAt = {};
            if (from)
                where.createdAt.gte = new Date(from);
            if (to)
                where.createdAt.lte = new Date(to);
        }
        if (search) {
            where.OR = [
                { gatewayRef: { contains: search, mode: 'insensitive' } },
                { order: { trackingNumber: { contains: search, mode: 'insensitive' } } },
            ];
        }
        const [data, total] = await Promise.all([
            this.prisma.payment.findMany({
                where,
                skip,
                take: limit,
                orderBy: { createdAt: 'desc' },
                include: {
                    order: {
                        select: {
                            id: true,
                            trackingNumber: true,
                            senderName: true,
                            senderPhone: true,
                            receiverName: true,
                            receiverPhone: true,
                            deliveryFee: true,
                            courierEarning: true,
                            status: true,
                        },
                    },
                    createdBy: {
                        select: { id: true, name: true },
                    },
                },
            }),
            this.prisma.payment.count({ where }),
        ]);
        return {
            data,
            total,
            page,
            limit,
            pages: Math.ceil(total / limit),
        };
    }
    async getPaymentStats() {
        const [totalCount, totalPaid, totalPending, totalFailed, totalRefunded] = await Promise.all([
            this.prisma.payment.count(),
            this.prisma.payment.aggregate({
                where: { status: 'PAID' },
                _sum: { amount: true },
                _count: true,
            }),
            this.prisma.payment.count({ where: { status: 'PENDING' } }),
            this.prisma.payment.count({ where: { status: 'FAILED' } }),
            this.prisma.payment.aggregate({
                where: { status: 'REFUNDED' },
                _sum: { refundAmount: true },
                _count: true,
            }),
        ]);
        return {
            totalCount,
            totalPaidAmount: totalPaid._sum.amount || 0,
            totalPaidCount: totalPaid._count,
            pendingCount: totalPending,
            failedCount: totalFailed,
            refundedAmount: totalRefunded._sum.refundAmount || 0,
            refundedCount: totalRefunded._count,
        };
    }
};
exports.PaymentsService = PaymentsService;
exports.PaymentsService = PaymentsService = PaymentsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        chapa_service_1.ChapaService,
        auto_assign_service_1.AutoAssignService,
        notifications_service_1.NotificationsService])
], PaymentsService);
//# sourceMappingURL=payments.service.js.map