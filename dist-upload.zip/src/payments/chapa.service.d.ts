import { PrismaService } from '../prisma/prisma.service';
interface ChapaInitParams {
    amount: number;
    currency?: string;
    email: string;
    firstName: string;
    lastName: string;
    phone?: string;
    txRef: string;
    callbackUrl: string;
    returnUrl: string;
    title?: string;
    description?: string;
    provider: {
        apiSecret: string | null;
        isTestMode: boolean;
        configJson?: any;
    };
}
export declare class ChapaService {
    private prisma;
    private readonly logger;
    private readonly baseUrl;
    constructor(prisma: PrismaService);
    getChapaProvider(): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        sortOrder: number;
        isEnabled: boolean;
        isTestMode: boolean;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
        apiKey: string | null;
        apiSecret: string | null;
        merchantId: string | null;
        webhookUrl: string | null;
        configJson: import("@prisma/client/runtime/library").JsonValue | null;
        createdById: string | null;
        updatedById: string | null;
        createdAt: Date;
        updatedAt: Date;
    }>;
    initialize(params: ChapaInitParams): Promise<{
        checkoutUrl: string;
        raw: any;
    }>;
    verify(txRef: string): Promise<{
        verified: boolean;
        amount: number | null;
        currency: any;
        paymentMethod: any;
        chapaRef: any;
        raw: any;
    }>;
}
export {};
