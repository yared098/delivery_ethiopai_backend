import { PaymentsService } from './payments.service';
export declare class ChapaWebhookController {
    private payments;
    constructor(payments: PaymentsService);
    webhook(body: any): Promise<{
        ok: boolean;
    }>;
    callback(body: any): Promise<{
        ok: boolean;
    }>;
}
