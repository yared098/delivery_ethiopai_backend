import { PrismaService } from '../prisma/prisma.service';
import { ChapaService } from './chapa.service';
import { InitChapaPaymentDto } from './dto/init-chapa-payment.dto';
import { AutoAssignService } from '../auto-assign/auto-assign.service';
import { NotificationsService } from '../notifications/notifications.service';
export declare class PaymentsService {
    private prisma;
    private chapa;
    private autoAssign;
    private notifications;
    private readonly logger;
    constructor(prisma: PrismaService, chapa: ChapaService, autoAssign: AutoAssignService, notifications: NotificationsService);
    initChapaPayment(dto: InitChapaPaymentDto, customerId?: string): Promise<{
        paymentId: string;
        txRef: string;
        checkoutUrl: string;
        amount: number;
        currency: string;
    }>;
    verifyChapaPayment(txRef: string): Promise<{
        status: "PAID";
        verified: boolean;
        alreadyPaid: boolean;
        amount?: undefined;
        paymentMethod?: undefined;
    } | {
        status: "PAID" | "FAILED";
        verified: boolean;
        amount: number | null;
        paymentMethod: any;
        alreadyPaid?: undefined;
    }>;
    handleChapaWebhook(body: any): Promise<{
        ok: boolean;
    }>;
    listOrderPayments(orderId: string): Promise<{
        id: string;
        createdById: string | null;
        createdAt: Date;
        updatedAt: Date;
        method: import("@prisma/client").$Enums.PaymentMethod;
        status: import("@prisma/client").$Enums.PaymentStatus;
        paidAt: Date | null;
        orderId: string;
        amount: number;
        currency: string;
        notes: string | null;
        party: import("@prisma/client").$Enums.PaymentParty;
        gatewayRef: string | null;
        gatewayPayload: import("@prisma/client/runtime/library").JsonValue | null;
        refundedAt: Date | null;
        refundAmount: number | null;
        refundReason: string | null;
    }[]>;
    listMyPayments(userId: string, accountType: 'CUSTOMER' | 'COURIER' | 'STAFF'): Promise<({
        order: {
            id: string;
            trackingNumber: string;
            senderName: string;
            receiverName: string | null;
            deliveryFee: number;
            courierEarning: number;
        };
    } & {
        id: string;
        createdById: string | null;
        createdAt: Date;
        updatedAt: Date;
        method: import("@prisma/client").$Enums.PaymentMethod;
        status: import("@prisma/client").$Enums.PaymentStatus;
        paidAt: Date | null;
        orderId: string;
        amount: number;
        currency: string;
        notes: string | null;
        party: import("@prisma/client").$Enums.PaymentParty;
        gatewayRef: string | null;
        gatewayPayload: import("@prisma/client/runtime/library").JsonValue | null;
        refundedAt: Date | null;
        refundAmount: number | null;
        refundReason: string | null;
    })[]>;
    markRefunded(paymentId: string, reason: string, amount?: number, staffId?: string): Promise<{
        message: string;
    }>;
    listAllPayments(filters: {
        page: number;
        limit: number;
        status?: string;
        method?: string;
        search?: string;
        from?: string;
        to?: string;
    }): Promise<{
        data: ({
            createdBy: {
                id: string;
                name: string;
            } | null;
            order: {
                id: string;
                trackingNumber: string;
                senderName: string;
                senderPhone: string;
                receiverName: string | null;
                receiverPhone: string;
                deliveryFee: number;
                courierEarning: number;
                status: import("@prisma/client").$Enums.OrderStatus;
            };
        } & {
            id: string;
            createdById: string | null;
            createdAt: Date;
            updatedAt: Date;
            method: import("@prisma/client").$Enums.PaymentMethod;
            status: import("@prisma/client").$Enums.PaymentStatus;
            paidAt: Date | null;
            orderId: string;
            amount: number;
            currency: string;
            notes: string | null;
            party: import("@prisma/client").$Enums.PaymentParty;
            gatewayRef: string | null;
            gatewayPayload: import("@prisma/client/runtime/library").JsonValue | null;
            refundedAt: Date | null;
            refundAmount: number | null;
            refundReason: string | null;
        })[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    getPaymentStats(): Promise<{
        totalCount: number;
        totalPaidAmount: number;
        totalPaidCount: number;
        pendingCount: number;
        failedCount: number;
        refundedAmount: number;
        refundedCount: number;
    }>;
}
