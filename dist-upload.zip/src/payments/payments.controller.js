"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentsController = void 0;
const common_1 = require("@nestjs/common");
const payments_service_1 = require("./payments.service");
const payment_providers_service_1 = require("../payment-providers/payment-providers.service");
const init_chapa_payment_dto_1 = require("./dto/init-chapa-payment.dto");
const any_auth_guard_1 = require("../common/guards/any-auth.guard");
const public_decorator_1 = require("../common/decorators/public.decorator");
let PaymentsController = class PaymentsController {
    constructor(payments, providers) {
        this.payments = payments;
        this.providers = providers;
    }
    listEnabledProviders() {
        return this.providers.findEnabled();
    }
    initChapa(dto, req) {
        const payerId = req.customer?.id || req.staff?.id || req.courier?.id;
        return this.payments.initChapaPayment(dto, payerId);
    }
    verify(txRef) {
        return this.payments.verifyChapaPayment(txRef);
    }
    async listMyPayments(req) {
        if (req.courier) {
            return this.payments.listMyPayments(req.courier.id, 'COURIER');
        }
        if (req.staff) {
            return this.payments.listMyPayments(req.staff.id, 'STAFF');
        }
        if (req.customer) {
            return this.payments.listMyPayments(req.customer.id, 'CUSTOMER');
        }
        return [];
    }
};
exports.PaymentsController = PaymentsController;
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('providers'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], PaymentsController.prototype, "listEnabledProviders", null);
__decorate([
    (0, common_1.UseGuards)(any_auth_guard_1.AnyAuthGuard),
    (0, common_1.Post)('chapa/init'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [init_chapa_payment_dto_1.InitChapaPaymentDto, Object]),
    __metadata("design:returntype", void 0)
], PaymentsController.prototype, "initChapa", null);
__decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Get)('chapa/verify/:txRef'),
    __param(0, (0, common_1.Param)('txRef')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], PaymentsController.prototype, "verify", null);
__decorate([
    (0, common_1.UseGuards)(any_auth_guard_1.AnyAuthGuard),
    (0, common_1.Get)('history'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], PaymentsController.prototype, "listMyPayments", null);
exports.PaymentsController = PaymentsController = __decorate([
    (0, common_1.Controller)('payments'),
    __metadata("design:paramtypes", [payments_service_1.PaymentsService,
        payment_providers_service_1.PaymentProvidersService])
], PaymentsController);
//# sourceMappingURL=payments.controller.js.map