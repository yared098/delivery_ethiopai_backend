import { PaymentsService } from './payments.service';
import { PaymentProvidersService } from '../payment-providers/payment-providers.service';
import { InitChapaPaymentDto } from './dto/init-chapa-payment.dto';
export declare class PaymentsController {
    private payments;
    private providers;
    constructor(payments: PaymentsService, providers: PaymentProvidersService);
    listEnabledProviders(): Promise<{
        id: string;
        code: string;
        name: string;
        description: string | null;
        type: import("@prisma/client").$Enums.PaymentProviderType;
        logoUrl: string | null;
        color: string | null;
        feePercent: number;
        feeFixed: number;
        minAmount: number | null;
        maxAmount: number | null;
    }[]>;
    initChapa(dto: InitChapaPaymentDto, req: any): Promise<{
        paymentId: string;
        txRef: string;
        checkoutUrl: string;
        amount: number;
        currency: string;
    }>;
    verify(txRef: string): Promise<{
        status: "PAID";
        verified: boolean;
        alreadyPaid: boolean;
        amount?: undefined;
        paymentMethod?: undefined;
    } | {
        status: "PAID" | "FAILED";
        verified: boolean;
        amount: number | null;
        paymentMethod: any;
        alreadyPaid?: undefined;
    }>;
    listMyPayments(req: any): Promise<({
        order: {
            id: string;
            trackingNumber: string;
            senderName: string;
            receiverName: string | null;
            deliveryFee: number;
            courierEarning: number;
        };
    } & {
        id: string;
        createdById: string | null;
        createdAt: Date;
        updatedAt: Date;
        method: import("@prisma/client").$Enums.PaymentMethod;
        status: import("@prisma/client").$Enums.PaymentStatus;
        paidAt: Date | null;
        orderId: string;
        amount: number;
        currency: string;
        notes: string | null;
        party: import("@prisma/client").$Enums.PaymentParty;
        gatewayRef: string | null;
        gatewayPayload: import("@prisma/client/runtime/library").JsonValue | null;
        refundedAt: Date | null;
        refundAmount: number | null;
        refundReason: string | null;
    })[]>;
}
