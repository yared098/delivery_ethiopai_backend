export declare class VerifyPaymentQueryDto {
    tx_ref: string;
}
