export declare class InitChapaPaymentDto {
    orderId: string;
    amount?: number;
    email?: string;
    firstName?: string;
    lastName?: string;
    phone?: string;
    returnUrl?: string;
}
