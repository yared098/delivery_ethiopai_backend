"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ChapaService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChapaService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
let ChapaService = ChapaService_1 = class ChapaService {
    constructor(prisma) {
        this.prisma = prisma;
        this.logger = new common_1.Logger(ChapaService_1.name);
        this.baseUrl = 'https://api.chapa.co/v1';
    }
    async getChapaProvider() {
        const provider = await this.prisma.paymentProvider.findUnique({
            where: { code: 'CHAPA' },
        });
        console.log('🔍 [getChapaProvider]:', {
            found: !!provider,
            code: provider?.code,
            isEnabled: provider?.isEnabled,
            keyLen: provider?.apiSecret?.length || 0,
            keyPrefix: provider?.apiSecret?.slice(0, 14) || '(null)',
        });
        if (!provider)
            throw new common_1.NotFoundException('Chapa provider not configured');
        if (!provider.isEnabled)
            throw new common_1.BadRequestException('Chapa payment is currently disabled');
        if (!provider.apiSecret)
            throw new common_1.BadRequestException('Chapa secret key not configured');
        return provider;
    }
    async initialize(params) {
        const body = {
            amount: params.amount.toFixed(2),
            currency: params.currency || 'ETB',
            email: "yades.dev@gmail.com",
            first_name: params.firstName,
            last_name: params.lastName,
            phone_number: params.phone,
            tx_ref: params.txRef,
            callback_url: params.callbackUrl,
            return_url: params.returnUrl,
            customization: {
                title: params.title || 'Truest Express',
                description: params.description || `Payment ${params.txRef}`,
            },
        };
        const key = params.provider?.apiSecret || '';
        console.log('🔍 [initialize] Sending to Chapa:', {
            keyLength: key.length,
            keyPrefix: key.slice(0, 14),
            authHeader: `Bearer ${key.slice(0, 20)}...`,
            url: `${this.baseUrl}/transaction/initialize`,
        });
        const res = await fetch(`${this.baseUrl}/transaction/initialize`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${key}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body),
        });
        const data = await res.json();
        console.log('📥 [initialize] HTTP:', res.status);
        console.log('📥 [initialize] Response:', JSON.stringify(data, null, 2));
        if (!res.ok || data.status !== 'success') {
            this.logger.error('Chapa init failed', data);
            throw new common_1.BadRequestException(data?.message || 'Failed to initialize Chapa payment');
        }
        return {
            checkoutUrl: data.data.checkout_url,
            raw: data,
        };
    }
    async verify(txRef) {
        const provider = await this.getChapaProvider();
        const res = await fetch(`${this.baseUrl}/transaction/verify/${encodeURIComponent(txRef)}`, {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${provider.apiSecret}`,
            },
        });
        const data = await res.json();
        const success = res.ok && data.status === 'success' && data.data?.status === 'success';
        return {
            verified: success,
            amount: data?.data?.amount ? Number(data.data.amount) : null,
            currency: data?.data?.currency,
            paymentMethod: data?.data?.payment_method,
            chapaRef: data?.data?.reference,
            raw: data,
        };
    }
};
exports.ChapaService = ChapaService;
exports.ChapaService = ChapaService = ChapaService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ChapaService);
//# sourceMappingURL=chapa.service.js.map