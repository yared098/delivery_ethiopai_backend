"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CouriersController = void 0;
const common_1 = require("@nestjs/common");
const couriers_service_1 = require("./couriers.service");
const create_courier_dto_1 = require("./dto/create-courier.dto");
const update_courier_dto_1 = require("./dto/update-courier.dto");
const list_couriers_query_dto_1 = require("./dto/list-couriers-query.dto");
const reject_courier_dto_1 = require("./dto/reject-courier.dto");
const jwt_auth_guard_1 = require("../common/guards/jwt-auth.guard");
const roles_guard_1 = require("../common/guards/roles.guard");
const staff_roles_decorator_1 = require("../common/decorators/staff-roles.decorator");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const client_1 = require("@prisma/client");
let CouriersController = class CouriersController {
    constructor(couriers) {
        this.couriers = couriers;
    }
    create(dto, user) {
        return this.couriers.create(dto, user);
    }
    findAll(query, user) {
        return this.couriers.findAll(query, user);
    }
    findOne(id, user) {
        return this.couriers.findOne(id, user);
    }
    update(id, dto, user) {
        return this.couriers.update(id, dto, user);
    }
    approve(id, user) {
        return this.couriers.approve(id, user);
    }
    reject(id, dto, user) {
        return this.couriers.reject(id, dto, user);
    }
    suspend(id, user) {
        return this.couriers.suspend(id, user);
    }
    reactivate(id, user) {
        return this.couriers.reactivate(id, user);
    }
};
exports.CouriersController = CouriersController;
__decorate([
    (0, common_1.Post)(),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_courier_dto_1.CreateCourierDto, Object]),
    __metadata("design:returntype", void 0)
], CouriersController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Query)()),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [list_couriers_query_dto_1.ListCouriersQueryDto, Object]),
    __metadata("design:returntype", void 0)
], CouriersController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], CouriersController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_courier_dto_1.UpdateCourierDto, Object]),
    __metadata("design:returntype", void 0)
], CouriersController.prototype, "update", null);
__decorate([
    (0, common_1.Post)(':id/approve'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], CouriersController.prototype, "approve", null);
__decorate([
    (0, common_1.Post)(':id/reject'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN, client_1.StaffRole.BRANCH_MANAGER),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, reject_courier_dto_1.RejectCourierDto, Object]),
    __metadata("design:returntype", void 0)
], CouriersController.prototype, "reject", null);
__decorate([
    (0, common_1.Post)(':id/suspend'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], CouriersController.prototype, "suspend", null);
__decorate([
    (0, common_1.Post)(':id/reactivate'),
    (0, staff_roles_decorator_1.StaffRoles)(client_1.StaffRole.SUPER_ADMIN, client_1.StaffRole.REGIONAL_ADMIN),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], CouriersController.prototype, "reactivate", null);
exports.CouriersController = CouriersController = __decorate([
    (0, common_1.Controller)('admin/couriers'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard),
    __metadata("design:paramtypes", [couriers_service_1.CouriersService])
], CouriersController);
//# sourceMappingURL=couriers.controller.js.map