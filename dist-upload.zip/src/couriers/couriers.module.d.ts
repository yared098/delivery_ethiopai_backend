export declare class CouriersModule {
}
