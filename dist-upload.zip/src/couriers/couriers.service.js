"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CouriersService = void 0;
const common_1 = require("@nestjs/common");
const argon2 = __importStar(require("argon2"));
const prisma_service_1 = require("../prisma/prisma.service");
const client_1 = require("@prisma/client");
let CouriersService = class CouriersService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    courierScope(currentUser) {
        if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN && currentUser.regionId) {
            return { regionId: currentUser.regionId };
        }
        if (currentUser.role === client_1.StaffRole.BRANCH_MANAGER && currentUser.branchId) {
            return { branchId: currentUser.branchId };
        }
        return currentUser.role === client_1.StaffRole.SUPER_ADMIN ? {} : { id: '__no_access__' };
    }
    assertCourierScope(courier, currentUser) {
        if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN &&
            courier.regionId !== currentUser.regionId) {
            throw new common_1.ForbiddenException('You can only manage couriers in your region');
        }
        if (currentUser.role === client_1.StaffRole.BRANCH_MANAGER &&
            courier.branchId !== currentUser.branchId) {
            throw new common_1.ForbiddenException('You can only manage couriers in your branch');
        }
    }
    normalizePhone(phone) {
        const digits = phone.replace(/\D/g, '');
        if (digits.startsWith('251') && digits.length === 12)
            return digits;
        if (digits.startsWith('0') && digits.length === 10)
            return '251' + digits.slice(1);
        if (digits.length === 9)
            return '251' + digits;
        throw new common_1.BadRequestException('Invalid phone');
    }
    async create(dto, currentUser) {
        const phone = this.normalizePhone(dto.phone);
        if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN &&
            dto.regionId !== currentUser.regionId) {
            throw new common_1.ForbiddenException('You can only create couriers in your region');
        }
        if (currentUser.role === client_1.StaffRole.BRANCH_MANAGER &&
            (dto.branchId !== currentUser.branchId ||
                dto.regionId !== currentUser.regionId)) {
            throw new common_1.ForbiddenException('You can only create couriers in your branch');
        }
        const region = await this.prisma.region.findUnique({
            where: { id: dto.regionId },
        });
        if (!region)
            throw new common_1.NotFoundException('Region not found');
        const branch = await this.prisma.branch.findUnique({
            where: { id: dto.branchId },
        });
        if (!branch)
            throw new common_1.NotFoundException('Branch not found');
        if (branch.regionId !== dto.regionId) {
            throw new common_1.BadRequestException('Branch does not belong to this region');
        }
        const existing = await this.prisma.courier.findUnique({ where: { phone } });
        if (existing) {
            throw new common_1.ConflictException('A courier with this phone already exists');
        }
        if (dto.email) {
            const emailExists = await this.prisma.courier.findUnique({
                where: { email: dto.email },
            });
            if (emailExists)
                throw new common_1.ConflictException('Email already in use');
        }
        if (dto.vehiclePlate) {
            const dup = await this.prisma.courier.findFirst({
                where: { vehiclePlate: dto.vehiclePlate },
            });
            if (dup)
                throw new common_1.ConflictException('Vehicle plate already registered');
        }
        const passwordHash = dto.password ? await argon2.hash(dto.password) : null;
        const data = {
            phone,
            name: dto.name,
            email: dto.email,
            regionId: dto.regionId,
            branchId: dto.branchId,
            vehicleType: dto.vehicleType,
            vehiclePlate: dto.vehiclePlate,
            vehicleModel: dto.vehicleModel,
            vehicleColor: dto.vehicleColor,
            vehicleYear: dto.vehicleYear,
            licenseNumber: dto.licenseNumber,
            maxWeightKg: dto.maxWeightKg,
            maxVolumeL: dto.maxVolumeL,
            handlesFragile: dto.handlesFragile ?? false,
            handlesRefrigerated: dto.handlesRefrigerated ?? false,
            nationalIdNumber: dto.nationalIdNumber,
            nationalIdImageUrl: dto.nationalIdImageUrl,
            licenseImageUrl: dto.licenseImageUrl,
            vehicleImageUrl: dto.vehicleImageUrl,
            selfieUrl: dto.selfieUrl,
            passwordHash,
            passwordChangedAt: passwordHash ? new Date() : null,
            status: client_1.CourierStatus.PENDING,
            isActive: true,
            phoneVerified: false,
            createdById: currentUser.id,
        };
        return this.prisma.courier.create({
            data,
            select: {
                id: true,
                phone: true,
                name: true,
                email: true,
                regionId: true,
                branchId: true,
                vehicleType: true,
                vehiclePlate: true,
                nationalIdImageUrl: true,
                licenseImageUrl: true,
                vehicleImageUrl: true,
                selfieUrl: true,
                status: true,
                rating: true,
                totalDeliveries: true,
                createdAt: true,
                region: { select: { id: true, name: true, code: true } },
                branch: { select: { id: true, name: true, code: true } },
            },
        });
    }
    async findAll(query, currentUser) {
        const scope = this.courierScope(currentUser);
        const where = { AND: [scope] };
        if (query.regionId)
            where.AND.push({ regionId: query.regionId });
        if (query.status)
            where.status = query.status;
        if (query.vehicleType)
            where.vehicleType = query.vehicleType;
        if (query.branchId) {
            where.AND.push({ branchId: query.branchId });
        }
        if (query.search) {
            where.OR = [
                { name: { contains: query.search, mode: 'insensitive' } },
                { phone: { contains: query.search } },
                { vehiclePlate: { contains: query.search, mode: 'insensitive' } },
            ];
        }
        const page = query.page || 1;
        const limit = query.limit || 20;
        const skip = (page - 1) * limit;
        const [data, total] = await Promise.all([
            this.prisma.courier.findMany({
                where,
                select: {
                    id: true,
                    phone: true,
                    name: true,
                    email: true,
                    regionId: true,
                    branchId: true,
                    vehicleType: true,
                    vehiclePlate: true,
                    currentLat: true,
                    currentLng: true,
                    lastSeenAt: true,
                    nationalIdImageUrl: true,
                    licenseImageUrl: true,
                    vehicleImageUrl: true,
                    selfieUrl: true,
                    status: true,
                    rating: true,
                    totalDeliveries: true,
                    isOnline: true,
                    isActive: true,
                    createdAt: true,
                    region: { select: { id: true, name: true, code: true } },
                    branch: { select: { id: true, name: true, code: true } },
                },
                orderBy: { createdAt: 'desc' },
                skip,
                take: limit,
            }),
            this.prisma.courier.count({ where }),
        ]);
        return { data, total, page, limit, pages: Math.ceil(total / limit) };
    }
    async findOne(id, currentUser) {
        const courier = await this.prisma.courier.findUnique({
            where: { id },
            include: {
                region: { select: { id: true, name: true, code: true } },
                branch: { select: { id: true, name: true, code: true } },
            },
        });
        if (!courier)
            throw new common_1.NotFoundException('Courier not found');
        this.assertCourierScope(courier, currentUser);
        return courier;
    }
    async update(id, dto, currentUser) {
        const existing = await this.prisma.courier.findUnique({ where: { id } });
        if (!existing)
            throw new common_1.NotFoundException('Courier not found');
        this.assertCourierScope(existing, currentUser);
        const targetRegionId = dto.regionId ?? existing.regionId;
        const targetBranchId = dto.branchId ?? existing.branchId;
        if (currentUser.role === client_1.StaffRole.BRANCH_MANAGER &&
            (targetRegionId !== currentUser.regionId ||
                targetBranchId !== currentUser.branchId)) {
            throw new common_1.ForbiddenException('You can only manage couriers in your branch');
        }
        if (dto.regionId && dto.regionId !== existing.regionId) {
            const region = await this.prisma.region.findUnique({
                where: { id: dto.regionId },
            });
            if (!region)
                throw new common_1.NotFoundException('Region not found');
            if (currentUser.role === client_1.StaffRole.REGIONAL_ADMIN &&
                dto.regionId !== currentUser.regionId) {
                throw new common_1.ForbiddenException('You can only move couriers within your region');
            }
        }
        if (dto.branchId && dto.branchId !== existing.branchId) {
            const branch = await this.prisma.branch.findUnique({
                where: { id: dto.branchId },
            });
            if (!branch)
                throw new common_1.NotFoundException('Branch not found');
            if (branch.regionId !== targetRegionId) {
                throw new common_1.BadRequestException('Branch does not belong to this region');
            }
        }
        let phone;
        if (dto.phone) {
            phone = this.normalizePhone(dto.phone);
            if (phone !== existing.phone) {
                const dup = await this.prisma.courier.findUnique({ where: { phone } });
                if (dup)
                    throw new common_1.ConflictException('Phone already in use');
            }
        }
        if (dto.email && dto.email !== existing.email) {
            const dup = await this.prisma.courier.findUnique({
                where: { email: dto.email },
            });
            if (dup)
                throw new common_1.ConflictException('Email already in use');
        }
        if (dto.vehiclePlate && dto.vehiclePlate !== existing.vehiclePlate) {
            const dup = await this.prisma.courier.findFirst({
                where: { vehiclePlate: dto.vehiclePlate },
            });
            if (dup)
                throw new common_1.ConflictException('Vehicle plate already registered');
        }
        const data = {};
        if (dto.name !== undefined)
            data.name = dto.name;
        if (dto.email !== undefined)
            data.email = dto.email;
        if (phone)
            data.phone = phone;
        if (dto.regionId !== undefined)
            data.regionId = dto.regionId;
        if (dto.branchId !== undefined)
            data.branchId = dto.branchId;
        if (dto.vehicleType !== undefined)
            data.vehicleType = dto.vehicleType;
        if (dto.vehiclePlate !== undefined)
            data.vehiclePlate = dto.vehiclePlate;
        if (dto.vehicleModel !== undefined)
            data.vehicleModel = dto.vehicleModel;
        if (dto.vehicleColor !== undefined)
            data.vehicleColor = dto.vehicleColor;
        if (dto.vehicleYear !== undefined)
            data.vehicleYear = dto.vehicleYear;
        if (dto.licenseNumber !== undefined)
            data.licenseNumber = dto.licenseNumber;
        if (dto.maxWeightKg !== undefined)
            data.maxWeightKg = dto.maxWeightKg;
        if (dto.maxVolumeL !== undefined)
            data.maxVolumeL = dto.maxVolumeL;
        if (dto.handlesFragile !== undefined)
            data.handlesFragile = dto.handlesFragile;
        if (dto.handlesRefrigerated !== undefined)
            data.handlesRefrigerated = dto.handlesRefrigerated;
        if (dto.nationalIdNumber !== undefined)
            data.nationalIdNumber = dto.nationalIdNumber;
        if (dto.nationalIdImageUrl !== undefined)
            data.nationalIdImageUrl = dto.nationalIdImageUrl;
        if (dto.licenseImageUrl !== undefined)
            data.licenseImageUrl = dto.licenseImageUrl;
        if (dto.vehicleImageUrl !== undefined)
            data.vehicleImageUrl = dto.vehicleImageUrl;
        if (dto.selfieUrl !== undefined)
            data.selfieUrl = dto.selfieUrl;
        if (dto.password) {
            data.passwordHash = await argon2.hash(dto.password);
            data.passwordChangedAt = new Date();
        }
        return this.prisma.courier.update({
            where: { id },
            data,
            select: {
                id: true,
                phone: true,
                name: true,
                email: true,
                regionId: true,
                branchId: true,
                vehicleType: true,
                vehiclePlate: true,
                nationalIdImageUrl: true,
                licenseImageUrl: true,
                vehicleImageUrl: true,
                selfieUrl: true,
                status: true,
                updatedAt: true,
            },
        });
    }
    async approve(id, currentUser) {
        await this.findOne(id, currentUser);
        return this.prisma.courier.update({
            where: { id },
            data: {
                status: client_1.CourierStatus.APPROVED,
                approvedById: currentUser.id,
                approvedAt: new Date(),
                rejectionReason: null,
            },
            select: { id: true, status: true, approvedAt: true },
        });
    }
    async reject(id, dto, currentUser) {
        await this.findOne(id, currentUser);
        return this.prisma.courier.update({
            where: { id },
            data: {
                status: client_1.CourierStatus.REJECTED,
                rejectionReason: dto.reason,
                rejectedById: currentUser.id,
                rejectedAt: new Date(),
            },
            select: { id: true, status: true, rejectionReason: true },
        });
    }
    async suspend(id, currentUser) {
        await this.findOne(id, currentUser);
        await this.prisma.courier.update({
            where: { id },
            data: {
                status: client_1.CourierStatus.SUSPENDED,
                isActive: false,
                isOnline: false,
                suspendedAt: new Date(),
                suspendedById: currentUser.id,
            },
        });
        await this.prisma.refreshToken.updateMany({
            where: { accountId: id, accountType: client_1.AccountType.COURIER, revokedAt: null },
            data: { revokedAt: new Date() },
        });
        return { message: 'Courier suspended' };
    }
    async reactivate(id, currentUser) {
        await this.findOne(id, currentUser);
        await this.prisma.courier.update({
            where: { id },
            data: {
                status: client_1.CourierStatus.APPROVED,
                isActive: true,
                suspendedAt: null,
                suspendedById: null,
            },
        });
        return { message: 'Courier reactivated' };
    }
};
exports.CouriersService = CouriersService;
exports.CouriersService = CouriersService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], CouriersService);
//# sourceMappingURL=couriers.service.js.map