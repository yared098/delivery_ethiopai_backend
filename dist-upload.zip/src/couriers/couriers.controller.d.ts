import { CouriersService } from './couriers.service';
import { CreateCourierDto } from './dto/create-courier.dto';
import { UpdateCourierDto } from './dto/update-courier.dto';
import { ListCouriersQueryDto } from './dto/list-couriers-query.dto';
import { RejectCourierDto } from './dto/reject-courier.dto';
export declare class CouriersController {
    private couriers;
    constructor(couriers: CouriersService);
    create(dto: CreateCourierDto, user: any): Promise<{
        id: string;
        name: string;
        createdAt: Date;
        status: import("@prisma/client").$Enums.CourierStatus;
        phone: string;
        email: string | null;
        regionId: string;
        branchId: string;
        region: {
            id: string;
            code: string;
            name: string;
        };
        branch: {
            id: string;
            code: string;
            name: string;
        };
        vehicleType: import("@prisma/client").$Enums.VehicleType;
        vehiclePlate: string | null;
        nationalIdImageUrl: string | null;
        licenseImageUrl: string | null;
        vehicleImageUrl: string | null;
        selfieUrl: string | null;
        rating: number;
        totalDeliveries: number;
    }>;
    findAll(query: ListCouriersQueryDto, user: any): Promise<{
        data: {
            id: string;
            name: string;
            createdAt: Date;
            status: import("@prisma/client").$Enums.CourierStatus;
            phone: string;
            email: string | null;
            regionId: string;
            branchId: string;
            isActive: boolean;
            region: {
                id: string;
                code: string;
                name: string;
            };
            branch: {
                id: string;
                code: string;
                name: string;
            };
            vehicleType: import("@prisma/client").$Enums.VehicleType;
            vehiclePlate: string | null;
            nationalIdImageUrl: string | null;
            licenseImageUrl: string | null;
            vehicleImageUrl: string | null;
            selfieUrl: string | null;
            rating: number;
            totalDeliveries: number;
            isOnline: boolean;
            currentLat: number | null;
            currentLng: number | null;
            lastSeenAt: Date | null;
        }[];
        total: number;
        page: number;
        limit: number;
        pages: number;
    }>;
    findOne(id: string, user: any): Promise<{
        region: {
            id: string;
            code: string;
            name: string;
        };
        branch: {
            id: string;
            code: string;
            name: string;
        };
    } & {
        id: string;
        name: string;
        createdById: string | null;
        createdAt: Date;
        updatedAt: Date;
        status: import("@prisma/client").$Enums.CourierStatus;
        phone: string;
        email: string | null;
        passwordHash: string | null;
        passwordChangedAt: Date | null;
        mustChangePassword: boolean;
        regionId: string;
        branchId: string;
        isActive: boolean;
        phoneVerified: boolean;
        suspendedAt: Date | null;
        suspendedById: string | null;
        vehicleType: import("@prisma/client").$Enums.VehicleType;
        vehiclePlate: string | null;
        vehicleModel: string | null;
        vehicleColor: string | null;
        vehicleYear: number | null;
        licenseNumber: string | null;
        maxWeightKg: number | null;
        maxVolumeL: number | null;
        handlesFragile: boolean;
        handlesRefrigerated: boolean;
        serviceType: import("@prisma/client").$Enums.ServiceType;
        serviceRegionIds: string[];
        maxTravelKm: number | null;
        acceptsReturnTrip: boolean;
        isOnLongTrip: boolean;
        availableFrom: Date | null;
        nationalIdNumber: string | null;
        nationalIdImageUrl: string | null;
        licenseImageUrl: string | null;
        vehicleImageUrl: string | null;
        selfieUrl: string | null;
        rejectionReason: string | null;
        approvedById: string | null;
        approvedAt: Date | null;
        rejectedById: string | null;
        rejectedAt: Date | null;
        rating: number;
        totalDeliveries: number;
        totalFailed: number;
        isOnline: boolean;
        currentLat: number | null;
        currentLng: number | null;
        lastSeenAt: Date | null;
    }>;
    update(id: string, dto: UpdateCourierDto, user: any): Promise<{
        id: string;
        name: string;
        updatedAt: Date;
        status: import("@prisma/client").$Enums.CourierStatus;
        phone: string;
        email: string | null;
        regionId: string;
        branchId: string;
        vehicleType: import("@prisma/client").$Enums.VehicleType;
        vehiclePlate: string | null;
        nationalIdImageUrl: string | null;
        licenseImageUrl: string | null;
        vehicleImageUrl: string | null;
        selfieUrl: string | null;
    }>;
    approve(id: string, user: any): Promise<{
        id: string;
        status: import("@prisma/client").$Enums.CourierStatus;
        approvedAt: Date | null;
    }>;
    reject(id: string, dto: RejectCourierDto, user: any): Promise<{
        id: string;
        status: import("@prisma/client").$Enums.CourierStatus;
        rejectionReason: string | null;
    }>;
    suspend(id: string, user: any): Promise<{
        message: string;
    }>;
    reactivate(id: string, user: any): Promise<{
        message: string;
    }>;
}
