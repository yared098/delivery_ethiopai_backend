export declare class RejectCourierDto {
    reason: string;
}
