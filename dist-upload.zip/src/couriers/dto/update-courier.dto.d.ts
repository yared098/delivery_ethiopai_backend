import { CreateCourierDto } from './create-courier.dto';
declare const UpdateCourierDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateCourierDto>>;
export declare class UpdateCourierDto extends UpdateCourierDto_base {
}
export {};
