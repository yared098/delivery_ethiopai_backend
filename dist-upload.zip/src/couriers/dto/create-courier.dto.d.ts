import { VehicleType } from '@prisma/client';
export declare class CreateCourierDto {
    phone: string;
    name: string;
    email?: string;
    regionId: string;
    branchId: string;
    vehicleType: VehicleType;
    vehiclePlate?: string;
    vehicleModel?: string;
    vehicleColor?: string;
    vehicleYear?: number;
    licenseNumber?: string;
    maxWeightKg?: number;
    maxVolumeL?: number;
    handlesFragile?: boolean;
    handlesRefrigerated?: boolean;
    nationalIdNumber?: string;
    nationalIdImageUrl?: string;
    licenseImageUrl?: string;
    vehicleImageUrl?: string;
    selfieUrl?: string;
    password?: string;
}
