import { CourierStatus, VehicleType } from '@prisma/client';
export declare class ListCouriersQueryDto {
    status?: CourierStatus;
    vehicleType?: VehicleType;
    regionId?: string;
    branchId?: string;
    search?: string;
    page?: number;
    limit?: number;
}
