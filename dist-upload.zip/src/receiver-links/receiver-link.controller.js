"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReceiverLinkController = void 0;
const common_1 = require("@nestjs/common");
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const argon2 = __importStar(require("argon2"));
const prisma_service_1 = require("../prisma/prisma.service");
const afromessage_service_1 = require("../integrations/afromessage/afromessage.service");
const tracking_gateway_1 = require("../tracking/tracking.gateway");
const public_decorator_1 = require("../common/decorators/public.decorator");
const client_1 = require("@prisma/client");
const pricing_service_1 = require("../orders/pricing.service");
class CompleteDto {
}
__decorate([
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(-90),
    (0, class_validator_1.Max)(90),
    __metadata("design:type", Number)
], CompleteDto.prototype, "lat", void 0);
__decorate([
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(-180),
    (0, class_validator_1.Max)(180),
    __metadata("design:type", Number)
], CompleteDto.prototype, "lng", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], CompleteDto.prototype, "accuracy", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CompleteDto.prototype, "address", void 0);
class VerifyOtpDto {
}
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(6, 6),
    __metadata("design:type", String)
], VerifyOtpDto.prototype, "code", void 0);
let ReceiverLinkController = class ReceiverLinkController {
    constructor(prisma, sms, trackingWs, pricing) {
        this.prisma = prisma;
        this.sms = sms;
        this.trackingWs = trackingWs;
        this.pricing = pricing;
    }
    async getLink(shortCode) {
        const link = await this.prisma.receiverLink.findUnique({
            where: { shortCode },
            include: { order: { include: { items: true } } },
        });
        if (!link)
            throw new common_1.NotFoundException('Link not found');
        if (link.status === 'REVOKED')
            return { mode: 'revoked' };
        if (link.status === 'EXPIRED' || link.expiresAt < new Date()) {
            return { mode: 'expired' };
        }
        if (link.status === 'USED') {
            return {
                mode: 'tracking',
                order: this.publicOrder(link.order),
                link: {
                    shortCode: link.shortCode,
                    status: link.status,
                    expiresAt: link.expiresAt,
                },
            };
        }
        return {
            mode: 'onboarding',
            order: this.publicOrder(link.order),
            link: {
                shortCode: link.shortCode,
                status: link.status,
                expiresAt: link.expiresAt,
            },
        };
    }
    async requestOtp(shortCode) {
        const link = await this.prisma.receiverLink.findUnique({
            where: { shortCode },
        });
        if (!link)
            throw new common_1.NotFoundException('Link not found');
        if (link.status !== 'ACTIVE' || link.expiresAt < new Date()) {
            throw new common_1.GoneException('Link is no longer active');
        }
        const code = Math.floor(100000 + Math.random() * 900000).toString();
        const codeHash = await argon2.hash(code);
        const expiresAt = new Date(Date.now() + 5 * 60 * 1000);
        const normalizedPhone = normalizePhone(link.receiverPhone);
        console.log('[otp/request] shortCode:', shortCode);
        console.log('[otp/request] raw phone:', link.receiverPhone);
        console.log('[otp/request] normalized phone:', normalizedPhone);
        await this.prisma.otpCode.updateMany({
            where: {
                phone: normalizedPhone,
                purpose: 'receiver_link',
                used: false,
            },
            data: { used: true },
        });
        const created = await this.prisma.otpCode.create({
            data: {
                phone: normalizedPhone,
                codeHash,
                purpose: 'receiver_link',
                expiresAt,
                accountType: client_1.AccountType.CUSTOMER,
            },
        });
        console.log('[otp/request] created row id:', created.id);
        await this.sms.sendOtp(normalizedPhone, code);
        return {
            phone: normalizedPhone,
            expiresInSec: 300,
        };
    }
    async verifyOtp(shortCode, body) {
        const link = await this.prisma.receiverLink.findUnique({
            where: { shortCode },
        });
        if (!link)
            throw new common_1.NotFoundException('Link not found');
        const normalizedPhone = normalizePhone(link.receiverPhone);
        console.log('[verify] shortCode:', shortCode);
        console.log('[verify] raw phone:', link.receiverPhone);
        console.log('[verify] normalized phone:', normalizedPhone);
        console.log('[verify] body:', body, 'code type:', typeof body?.code);
        const records = await this.prisma.otpCode.findMany({
            where: {
                phone: normalizedPhone,
                purpose: 'receiver_link',
                used: false,
                expiresAt: { gt: new Date() },
            },
            orderBy: { createdAt: 'desc' },
            take: 5,
        });
        console.log('[verify] found', records.length, 'candidate codes');
        records.forEach((r) => console.log('  → id:', r.id, 'phone:', r.phone, 'attempts:', r.attempts, 'expires:', r.expiresAt));
        if (!records.length) {
            throw new common_1.BadRequestException('Code expired or not found');
        }
        const submitted = String(body?.code ?? '').trim();
        if (!/^\d{6}$/.test(submitted)) {
            throw new common_1.BadRequestException('Code must be 6 digits');
        }
        let matched = null;
        for (const rec of records) {
            if (rec.attempts >= 3)
                continue;
            const ok = await argon2.verify(rec.codeHash, submitted).catch(() => false);
            if (ok) {
                matched = rec;
                break;
            }
        }
        if (!matched) {
            await this.prisma.otpCode.update({
                where: { id: records[0].id },
                data: { attempts: { increment: 1 } },
            });
            throw new common_1.BadRequestException('Invalid code');
        }
        await this.prisma.otpCode.updateMany({
            where: {
                phone: normalizedPhone,
                purpose: 'receiver_link',
                used: false,
            },
            data: { used: true },
        });
        return { verified: true };
    }
    async complete(shortCode, dto) {
        const link = await this.prisma.receiverLink.findUnique({
            where: { shortCode },
        });
        if (!link)
            throw new common_1.NotFoundException('Link not found');
        if (link.status !== 'ACTIVE') {
            throw new common_1.GoneException('Link is no longer active');
        }
        if (dto.lat < 3.4 || dto.lat > 14.9 ||
            dto.lng < 32.9 || dto.lng > 48.0) {
            throw new common_1.BadRequestException('Coordinates outside Ethiopia');
        }
        const updated = await this.prisma.$transaction(async (tx) => {
            const existingOrder = await tx.order.findUnique({
                where: { id: link.orderId },
                select: { senderLat: true, senderLng: true },
            });
            if (!existingOrder)
                throw new common_1.NotFoundException('Order not found');
            const distanceKm = existingOrder.senderLat != null && existingOrder.senderLng != null
                ? this.pricing.distanceKm(existingOrder.senderLat, existingOrder.senderLng, dto.lat, dto.lng)
                : null;
            const order = await tx.order.update({
                where: { id: link.orderId },
                data: {
                    receiverLat: dto.lat,
                    receiverLng: dto.lng,
                    distanceKm,
                    receiverLocationSource: 'link',
                    status: client_1.OrderStatus.PENDING_PAYMENT,
                },
            });
            await tx.receiverLink.update({
                where: { id: link.id },
                data: { status: 'USED', filledAt: new Date() },
            });
            await tx.orderEvent.create({
                data: {
                    orderId: link.orderId,
                    status: client_1.OrderStatus.PENDING_PAYMENT,
                    note: 'Receiver shared location via link',
                    actorType: null,
                    actorId: null,
                    actorName: 'System',
                    isPublic: true,
                },
            });
            return order;
        });
        this.trackingWs.broadcastStatusChange(link.orderId, {
            status: client_1.OrderStatus.PENDING_PAYMENT,
            note: 'Receiver shared location',
            timestamp: new Date().toISOString(),
        });
        return {
            order: this.publicOrder(updated),
            trackingToken: updated.trackingToken,
        };
    }
    publicOrder(order) {
        return {
            id: order.id,
            trackingNumber: order.trackingNumber,
            trackingToken: order.trackingToken,
            status: order.status,
            senderName: maskName(order.senderName),
            receiverName: order.receiverName ? maskName(order.receiverName) : undefined,
            receiverPhone: maskPhone(order.receiverPhone),
            itemCount: order.items?.length ?? 1,
            totalWeightKg: order.totalWeightKg,
            packageDescription: order.packageDescription ?? null,
            createdAt: order.createdAt,
            items: Array.isArray(order.items)
                ? order.items.map((it) => ({
                    id: it.id,
                    description: it.description ?? null,
                    type: it.type ?? null,
                    quantity: it.quantity ?? 1,
                    weightKg: it.weightKg ?? 0,
                    isFragile: !!it.isFragile,
                    isRefrigerated: !!it.isRefrigerated,
                }))
                : [],
        };
    }
};
exports.ReceiverLinkController = ReceiverLinkController;
__decorate([
    (0, common_1.Get)(':shortCode'),
    __param(0, (0, common_1.Param)('shortCode')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ReceiverLinkController.prototype, "getLink", null);
__decorate([
    (0, common_1.Post)(':shortCode/otp/request'),
    __param(0, (0, common_1.Param)('shortCode')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ReceiverLinkController.prototype, "requestOtp", null);
__decorate([
    (0, common_1.Post)(':shortCode/otp/verify'),
    __param(0, (0, common_1.Param)('shortCode')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, VerifyOtpDto]),
    __metadata("design:returntype", Promise)
], ReceiverLinkController.prototype, "verifyOtp", null);
__decorate([
    (0, common_1.Post)(':shortCode/complete'),
    __param(0, (0, common_1.Param)('shortCode')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, CompleteDto]),
    __metadata("design:returntype", Promise)
], ReceiverLinkController.prototype, "complete", null);
exports.ReceiverLinkController = ReceiverLinkController = __decorate([
    (0, public_decorator_1.Public)(),
    (0, common_1.Controller)('r'),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        afromessage_service_1.AfroMessageService,
        tracking_gateway_1.TrackingGateway,
        pricing_service_1.PricingService])
], ReceiverLinkController);
function normalizePhone(raw) {
    const digits = (raw || '').replace(/\D/g, '');
    if (digits.startsWith('251') && digits.length === 12)
        return digits;
    if (digits.startsWith('0') && digits.length === 10)
        return '251' + digits.slice(1);
    if (digits.length === 9)
        return '251' + digits;
    return '251' + digits;
}
function maskName(name) {
    if (!name)
        return '';
    const [first, last] = name.split(' ');
    return last ? `${first} ${last[0]}.` : first;
}
function maskPhone(phone) {
    if (!phone || phone.length < 6)
        return phone;
    return `${phone.slice(0, 4)}****${phone.slice(-3)}`;
}
//# sourceMappingURL=receiver-link.controller.js.map