import { PrismaService } from '../prisma/prisma.service';
import { AfroMessageService } from '../integrations/afromessage/afromessage.service';
import { TrackingGateway } from '../tracking/tracking.gateway';
import { PricingService } from '../orders/pricing.service';
declare class CompleteDto {
    lat: number;
    lng: number;
    accuracy?: number;
    address?: string;
}
declare class VerifyOtpDto {
    code: string;
}
export declare class ReceiverLinkController {
    private prisma;
    private sms;
    private trackingWs;
    private pricing;
    constructor(prisma: PrismaService, sms: AfroMessageService, trackingWs: TrackingGateway, pricing: PricingService);
    getLink(shortCode: string): Promise<{
        mode: string;
        order?: undefined;
        link?: undefined;
    } | {
        mode: string;
        order: {
            id: any;
            trackingNumber: any;
            trackingToken: any;
            status: any;
            senderName: string;
            receiverName: string | undefined;
            receiverPhone: string;
            itemCount: any;
            totalWeightKg: any;
            packageDescription: any;
            createdAt: any;
            items: any;
        };
        link: {
            shortCode: string;
            status: "USED";
            expiresAt: Date;
        };
    } | {
        mode: string;
        order: {
            id: any;
            trackingNumber: any;
            trackingToken: any;
            status: any;
            senderName: string;
            receiverName: string | undefined;
            receiverPhone: string;
            itemCount: any;
            totalWeightKg: any;
            packageDescription: any;
            createdAt: any;
            items: any;
        };
        link: {
            shortCode: string;
            status: "ACTIVE";
            expiresAt: Date;
        };
    }>;
    requestOtp(shortCode: string): Promise<{
        phone: string;
        expiresInSec: number;
    }>;
    verifyOtp(shortCode: string, body: VerifyOtpDto): Promise<{
        verified: boolean;
    }>;
    complete(shortCode: string, dto: CompleteDto): Promise<{
        order: {
            id: any;
            trackingNumber: any;
            trackingToken: any;
            status: any;
            senderName: string;
            receiverName: string | undefined;
            receiverPhone: string;
            itemCount: any;
            totalWeightKg: any;
            packageDescription: any;
            createdAt: any;
            items: any;
        };
        trackingToken: string | null;
    }>;
    private publicOrder;
}
export {};
