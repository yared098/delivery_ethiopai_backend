"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TelegramNotifierService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramNotifierService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const telegram_api_service_1 = require("./telegram-api.service");
const telegram_i18n_1 = require("./i18n/telegram.i18n");
let TelegramNotifierService = TelegramNotifierService_1 = class TelegramNotifierService {
    constructor(api, prisma) {
        this.api = api;
        this.prisma = prisma;
        this.logger = new common_1.Logger(TelegramNotifierService_1.name);
    }
    async notifyCustomerId(customerId, text) {
        if (!customerId)
            return false;
        const customer = await this.prisma.customer.findUnique({
            where: { id: customerId },
            select: { telegramId: true },
        });
        if (!customer?.telegramId)
            return false;
        await this.api.sendMessage(customer.telegramId, text);
        return true;
    }
    async notifyChat(chatId, text) {
        await this.api.sendMessage(chatId, text);
    }
    async notifyOrderStatus(payload) {
        if (!this.api.isConfigured)
            return;
        const text = (0, telegram_i18n_1.t)(telegram_i18n_1.DEFAULT_LANG, 'orderStatusPush', {
            tracking: payload.trackingNumber,
            status: (0, telegram_i18n_1.statusLabel)(telegram_i18n_1.DEFAULT_LANG, payload.status),
        });
        const recipientIds = new Set();
        if (payload.senderId)
            recipientIds.add(payload.senderId);
        if (payload.receiverId)
            recipientIds.add(payload.receiverId);
        if (recipientIds.size === 0)
            return;
        try {
            const customers = await this.prisma.customer.findMany({
                where: {
                    id: { in: Array.from(recipientIds) },
                    telegramId: { not: null },
                },
                select: { telegramId: true },
            });
            await Promise.all(customers.map((customer) => this.api.sendMessage(customer.telegramId, text)));
        }
        catch (err) {
            this.logger.error(`Telegram order status push failed: ${err instanceof Error ? err.message : String(err)}`);
        }
    }
};
exports.TelegramNotifierService = TelegramNotifierService;
exports.TelegramNotifierService = TelegramNotifierService = TelegramNotifierService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [telegram_api_service_1.TelegramApiService,
        prisma_service_1.PrismaService])
], TelegramNotifierService);
//# sourceMappingURL=telegram-notifier.service.js.map