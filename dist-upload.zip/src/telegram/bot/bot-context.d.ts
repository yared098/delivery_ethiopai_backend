import { Lang } from '../i18n/telegram.i18n';
import { ReplyMarkup } from './keyboards';
export interface BotContext {
    chatId: string;
    lang: Lang;
    say(text: string, keyboard?: ReplyMarkup): Promise<void>;
    sendPhoto(photo: Buffer | string, caption?: string, keyboard?: ReplyMarkup): Promise<boolean>;
}
