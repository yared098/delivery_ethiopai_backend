"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramBotModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const prisma_module_1 = require("../../prisma/prisma.module");
const orders_module_1 = require("../../orders/orders.module");
const qr_module_1 = require("../../qr/qr.module");
const telegram_module_1 = require("../telegram.module");
const telegram_webapp_module_1 = require("../webapp/telegram-webapp.module");
const telegram_bot_service_1 = require("./telegram-bot.service");
const telegram_bot_controller_1 = require("./telegram-bot.controller");
const account_handler_1 = require("./handlers/account.handler");
const orders_handler_1 = require("./handlers/orders.handler");
const tracking_handler_1 = require("./handlers/tracking.handler");
let TelegramBotModule = class TelegramBotModule {
};
exports.TelegramBotModule = TelegramBotModule;
exports.TelegramBotModule = TelegramBotModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule,
            prisma_module_1.PrismaModule,
            telegram_module_1.TelegramModule,
            telegram_webapp_module_1.TelegramWebAppModule,
            orders_module_1.OrdersModule,
            qr_module_1.QrModule,
        ],
        controllers: [telegram_bot_controller_1.TelegramBotController],
        providers: [
            telegram_bot_service_1.TelegramBotService,
            account_handler_1.TelegramAccountHandler,
            orders_handler_1.TelegramOrdersHandler,
            tracking_handler_1.TelegramTrackingHandler,
        ],
        exports: [telegram_bot_service_1.TelegramBotService],
    })
], TelegramBotModule);
//# sourceMappingURL=telegram-bot.module.js.map