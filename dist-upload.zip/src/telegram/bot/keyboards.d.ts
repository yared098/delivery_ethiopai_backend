import { Lang } from '../i18n/telegram.i18n';
export type ReplyMarkup = Record<string, unknown>;
interface KeyboardOrder {
    id: string;
    trackingNumber: string;
}
export declare const REMOVE_KEYBOARD: ReplyMarkup;
export declare function mainMenuKeyboard(lang: Lang): ReplyMarkup;
export declare function resolveMenuAction(text: string): string | null;
export declare function languageKeyboard(): ReplyMarkup;
export declare function paymentPartyKeyboard(lang: Lang): ReplyMarkup;
export declare function confirmOrderKeyboard(lang: Lang): ReplyMarkup;
export declare function skipStepKeyboard(lang: Lang): ReplyMarkup;
export declare function shareLocationKeyboard(lang: Lang): ReplyMarkup;
export declare function ordersListKeyboard(orders: KeyboardOrder[], page: number, totalPages: number, lang: Lang): ReplyMarkup;
export declare function orderCardKeyboard(orderId: string, trackingUrl: string | null, lang: Lang): ReplyMarkup;
export declare function backToMenuKeyboard(lang: Lang, orderId?: string): ReplyMarkup;
export declare const ORDERS_PER_PAGE = 5;
export declare function newOrderChoiceKeyboard(lang: Lang, webAppUrl: string): ReplyMarkup;
export {};
