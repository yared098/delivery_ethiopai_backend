"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatMoney = formatMoney;
exports.formatDateTime = formatDateTime;
exports.maskName = maskName;
exports.maskPhone = maskPhone;
exports.formatOrderCard = formatOrderCard;
exports.formatTrackingCard = formatTrackingCard;
exports.formatOrderListLine = formatOrderListLine;
const telegram_i18n_1 = require("../i18n/telegram.i18n");
const phone_util_1 = require("../../common/utils/phone.util");
const TIME_ZONE = 'Africa/Addis_Ababa';
function formatMoney(amount) {
    return `${amount.toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    })} ETB`;
}
function formatDateTime(value) {
    if (!value)
        return '-';
    const date = value instanceof Date ? value : new Date(value);
    if (Number.isNaN(date.getTime()))
        return '-';
    return new Intl.DateTimeFormat('en-GB', {
        dateStyle: 'short',
        timeStyle: 'short',
        timeZone: TIME_ZONE,
    }).format(date);
}
function maskName(name) {
    if (!name)
        return '-';
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1)
        return parts[0];
    return `${parts[0]} ${parts[parts.length - 1].charAt(0)}.`;
}
function maskPhone(phone) {
    if (!phone)
        return '-';
    if (phone.length < 7)
        return phone;
    return `${phone.slice(0, 4)}****${phone.slice(-3)}`;
}
function formatOrderCard(order, lang) {
    const lines = [
        (0, telegram_i18n_1.t)(lang, 'orderDetailsTitle', { tracking: order.trackingNumber }),
        '',
        `${(0, telegram_i18n_1.t)(lang, 'statusLabel')}: ${(0, telegram_i18n_1.statusLabel)(lang, order.status)}`,
        `${(0, telegram_i18n_1.t)(lang, 'senderLabel')}: ${order.senderName} (${(0, phone_util_1.toLocalPhone)(order.senderPhone)})`,
        `${(0, telegram_i18n_1.t)(lang, 'receiverLabel')}: ${order.receiverName ?? '-'} (${(0, phone_util_1.toLocalPhone)(order.receiverPhone)})`,
    ];
    if (order.itemDescription) {
        lines.push(`${(0, telegram_i18n_1.t)(lang, 'itemLabel')}: ${order.itemDescription}`);
    }
    if (order.photoUrl) {
        lines.push(`${(0, telegram_i18n_1.t)(lang, 'photoLabel')}: 📸 ${(0, telegram_i18n_1.t)(lang, 'photoAttached')}`);
    }
    lines.push(`${(0, telegram_i18n_1.t)(lang, 'weightLabel')}: ${order.totalWeightKg} kg`, `${(0, telegram_i18n_1.t)(lang, 'feeLabel')}: ${formatMoney(order.deliveryFee)}`);
    if (order.courierName) {
        const phone = order.courierPhone ? ` (${(0, phone_util_1.toLocalPhone)(order.courierPhone)})` : '';
        lines.push(`${(0, telegram_i18n_1.t)(lang, 'courierLabel')}: ${order.courierName}${phone}`);
    }
    lines.push(`${(0, telegram_i18n_1.t)(lang, 'trackingLabel')}: ${formatDateTime(order.createdAt)}`);
    lines.push('', (0, telegram_i18n_1.t)(lang, 'eventsTitle'));
    if (order.events.length === 0) {
        lines.push((0, telegram_i18n_1.t)(lang, 'noEvents'));
    }
    else {
        for (const event of order.events.slice(0, 5)) {
            const note = event.note ? ` - ${event.note}` : '';
            lines.push(`- ${formatDateTime(event.createdAt)} ${(0, telegram_i18n_1.statusLabel)(lang, event.status)}${note}`);
        }
    }
    return lines.join('\n');
}
function formatTrackingCard(order, lang) {
    const lines = [
        (0, telegram_i18n_1.t)(lang, 'trackTitle', { tracking: order.trackingNumber }),
        '',
        `${(0, telegram_i18n_1.t)(lang, 'statusLabel')}: ${(0, telegram_i18n_1.statusLabel)(lang, order.status)}`,
        `${(0, telegram_i18n_1.t)(lang, 'senderLabel')}: ${maskName(order.senderName)}`,
        `${(0, telegram_i18n_1.t)(lang, 'receiverLabel')}: ${maskName(order.receiverName)}`,
        `${(0, telegram_i18n_1.t)(lang, 'weightLabel')}: ${order.totalWeightKg} kg`,
    ];
    if (order.courierName) {
        lines.push(`${(0, telegram_i18n_1.t)(lang, 'courierLabel')}: ${maskName(order.courierName)} (${maskPhone(order.courierPhone)})`);
    }
    lines.push('', (0, telegram_i18n_1.t)(lang, 'eventsTitle'));
    if (order.events.length === 0) {
        lines.push((0, telegram_i18n_1.t)(lang, 'noEvents'));
    }
    else {
        for (const event of order.events.slice(0, 5)) {
            const note = event.note ? ` - ${event.note}` : '';
            lines.push(`- ${formatDateTime(event.createdAt)} ${(0, telegram_i18n_1.statusLabel)(lang, event.status)}${note}`);
        }
    }
    return lines.join('\n');
}
function formatOrderListLine(order, lang) {
    return `${order.trackingNumber}  ${(0, telegram_i18n_1.statusLabel)(lang, order.status)}  ${formatDateTime(order.createdAt)}`;
}
//# sourceMappingURL=format.js.map