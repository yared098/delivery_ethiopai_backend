import { TelegramUpdate } from '../telegram-api.service';
import { TelegramBotService } from './telegram-bot.service';
export declare class TelegramBotController {
    private readonly bot;
    constructor(bot: TelegramBotService);
    webhook(update: TelegramUpdate): Promise<{
        ok: true;
    }>;
}
