"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TelegramOrdersHandler_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramOrdersHandler = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../../prisma/prisma.service");
const orders_service_1 = require("../../../orders/orders.service");
const pricing_service_1 = require("../../../orders/pricing.service");
const qr_service_1 = require("../../../qr/qr.service");
const telegram_api_service_1 = require("../../telegram-api.service");
const telegram_webapp_service_1 = require("../../webapp/telegram-webapp.service");
const telegram_session_service_1 = require("../../telegram-session.service");
const telegram_i18n_1 = require("../../i18n/telegram.i18n");
const phone_util_1 = require("../../../common/utils/phone.util");
const image_util_1 = require("../../../common/utils/image.util");
const path_1 = require("path");
const fs_1 = require("fs");
const crypto_1 = require("crypto");
const account_handler_1 = require("./account.handler");
const keyboards_1 = require("../keyboards");
const format_1 = require("../format");
const MIN_ITEM_LENGTH = 2;
const MIN_WEIGHT_KG = 0.01;
const MAX_WEIGHT_KG = 5_000;
let TelegramOrdersHandler = TelegramOrdersHandler_1 = class TelegramOrdersHandler {
    constructor(prisma, orders, pricing, sessions, account, qrService, telegramApi, webApp) {
        this.prisma = prisma;
        this.orders = orders;
        this.pricing = pricing;
        this.sessions = sessions;
        this.account = account;
        this.qrService = qrService;
        this.telegramApi = telegramApi;
        this.webApp = webApp;
        this.logger = new common_1.Logger(TelegramOrdersHandler_1.name);
    }
    async startNewOrder(ctx) {
        const customer = await this.account.requireCustomer(ctx);
        if (!customer)
            return;
        const orderFormUrl = `${this.webApp.webAppUrl}/api/v1/telegram/webapp/order-form`;
        await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'createOrderChoose'), (0, keyboards_1.newOrderChoiceKeyboard)(ctx.lang, orderFormUrl));
    }
    async startOrderWizard(ctx) {
        this.sessions.setStep(ctx.chatId, 'order:receiver_name', {
            receiverName: undefined,
            receiverPhone: undefined,
            itemDescription: undefined,
            photoUrl: undefined,
            weightKg: undefined,
            paymentParty: 'SENDER',
            senderLat: undefined,
            senderLng: undefined,
            senderAddress: undefined,
        });
        await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderAskReceiverName'), keyboards_1.REMOVE_KEYBOARD);
    }
    async handleStep(ctx, text, message) {
        const session = this.sessions.get(ctx.chatId);
        switch (session.step) {
            case 'order:receiver_name': {
                if (text.trim().length < MIN_ITEM_LENGTH) {
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'invalidName'));
                    return true;
                }
                this.sessions.setStep(ctx.chatId, 'order:receiver_phone', {
                    receiverName: text.trim(),
                });
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderAskReceiverPhone'));
                return true;
            }
            case 'order:receiver_phone': {
                const phone = (0, phone_util_1.normalizeEthiopianPhone)(text);
                if (!phone) {
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'invalidPhone'));
                    return true;
                }
                this.sessions.setStep(ctx.chatId, 'order:item', { receiverPhone: phone });
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderAskItem'));
                return true;
            }
            case 'order:item': {
                if (text.trim().length < MIN_ITEM_LENGTH) {
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'invalidItem'));
                    return true;
                }
                this.sessions.setStep(ctx.chatId, 'order:photo', {
                    itemDescription: text.trim(),
                });
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderAskPhoto'), (0, keyboards_1.skipStepKeyboard)(ctx.lang));
                return true;
            }
            case 'order:photo': {
                const trimmed = text.trim();
                const isSkip = trimmed.toLowerCase() === 'skip' ||
                    (0, keyboards_1.resolveMenuAction)(trimmed) === 'btn.skip';
                if (isSkip) {
                    this.sessions.setStep(ctx.chatId, 'order:weight');
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderAskWeight'), keyboards_1.REMOVE_KEYBOARD);
                    return true;
                }
                const photo = message?.photo && message.photo.length > 0
                    ? message.photo[message.photo.length - 1]
                    : null;
                const isImageDoc = message?.document?.mime_type?.startsWith('image/') ||
                    /\.(jpe?g|png|webp|heic)$/i.test(message?.document?.file_name ?? '');
                const fileId = photo?.file_id ?? (isImageDoc ? message?.document?.file_id : null);
                if (!fileId) {
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderAskPhotoInvalid'), (0, keyboards_1.skipStepKeyboard)(ctx.lang));
                    return true;
                }
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderPhotoUploading'));
                const fileInfo = await this.telegramApi.getFile(fileId);
                if (!fileInfo?.file_path) {
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderPhotoUploadFailed'), (0, keyboards_1.skipStepKeyboard)(ctx.lang));
                    return true;
                }
                const rawBuffer = await this.telegramApi.downloadFile(fileInfo.file_path);
                if (!rawBuffer) {
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderPhotoUploadFailed'), (0, keyboards_1.skipStepKeyboard)(ctx.lang));
                    return true;
                }
                try {
                    const compressed = await (0, image_util_1.compressImage)(rawBuffer, 2 * 1024 * 1024);
                    const uploadDir = (0, path_1.join)(process.cwd(), 'uploads', 'orders');
                    (0, fs_1.mkdirSync)(uploadDir, { recursive: true });
                    const filename = `${(0, crypto_1.randomUUID)()}.jpg`;
                    const filePath = (0, path_1.join)(uploadDir, filename);
                    (0, fs_1.writeFileSync)(filePath, compressed);
                    const photoUrl = `/uploads/orders/${filename}`;
                    this.sessions.setStep(ctx.chatId, 'order:weight', { photoUrl });
                    const sizeKb = Math.round(compressed.length / 1024);
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderPhotoUploaded', { size: `${sizeKb} KB` }), keyboards_1.REMOVE_KEYBOARD);
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderAskWeight'));
                    return true;
                }
                catch (err) {
                    this.logger.error(`Photo compression or upload failed: ${err instanceof Error ? err.message : String(err)}`);
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderPhotoUploadFailed'), (0, keyboards_1.skipStepKeyboard)(ctx.lang));
                    return true;
                }
            }
            case 'order:weight': {
                const weight = Number.parseFloat(text.replace(',', '.'));
                if (!Number.isFinite(weight) ||
                    weight < MIN_WEIGHT_KG ||
                    weight > MAX_WEIGHT_KG) {
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'invalidWeight'));
                    return true;
                }
                this.sessions.setStep(ctx.chatId, 'order:sender_location', { weightKg: weight });
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderAskSenderLocation'), (0, keyboards_1.shareLocationKeyboard)(ctx.lang));
                return true;
            }
            case 'order:sender_location': {
                if (message?.location) {
                    const { latitude, longitude } = message.location;
                    this.sessions.setStep(ctx.chatId, 'order:payment', {
                        senderLat: latitude,
                        senderLng: longitude,
                    });
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderSenderLocationReceived'), keyboards_1.REMOVE_KEYBOARD);
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderAskPaymentParty'), (0, keyboards_1.paymentPartyKeyboard)(ctx.lang));
                    return true;
                }
                const trimmed = text.trim();
                const action = (0, keyboards_1.resolveMenuAction)(trimmed);
                const isSkip = trimmed.toLowerCase() === 'skip' || action === 'btn.skip';
                const isCancel = trimmed.toLowerCase() === 'cancel' || action === 'btn.cancel';
                if (isCancel) {
                    this.sessions.reset(ctx.chatId);
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'cancelled'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
                    return true;
                }
                if (isSkip) {
                    this.sessions.setStep(ctx.chatId, 'order:payment');
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderSenderLocationSkipped'), keyboards_1.REMOVE_KEYBOARD);
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderAskPaymentParty'), (0, keyboards_1.paymentPartyKeyboard)(ctx.lang));
                    return true;
                }
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderAskSenderLocation'), (0, keyboards_1.shareLocationKeyboard)(ctx.lang));
                return true;
            }
            default:
                return false;
        }
    }
    async setPaymentParty(ctx, party) {
        this.sessions.patchData(ctx.chatId, { paymentParty: party });
        this.sessions.setStep(ctx.chatId, 'order:confirm');
        const data = this.sessions.get(ctx.chatId).data;
        const estimate = this.pricing.calculate({
            distanceKm: 0,
            totalWeightKg: data.weightKg ?? 0,
            items: [{ type: 'OTHER', quantity: 1 }],
        }).total;
        const lines = [
            (0, telegram_i18n_1.t)(ctx.lang, 'orderConfirmTitle'),
            '',
            `${(0, telegram_i18n_1.t)(ctx.lang, 'receiverLabel')}: ${data.receiverName ?? '-'}`,
            `${(0, telegram_i18n_1.t)(ctx.lang, 'phoneLabel')}: ${data.receiverPhone ? (0, phone_util_1.toLocalPhone)(data.receiverPhone) : '-'}`,
            `${(0, telegram_i18n_1.t)(ctx.lang, 'itemLabel')}: ${data.itemDescription ?? '-'}`,
            `${(0, telegram_i18n_1.t)(ctx.lang, 'photoLabel')}: ${data.photoUrl ? '📸 ' + (0, telegram_i18n_1.t)(ctx.lang, 'photoAttached') : '-'}`,
            `${(0, telegram_i18n_1.t)(ctx.lang, 'weightLabel')}: ${data.weightKg ?? 0} kg`,
            `📍 ${(0, telegram_i18n_1.t)(ctx.lang, 'addressLabel')}: ${data.senderLat != null && data.senderLng != null
                ? `${data.senderLat.toFixed(5)}, ${data.senderLng.toFixed(5)}`
                : data.senderAddress ?? (0, telegram_i18n_1.t)(ctx.lang, 'notSet')}`,
            `${(0, telegram_i18n_1.t)(ctx.lang, 'feeLabel')}: ${(0, telegram_i18n_1.t)(ctx.lang, 'estimateFrom', { fee: (0, format_1.formatMoney)(estimate) })}`,
            '',
            (0, telegram_i18n_1.t)(ctx.lang, 'orderConfirmHint'),
        ];
        await ctx.say(lines.join('\n'), (0, keyboards_1.confirmOrderKeyboard)(ctx.lang));
    }
    async confirmOrder(ctx) {
        const customer = await this.account.requireCustomer(ctx);
        if (!customer)
            return;
        const session = this.sessions.get(ctx.chatId);
        const data = session.data;
        if (!data.receiverName ||
            !data.receiverPhone ||
            !data.itemDescription ||
            !data.weightKg) {
            this.sessions.reset(ctx.chatId);
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'unknownCommand'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
            return;
        }
        this.sessions.reset(ctx.chatId);
        const dto = this.buildOrderDto(customer, data);
        try {
            const result = await this.orders.create(dto, {
                id: customer.id,
                name: customer.name ?? 'Customer',
                accountType: client_1.AccountType.CUSTOMER,
                role: 'CUSTOMER',
            });
            const order = result.order;
            if (!order) {
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderCreateFailed', { reason: 'order not persisted' }));
                return;
            }
            const successText = (0, telegram_i18n_1.t)(ctx.lang, 'orderCreated', {
                tracking: order.trackingNumber,
                fee: (0, format_1.formatMoney)(order.deliveryFee),
            });
            const qrResult = await this.qrService.getOrderQrBuffer(order.id).catch(() => null);
            if (qrResult?.buffer) {
                const prompt = `📱 ${(0, telegram_i18n_1.t)(ctx.lang, 'orderQrPrompt', { tracking: order.trackingNumber })}`;
                const sent = await ctx.sendPhoto(qrResult.buffer, `${successText}\n\n${prompt}`, (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
                if (sent)
                    return;
            }
            await ctx.say(successText, (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
        }
        catch (err) {
            this.logger.error(`Telegram order creation failed for customer ${customer.id}: ${err instanceof Error ? err.message : String(err)}`);
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'orderCreateFailed', {
                reason: err instanceof Error ? err.message : 'unknown error',
            }), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
        }
    }
    buildOrderDto(customer, data) {
        return {
            sender: {
                customerId: customer.id,
                name: customer.name ?? 'Customer',
                phone: customer.phone,
                address: data.senderAddress ?? customer.defaultAddress ?? undefined,
                lat: data.senderLat ?? customer.defaultLat ?? undefined,
                lng: data.senderLng ?? customer.defaultLng ?? undefined,
            },
            receiver: {
                name: data.receiverName,
                phone: data.receiverPhone,
            },
            items: [
                {
                    description: data.itemDescription,
                    weightKg: data.weightKg,
                    quantity: 1,
                    photoUrl: data.photoUrl,
                },
            ],
            paymentParty: data.paymentParty === 'RECEIVER' ? client_1.PaymentParty.RECEIVER : client_1.PaymentParty.SENDER,
            sendReceiverLink: true,
            autoAssignCourier: false,
        };
    }
    async listOrders(ctx, page = 1) {
        const customer = await this.account.requireCustomer(ctx);
        if (!customer)
            return;
        const safePage = Number.isFinite(page) && page > 0 ? Math.floor(page) : 1;
        const where = {
            OR: [{ senderId: customer.id }, { receiverId: customer.id }],
        };
        const [orders, total] = await Promise.all([
            this.prisma.order.findMany({
                where,
                orderBy: { createdAt: 'desc' },
                skip: (safePage - 1) * keyboards_1.ORDERS_PER_PAGE,
                take: keyboards_1.ORDERS_PER_PAGE,
                select: {
                    id: true,
                    trackingNumber: true,
                    status: true,
                    createdAt: true,
                },
            }),
            this.prisma.order.count({ where }),
        ]);
        if (total === 0) {
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'noOrders'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
            return;
        }
        const totalPages = Math.max(1, Math.ceil(total / keyboards_1.ORDERS_PER_PAGE));
        const header = [
            (0, telegram_i18n_1.t)(ctx.lang, 'ordersTitle'),
            (0, telegram_i18n_1.t)(ctx.lang, 'ordersPageOf', { page: safePage, pages: totalPages }),
            '',
        ];
        const body = orders.map((order) => (0, format_1.formatOrderListLine)(order, ctx.lang)).join('\n');
        await ctx.say(`${header.join('\n')}\n${body}`, (0, keyboards_1.ordersListKeyboard)(orders, safePage, totalPages, ctx.lang));
    }
    async showOrder(ctx, orderId) {
        const customer = await this.account.requireCustomer(ctx);
        if (!customer)
            return;
        const order = await this.prisma.order.findFirst({
            where: {
                id: orderId,
                OR: [{ senderId: customer.id }, { receiverId: customer.id }],
            },
            include: {
                items: true,
                courier: { select: { name: true, phone: true } },
                events: { orderBy: { createdAt: 'desc' }, take: 5 },
            },
        });
        if (!order) {
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'noOrders'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
            return;
        }
        const view = {
            id: order.id,
            trackingNumber: order.trackingNumber,
            status: order.status,
            senderName: order.senderName,
            senderPhone: order.senderPhone,
            receiverName: order.receiverName,
            receiverPhone: order.receiverPhone,
            itemDescription: order.items[0]?.description ?? null,
            photoUrl: order.items[0]?.photoUrl ?? null,
            deliveryFee: order.deliveryFee,
            totalWeightKg: order.totalWeightKg,
            trackingUrl: order.trackingUrl,
            courierName: order.courier?.name ?? null,
            courierPhone: order.courier?.phone ?? null,
            createdAt: order.createdAt,
            events: order.events.map((event) => ({
                status: event.status,
                note: event.note,
                createdAt: event.createdAt,
            })),
        };
        const cardText = (0, format_1.formatOrderCard)(view, ctx.lang);
        const keyboard = (0, keyboards_1.orderCardKeyboard)(order.id, order.trackingUrl, ctx.lang);
        const qrResult = await this.qrService.getOrderQrBuffer(order.id).catch(() => null);
        if (qrResult?.buffer) {
            const prompt = `📱 ${(0, telegram_i18n_1.t)(ctx.lang, 'orderQrPrompt', { tracking: order.trackingNumber })}`;
            const caption = `${cardText}\n\n${prompt}`;
            const sent = await ctx.sendPhoto(qrResult.buffer, caption, keyboard);
            if (sent)
                return;
        }
        await ctx.say(cardText, keyboard);
    }
    async showOrderQr(ctx, orderIdOrRef) {
        const customer = await this.account.requireCustomer(ctx);
        if (!customer)
            return;
        const ref = orderIdOrRef.trim();
        const order = await this.prisma.order.findFirst({
            where: {
                OR: [{ id: ref }, { trackingNumber: ref }],
                AND: [
                    { OR: [{ senderId: customer.id }, { receiverId: customer.id }] },
                ],
            },
            select: {
                id: true,
                trackingNumber: true,
                status: true,
                receiverName: true,
                receiverPhone: true,
                totalWeightKg: true,
                trackingUrl: true,
            },
        });
        if (!order) {
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'qrCodeNotFound'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
            return;
        }
        try {
            const { buffer } = await this.qrService.getOrderQrBuffer(order.id);
            const lines = [
                `📱 ${(0, telegram_i18n_1.t)(ctx.lang, 'orderQrPrompt', { tracking: order.trackingNumber })}`,
                '',
                `${(0, telegram_i18n_1.t)(ctx.lang, 'statusLabel')}: ${(0, telegram_i18n_1.statusLabel)(ctx.lang, order.status)}`,
                `${(0, telegram_i18n_1.t)(ctx.lang, 'receiverLabel')}: ${order.receiverName ?? '-'} (${order.receiverPhone})`,
                `${(0, telegram_i18n_1.t)(ctx.lang, 'weightLabel')}: ${order.totalWeightKg} kg`,
            ];
            const keyboard = (0, keyboards_1.orderCardKeyboard)(order.id, order.trackingUrl, ctx.lang);
            const sent = await ctx.sendPhoto(buffer, lines.join('\n'), keyboard);
            if (!sent) {
                await ctx.say(lines.join('\n'), keyboard);
            }
        }
        catch (err) {
            this.logger.error(`Failed to generate QR for order ${order.id}: ${err instanceof Error ? err.message : String(err)}`);
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'qrCodeNotFound'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
        }
    }
    async showLatestOrderQr(ctx) {
        const customer = await this.account.requireCustomer(ctx);
        if (!customer)
            return;
        const order = await this.prisma.order.findFirst({
            where: {
                OR: [{ senderId: customer.id }, { receiverId: customer.id }],
            },
            orderBy: { createdAt: 'desc' },
            select: { id: true },
        });
        if (!order) {
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'noOrders'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
            return;
        }
        await this.showOrderQr(ctx, order.id);
    }
};
exports.TelegramOrdersHandler = TelegramOrdersHandler;
exports.TelegramOrdersHandler = TelegramOrdersHandler = TelegramOrdersHandler_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        orders_service_1.OrdersService,
        pricing_service_1.PricingService,
        telegram_session_service_1.TelegramSessionService,
        account_handler_1.TelegramAccountHandler,
        qr_service_1.QrService,
        telegram_api_service_1.TelegramApiService,
        telegram_webapp_service_1.TelegramWebAppService])
], TelegramOrdersHandler);
//# sourceMappingURL=orders.handler.js.map