import { PrismaService } from '../../../prisma/prisma.service';
import { BotContext } from '../bot-context';
import { TelegramAccountHandler } from './account.handler';
import { OrderCardView } from '../format';
export declare class TelegramTrackingHandler {
    private readonly prisma;
    private readonly account;
    constructor(prisma: PrismaService, account: TelegramAccountHandler);
    promptForNumber(ctx: BotContext): Promise<void>;
    track(ctx: BotContext, reference: string): Promise<void>;
}
type OrderWithRelations = {
    id: string;
    trackingNumber: string;
    status: OrderCardView['status'];
    senderName: string;
    senderPhone: string;
    receiverName: string | null;
    receiverPhone: string;
    deliveryFee: number;
    totalWeightKg: number;
    trackingUrl: string | null;
    createdAt: Date;
    courier: {
        name: string;
        phone: string | null;
    } | null;
    events: Array<{
        status: OrderCardView['status'];
        note: string | null;
        createdAt: Date;
    }>;
};
export declare function toCardView(order: OrderWithRelations): OrderCardView;
export {};
