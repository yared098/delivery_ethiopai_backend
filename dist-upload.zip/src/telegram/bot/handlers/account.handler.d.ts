import { Customer } from '@prisma/client';
import { PrismaService } from '../../../prisma/prisma.service';
import { TelegramSessionService } from '../../telegram-session.service';
import { BotContext } from '../bot-context';
export declare class TelegramAccountHandler {
    private readonly prisma;
    private readonly sessions;
    constructor(prisma: PrismaService, sessions: TelegramSessionService);
    findCustomer(chatId: string): Promise<Customer | null>;
    requireCustomer(ctx: BotContext): Promise<Customer | null>;
    showProfile(ctx: BotContext): Promise<void>;
    beginRegister(ctx: BotContext): Promise<void>;
    unlink(ctx: BotContext): Promise<void>;
    link(ctx: BotContext, rawPhone: string): Promise<void>;
    handleStep(ctx: BotContext, text: string): Promise<boolean>;
    private completeRegistration;
    private attachTelegram;
}
