"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramAccountHandler = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("@prisma/client");
const prisma_service_1 = require("../../../prisma/prisma.service");
const telegram_session_service_1 = require("../../telegram-session.service");
const telegram_i18n_1 = require("../../i18n/telegram.i18n");
const phone_util_1 = require("../../../common/utils/phone.util");
const keyboards_1 = require("../keyboards");
let TelegramAccountHandler = class TelegramAccountHandler {
    constructor(prisma, sessions) {
        this.prisma = prisma;
        this.sessions = sessions;
    }
    async findCustomer(chatId) {
        return this.prisma.customer.findUnique({ where: { telegramId: chatId } });
    }
    async requireCustomer(ctx) {
        const customer = await this.findCustomer(ctx.chatId);
        if (!customer) {
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'notRegistered'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
            return null;
        }
        return customer;
    }
    async showProfile(ctx) {
        const customer = await this.requireCustomer(ctx);
        if (!customer)
            return;
        const lines = [
            (0, telegram_i18n_1.t)(ctx.lang, 'profileTitle'),
            '',
            `${(0, telegram_i18n_1.t)(ctx.lang, 'nameLabel')}: ${customer.name ?? (0, telegram_i18n_1.t)(ctx.lang, 'notSet')}`,
            `${(0, telegram_i18n_1.t)(ctx.lang, 'phoneLabel')}: ${customer.phone}`,
            `${(0, telegram_i18n_1.t)(ctx.lang, 'addressLabel')}: ${customer.defaultAddress ?? (0, telegram_i18n_1.t)(ctx.lang, 'notSet')}`,
        ];
        await ctx.say(lines.join('\n'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
    }
    async beginRegister(ctx) {
        this.sessions.setStep(ctx.chatId, 'register:name', {
            name: undefined,
            phone: undefined,
            address: undefined,
        });
        await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'askName'), keyboards_1.REMOVE_KEYBOARD);
    }
    async unlink(ctx) {
        const customer = await this.findCustomer(ctx.chatId);
        if (!customer) {
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'noLinkedAccount'));
            return;
        }
        await this.prisma.customer.update({
            where: { id: customer.id },
            data: { telegramId: null },
        });
        await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'accountUnlinked'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
    }
    async link(ctx, rawPhone) {
        const phone = (0, phone_util_1.normalizeEthiopianPhone)(rawPhone);
        if (!phone) {
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'invalidPhone'));
            return;
        }
        const customer = await this.prisma.customer.findUnique({ where: { phone } });
        if (!customer) {
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'accountLinkFailed'));
            return;
        }
        if (customer.telegramId && customer.telegramId !== ctx.chatId) {
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'accountInUse'));
            return;
        }
        await this.attachTelegram(customer.id, ctx.chatId);
        await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'accountLinked', { name: customer.name ?? phone }), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
    }
    async handleStep(ctx, text) {
        const session = this.sessions.get(ctx.chatId);
        if (session.step === 'register:name') {
            if (text.trim().length < 2) {
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'invalidName'));
                return true;
            }
            this.sessions.setStep(ctx.chatId, 'register:phone', { name: text.trim() });
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'askPhone'));
            return true;
        }
        if (session.step === 'register:phone') {
            const phone = (0, phone_util_1.normalizeEthiopianPhone)(text);
            if (!phone) {
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'invalidPhone'));
                return true;
            }
            this.sessions.setStep(ctx.chatId, 'register:address', { phone });
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'askAddress'));
            return true;
        }
        if (session.step === 'register:address') {
            const trimmed = text.trim();
            const address = trimmed.toLowerCase() === 'skip' ? null : trimmed;
            await this.completeRegistration(ctx, address || null);
            return true;
        }
        return false;
    }
    async completeRegistration(ctx, address) {
        const { name, phone } = this.sessions.get(ctx.chatId).data;
        this.sessions.reset(ctx.chatId);
        if (!name || !phone) {
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'registrationFailed', { reason: 'missing data' }));
            return;
        }
        try {
            const existing = await this.prisma.customer.findUnique({ where: { phone } });
            if (existing) {
                if (existing.telegramId && existing.telegramId !== ctx.chatId) {
                    await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'accountInUse'));
                    return;
                }
                await this.attachTelegram(existing.id, ctx.chatId);
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'accountLinked', { name: existing.name ?? name }), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
                return;
            }
            const created = await this.prisma.customer.create({
                data: { name, phone, defaultAddress: address, telegramId: ctx.chatId },
            });
            await ctx.say(`${(0, telegram_i18n_1.t)(ctx.lang, 'registrationDone')}\n\n${(0, telegram_i18n_1.t)(ctx.lang, 'registeredAs', {
                name: created.name ?? name,
            })}`, (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
        }
        catch (err) {
            const reason = err instanceof client_1.Prisma.PrismaClientKnownRequestError && err.code === 'P2002'
                ? 'phone or Telegram already registered'
                : err instanceof Error
                    ? err.message
                    : String(err);
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'registrationFailed', { reason }));
        }
    }
    async attachTelegram(customerId, chatId) {
        await this.prisma.customer.updateMany({
            where: { telegramId: chatId, NOT: { id: customerId } },
            data: { telegramId: null },
        });
        await this.prisma.customer.update({
            where: { id: customerId },
            data: { telegramId: chatId },
        });
    }
};
exports.TelegramAccountHandler = TelegramAccountHandler;
exports.TelegramAccountHandler = TelegramAccountHandler = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        telegram_session_service_1.TelegramSessionService])
], TelegramAccountHandler);
//# sourceMappingURL=account.handler.js.map