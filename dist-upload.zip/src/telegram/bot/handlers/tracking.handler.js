"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramTrackingHandler = void 0;
exports.toCardView = toCardView;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../../prisma/prisma.service");
const telegram_i18n_1 = require("../../i18n/telegram.i18n");
const account_handler_1 = require("./account.handler");
const format_1 = require("../format");
const keyboards_1 = require("../keyboards");
let TelegramTrackingHandler = class TelegramTrackingHandler {
    constructor(prisma, account) {
        this.prisma = prisma;
        this.account = account;
    }
    async promptForNumber(ctx) {
        await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'trackAsk'));
    }
    async track(ctx, reference) {
        const reference_ = reference.trim();
        if (!reference_) {
            await this.promptForNumber(ctx);
            return;
        }
        const customer = await this.account.findCustomer(ctx.chatId);
        const order = await this.prisma.order.findFirst({
            where: {
                OR: [{ trackingNumber: reference_ }, { trackingToken: reference_ }],
            },
            include: {
                courier: { select: { name: true, phone: true } },
                events: {
                    where: { isPublic: true },
                    orderBy: { createdAt: 'desc' },
                    take: 5,
                },
            },
        });
        if (!order) {
            await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'trackNotFound', { number: reference_ }), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
            return;
        }
        const view = toCardView(order);
        const isOwner = !!customer &&
            (order.senderId === customer.id || order.receiverId === customer.id);
        await ctx.say(isOwner ? (0, format_1.formatOrderCard)(view, ctx.lang) : (0, format_1.formatTrackingCard)(view, ctx.lang), (0, keyboards_1.backToMenuKeyboard)(ctx.lang, isOwner ? order.id : undefined));
    }
};
exports.TelegramTrackingHandler = TelegramTrackingHandler;
exports.TelegramTrackingHandler = TelegramTrackingHandler = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        account_handler_1.TelegramAccountHandler])
], TelegramTrackingHandler);
function toCardView(order) {
    return {
        id: order.id,
        trackingNumber: order.trackingNumber,
        status: order.status,
        senderName: order.senderName,
        senderPhone: order.senderPhone,
        receiverName: order.receiverName,
        receiverPhone: order.receiverPhone,
        deliveryFee: order.deliveryFee,
        totalWeightKg: order.totalWeightKg,
        trackingUrl: order.trackingUrl,
        courierName: order.courier?.name ?? null,
        courierPhone: order.courier?.phone ?? null,
        createdAt: order.createdAt,
        events: order.events.map((event) => ({
            status: event.status,
            note: event.note,
            createdAt: event.createdAt,
        })),
    };
}
//# sourceMappingURL=tracking.handler.js.map