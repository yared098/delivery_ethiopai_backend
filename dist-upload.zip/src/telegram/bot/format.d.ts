import { OrderStatus } from '@prisma/client';
import { Lang } from '../i18n/telegram.i18n';
export interface OrderEventView {
    status: OrderStatus;
    note: string | null;
    createdAt: Date;
}
export interface OrderCardView {
    id: string;
    trackingNumber: string;
    status: OrderStatus;
    senderName: string;
    senderPhone: string;
    receiverName: string | null;
    receiverPhone: string;
    itemDescription?: string | null;
    photoUrl?: string | null;
    deliveryFee: number;
    totalWeightKg: number;
    trackingUrl: string | null;
    courierName: string | null;
    courierPhone: string | null;
    createdAt: Date;
    events: OrderEventView[];
}
export declare function formatMoney(amount: number): string;
export declare function formatDateTime(value: Date | string | null | undefined): string;
export declare function maskName(name: string | null | undefined): string;
export declare function maskPhone(phone: string | null | undefined): string;
export declare function formatOrderCard(order: OrderCardView, lang: Lang): string;
export declare function formatTrackingCard(order: OrderCardView, lang: Lang): string;
export declare function formatOrderListLine(order: {
    trackingNumber: string;
    status: OrderStatus;
    createdAt: Date;
}, lang: Lang): string;
