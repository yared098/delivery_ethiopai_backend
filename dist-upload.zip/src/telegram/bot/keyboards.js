"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ORDERS_PER_PAGE = exports.REMOVE_KEYBOARD = void 0;
exports.mainMenuKeyboard = mainMenuKeyboard;
exports.resolveMenuAction = resolveMenuAction;
exports.languageKeyboard = languageKeyboard;
exports.paymentPartyKeyboard = paymentPartyKeyboard;
exports.confirmOrderKeyboard = confirmOrderKeyboard;
exports.skipStepKeyboard = skipStepKeyboard;
exports.shareLocationKeyboard = shareLocationKeyboard;
exports.ordersListKeyboard = ordersListKeyboard;
exports.orderCardKeyboard = orderCardKeyboard;
exports.backToMenuKeyboard = backToMenuKeyboard;
exports.newOrderChoiceKeyboard = newOrderChoiceKeyboard;
const telegram_constants_1 = require("../telegram.constants");
const telegram_i18n_1 = require("../i18n/telegram.i18n");
exports.REMOVE_KEYBOARD = { remove_keyboard: true };
function mainMenuKeyboard(lang) {
    return {
        keyboard: [
            [
                { text: (0, telegram_i18n_1.t)(lang, 'btn.newOrder') },
                { text: (0, telegram_i18n_1.t)(lang, 'btn.orders') },
                { text: (0, telegram_i18n_1.t)(lang, 'btn.track') },
            ],
            [
                { text: (0, telegram_i18n_1.t)(lang, 'btn.account') },
                { text: (0, telegram_i18n_1.t)(lang, 'btn.language') },
                { text: (0, telegram_i18n_1.t)(lang, 'btn.help') },
            ],
        ],
        resize_keyboard: true,
        is_persistent: false,
        input_field_placeholder: (0, telegram_i18n_1.t)(lang, 'menuPlaceholder'),
    };
}
function resolveMenuAction(text) {
    const normalised = text.trim().toLowerCase();
    const keys = [
        'btn.newOrder',
        'btn.orders',
        'btn.track',
        'btn.account',
        'btn.language',
        'btn.help',
        'btn.skip',
        'btn.register',
    ];
    for (const key of keys) {
        for (const { code } of telegram_i18n_1.LANGUAGES) {
            if ((0, telegram_i18n_1.t)(code, key).toLowerCase() === normalised)
                return key;
        }
    }
    return null;
}
function languageKeyboard() {
    return {
        inline_keyboard: [
            telegram_i18n_1.LANGUAGES.map((language) => ({
                text: language.label,
                callback_data: `${telegram_constants_1.CALLBACK_DATA.language}:${language.code}`,
            })),
        ],
    };
}
function paymentPartyKeyboard(lang) {
    return {
        inline_keyboard: [
            [
                { text: (0, telegram_i18n_1.t)(lang, 'paySender'), callback_data: `${telegram_constants_1.CALLBACK_DATA.payParty}:SENDER` },
                { text: (0, telegram_i18n_1.t)(lang, 'payReceiver'), callback_data: `${telegram_constants_1.CALLBACK_DATA.payParty}:RECEIVER` },
            ],
            [{ text: (0, telegram_i18n_1.t)(lang, 'btn.cancel'), callback_data: telegram_constants_1.CALLBACK_DATA.cancelFlow }],
        ],
    };
}
function confirmOrderKeyboard(lang) {
    return {
        inline_keyboard: [
            [
                {
                    text: (0, telegram_i18n_1.t)(lang, 'btn.confirm'),
                    callback_data: `${telegram_constants_1.CALLBACK_DATA.confirmOrder}:yes`,
                },
            ],
            [{ text: (0, telegram_i18n_1.t)(lang, 'btn.cancel'), callback_data: telegram_constants_1.CALLBACK_DATA.cancelFlow }],
        ],
    };
}
function skipStepKeyboard(lang) {
    return {
        keyboard: [
            [{ text: (0, telegram_i18n_1.t)(lang, 'btn.skip') }, { text: (0, telegram_i18n_1.t)(lang, 'btn.cancel') }],
        ],
        resize_keyboard: true,
        one_time_keyboard: true,
        is_persistent: false,
    };
}
function shareLocationKeyboard(lang) {
    return {
        keyboard: [
            [
                {
                    text: (0, telegram_i18n_1.t)(lang, 'btn.shareLocation'),
                    request_location: true,
                },
            ],
            [{ text: (0, telegram_i18n_1.t)(lang, 'btn.skip') }, { text: (0, telegram_i18n_1.t)(lang, 'btn.cancel') }],
        ],
        resize_keyboard: true,
        one_time_keyboard: true,
        is_persistent: false,
        input_field_placeholder: (0, telegram_i18n_1.t)(lang, 'locationPlaceholder'),
    };
}
function ordersListKeyboard(orders, page, totalPages, lang) {
    const rows = orders.map((order) => [
        {
            text: `📦 ${order.trackingNumber}`,
            callback_data: `${telegram_constants_1.CALLBACK_DATA.orderView}:${order.id}`,
        },
        {
            text: `📱 ${(0, telegram_i18n_1.t)(lang, 'btn.showQr')}`,
            callback_data: `${telegram_constants_1.CALLBACK_DATA.orderQr}:${order.id}`,
        },
    ]);
    if (totalPages > 1) {
        const nav = [];
        if (page > 1) {
            nav.push({
                text: '<',
                callback_data: `${telegram_constants_1.CALLBACK_DATA.ordersPage}:${page - 1}`,
            });
        }
        nav.push({
            text: `${page}/${totalPages}`,
            callback_data: `${telegram_constants_1.CALLBACK_DATA.ordersPage}:${page}`,
        });
        if (page < totalPages) {
            nav.push({
                text: '>',
                callback_data: `${telegram_constants_1.CALLBACK_DATA.ordersPage}:${page + 1}`,
            });
        }
        rows.push(nav);
    }
    rows.push([
        { text: (0, telegram_i18n_1.t)(lang, 'btn.newOrder'), callback_data: telegram_constants_1.CALLBACK_DATA.newOrder },
    ]);
    return { inline_keyboard: rows };
}
function orderCardKeyboard(orderId, trackingUrl, lang) {
    const rows = [];
    if (trackingUrl && /^https?:\/\//i.test(trackingUrl)) {
        rows.push([{ text: (0, telegram_i18n_1.t)(lang, 'btn.openTracking'), url: trackingUrl }]);
    }
    rows.push([
        { text: `📱 ${(0, telegram_i18n_1.t)(lang, 'btn.showQr')}`, callback_data: `${telegram_constants_1.CALLBACK_DATA.orderQr}:${orderId}` },
        { text: (0, telegram_i18n_1.t)(lang, 'btn.refresh'), callback_data: `${telegram_constants_1.CALLBACK_DATA.orderView}:${orderId}` },
    ]);
    rows.push([
        { text: (0, telegram_i18n_1.t)(lang, 'btn.orders'), callback_data: `${telegram_constants_1.CALLBACK_DATA.ordersPage}:1` },
    ]);
    return { inline_keyboard: rows };
}
function backToMenuKeyboard(lang, orderId) {
    const rows = [];
    if (orderId) {
        rows.push([
            { text: `📱 ${(0, telegram_i18n_1.t)(lang, 'btn.showQr')}`, callback_data: `${telegram_constants_1.CALLBACK_DATA.orderQr}:${orderId}` },
            { text: (0, telegram_i18n_1.t)(lang, 'btn.refresh'), callback_data: `${telegram_constants_1.CALLBACK_DATA.orderView}:${orderId}` },
        ]);
    }
    rows.push([
        { text: (0, telegram_i18n_1.t)(lang, 'btn.newOrder'), callback_data: telegram_constants_1.CALLBACK_DATA.newOrder },
        { text: (0, telegram_i18n_1.t)(lang, 'btn.orders'), callback_data: `${telegram_constants_1.CALLBACK_DATA.ordersPage}:1` },
        { text: (0, telegram_i18n_1.t)(lang, 'btn.help'), callback_data: telegram_constants_1.CALLBACK_DATA.help },
    ]);
    return { inline_keyboard: rows };
}
exports.ORDERS_PER_PAGE = telegram_constants_1.ORDERS_PAGE_SIZE;
function newOrderChoiceKeyboard(lang, webAppUrl) {
    return {
        inline_keyboard: [
            [
                {
                    text: (0, telegram_i18n_1.t)(lang, 'btn.openOrderForm'),
                    web_app: { url: webAppUrl },
                },
            ],
            [
                {
                    text: (0, telegram_i18n_1.t)(lang, 'btn.useWizard'),
                    callback_data: telegram_constants_1.CALLBACK_DATA.startWizard,
                },
            ],
        ],
    };
}
//# sourceMappingURL=keyboards.js.map