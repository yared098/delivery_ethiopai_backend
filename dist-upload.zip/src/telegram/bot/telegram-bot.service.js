"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TelegramBotService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramBotService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const telegram_api_service_1 = require("../telegram-api.service");
const telegram_session_service_1 = require("../telegram-session.service");
const telegram_constants_1 = require("../telegram.constants");
const telegram_i18n_1 = require("../i18n/telegram.i18n");
const keyboards_1 = require("./keyboards");
const account_handler_1 = require("./handlers/account.handler");
const orders_handler_1 = require("./handlers/orders.handler");
const tracking_handler_1 = require("./handlers/tracking.handler");
const COMMAND_ALIASES = {
    start: 'start',
    menu: 'start',
    help: 'help',
    register: 'register',
    link: 'link',
    unlink: 'unlink',
    me: 'account',
    account: 'account',
    neworder: 'neworder',
    order: 'neworder',
    orders: 'orders',
    myorders: 'orders',
    myorder: 'orders',
    qr: 'qr',
    qrcode: 'qr',
    track: 'track',
    language: 'language',
    cancel: 'cancel',
};
let TelegramBotService = TelegramBotService_1 = class TelegramBotService {
    constructor(config, api, sessions, account, orders, tracking) {
        this.config = config;
        this.api = api;
        this.sessions = sessions;
        this.account = account;
        this.orders = orders;
        this.tracking = tracking;
        this.logger = new common_1.Logger(TelegramBotService_1.name);
        this.offset = 0;
        this.polling = false;
        this.stopRequested = false;
    }
    async onModuleInit() {
        if (!this.api.isConfigured) {
            this.logger.warn('TELEGRAM_BOT_TOKEN not configured — Telegram bot disabled');
            return;
        }
        await this.api.setMyCommands(telegram_constants_1.BOT_COMMANDS);
        if (this.config.get('TELEGRAM_POLLING') === 'true') {
            void this.startPolling();
        }
        else {
            this.logger.log('Telegram bot in webhook mode (POST /api/v1/telegram/webhook)');
        }
    }
    onModuleDestroy() {
        this.stopRequested = true;
    }
    async startPolling() {
        if (this.polling)
            return;
        this.polling = true;
        const me = await this.api.getMe();
        this.logger.log(`Telegram bot @${me?.username ?? 'unknown'} polling started`);
        while (!this.stopRequested) {
            const updates = await this.api.getUpdates(this.offset, 25);
            if (updates.length === 0) {
                await delay(telegram_constants_1.TELEGRAM_POLL_BACKOFF_MS);
                continue;
            }
            for (const update of updates) {
                this.offset = update.update_id + 1;
                await this.handleUpdate(update);
            }
        }
        this.polling = false;
        this.logger.log('Telegram bot polling stopped');
    }
    async handleUpdate(update) {
        try {
            if (update.callback_query) {
                await this.handleCallback(update.callback_query);
                return;
            }
            const message = update.message ?? update.edited_message;
            if (message)
                await this.handleMessage(message);
        }
        catch (err) {
            this.logger.error(`Telegram update ${update.update_id} failed: ${err instanceof Error ? err.message : String(err)}`);
        }
    }
    async handleMessage(message) {
        const chatId = String(message.chat.id);
        const text = (message.text ?? message.caption)?.trim() ?? '';
        const hasMedia = !!message.photo?.length || !!message.document;
        const hasLocation = !!message.location;
        if (!text && !hasMedia && !hasLocation)
            return;
        const ctx = this.buildContext(chatId);
        if (text.startsWith('/')) {
            await this.handleCommand(ctx, text);
            return;
        }
        if (hasLocation) {
            const session = this.sessions.get(chatId);
            if (session.step === 'order:sender_location') {
                await this.orders.handleStep(ctx, '', message);
            }
            return;
        }
        const menuAction = (0, keyboards_1.resolveMenuAction)(text);
        if (menuAction && menuAction !== 'btn.skip') {
            this.sessions.reset(chatId);
            await this.runMenuAction(ctx, menuAction);
            return;
        }
        const consumed = (await this.account.handleStep(ctx, text)) ||
            (await this.orders.handleStep(ctx, text, message));
        if (consumed)
            return;
        if (this.sessions.get(chatId).step === 'track:number') {
            this.sessions.reset(chatId);
            await this.tracking.track(ctx, text);
            return;
        }
        await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'unknownCommand'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
    }
    async handleCommand(ctx, raw) {
        const [commandPart, ...args] = raw.split(/\s+/);
        const command = commandPart.replace(/^\//, '').split('@')[0].toLowerCase();
        const action = COMMAND_ALIASES[command];
        if (action !== 'cancel')
            this.sessions.reset(ctx.chatId);
        switch (action) {
            case 'start':
                await this.sendWelcome(ctx);
                return;
            case 'help':
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'help'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
                return;
            case 'register':
                await this.account.beginRegister(ctx);
                return;
            case 'link':
                if (args[0]) {
                    await this.account.link(ctx, args[0]);
                    return;
                }
                await ctx.say('Usage: /link 0912345678');
                return;
            case 'unlink':
                await this.account.unlink(ctx);
                return;
            case 'account':
                await this.account.showProfile(ctx);
                return;
            case 'neworder':
                await this.orders.startNewOrder(ctx);
                return;
            case 'orders':
                await this.orders.listOrders(ctx, 1);
                return;
            case 'qr':
                if (args[0]) {
                    await this.orders.showOrderQr(ctx, args[0]);
                    return;
                }
                await this.orders.showLatestOrderQr(ctx);
                return;
            case 'track':
                if (args[0]) {
                    await this.tracking.track(ctx, args[0]);
                    return;
                }
                this.sessions.setStep(ctx.chatId, 'track:number');
                await this.tracking.promptForNumber(ctx);
                return;
            case 'language':
                await this.showLanguagePicker(ctx);
                return;
            case 'cancel':
                this.sessions.reset(ctx.chatId);
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'cancelled'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
                return;
            default:
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'unknownCommand'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
        }
    }
    async sendWelcome(ctx) {
        const customer = await this.account.findCustomer(ctx.chatId);
        const lines = [(0, telegram_i18n_1.t)(ctx.lang, 'welcome')];
        if (customer) {
            lines.push('', (0, telegram_i18n_1.t)(ctx.lang, 'welcomeBack', { name: customer.name ?? 'customer' }));
        }
        lines.push('', (0, telegram_i18n_1.t)(ctx.lang, 'mainMenu'));
        await ctx.say(lines.join('\n'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
    }
    async showLanguagePicker(ctx) {
        await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'languageTitle'), {
            inline_keyboard: [
                [
                    { text: 'English', callback_data: `${telegram_constants_1.CALLBACK_DATA.language}:en` },
                    { text: 'አማርኛ', callback_data: `${telegram_constants_1.CALLBACK_DATA.language}:am` },
                ],
            ],
        });
    }
    async runMenuAction(ctx, action) {
        switch (action) {
            case 'btn.newOrder':
                await this.orders.startNewOrder(ctx);
                return;
            case 'btn.orders':
                await this.orders.listOrders(ctx, 1);
                return;
            case 'btn.track':
                this.sessions.setStep(ctx.chatId, 'track:number');
                await this.tracking.promptForNumber(ctx);
                return;
            case 'btn.account':
                await this.account.showProfile(ctx);
                return;
            case 'btn.language':
                await this.showLanguagePicker(ctx);
                return;
            case 'btn.help':
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'help'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
                return;
            case 'btn.skip':
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'mainMenu'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
                return;
            case 'btn.register':
                await this.account.beginRegister(ctx);
                return;
            default:
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'mainMenu'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
        }
    }
    async handleCallback(query) {
        const chatId = String(query.message?.chat.id ?? query.from.id);
        const ctx = this.buildContext(chatId);
        const data = query.data ?? '';
        const [prefix, payload] = data.split(':');
        await this.api.answerCallbackQuery(query.id);
        switch (prefix) {
            case telegram_constants_1.CALLBACK_DATA.language:
                if ((0, telegram_i18n_1.isLang)(payload)) {
                    this.sessions.setLang(chatId, payload);
                    await ctx.say((0, telegram_i18n_1.t)(payload, 'languageSet'), (0, keyboards_1.mainMenuKeyboard)(payload));
                }
                return;
            case telegram_constants_1.CALLBACK_DATA.newOrder:
                this.sessions.reset(chatId);
                await this.orders.startNewOrder(this.buildContext(chatId));
                return;
            case telegram_constants_1.CALLBACK_DATA.ordersPage:
                await this.orders.listOrders(this.buildContext(chatId), Number(payload) || 1);
                return;
            case telegram_constants_1.CALLBACK_DATA.orderView:
                if (payload)
                    await this.orders.showOrder(this.buildContext(chatId), payload);
                return;
            case telegram_constants_1.CALLBACK_DATA.orderQr:
                if (payload)
                    await this.orders.showOrderQr(this.buildContext(chatId), payload);
                return;
            case telegram_constants_1.CALLBACK_DATA.payParty:
                if (payload === 'SENDER' || payload === 'RECEIVER') {
                    await this.orders.setPaymentParty(this.buildContext(chatId), payload);
                }
                return;
            case telegram_constants_1.CALLBACK_DATA.confirmOrder:
                await this.orders.confirmOrder(this.buildContext(chatId));
                return;
            case telegram_constants_1.CALLBACK_DATA.startWizard:
                this.sessions.reset(chatId);
                await this.orders.startOrderWizard(this.buildContext(chatId));
                return;
            case telegram_constants_1.CALLBACK_DATA.cancelFlow:
                this.sessions.reset(chatId);
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'cancelled'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
                return;
            case telegram_constants_1.CALLBACK_DATA.help:
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'help'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
                return;
            default:
                await ctx.say((0, telegram_i18n_1.t)(ctx.lang, 'unknownCommand'), (0, keyboards_1.mainMenuKeyboard)(ctx.lang));
        }
    }
    buildContext(chatId) {
        const session = this.sessions.get(chatId);
        const lang = (0, telegram_i18n_1.isLang)(session.lang) ? session.lang : telegram_i18n_1.DEFAULT_LANG;
        return {
            chatId,
            lang,
            say: (text, keyboard) => this.api.sendMessage(chatId, text, keyboard),
            sendPhoto: async (photo, caption, keyboard) => {
                const result = await this.api.sendPhoto(chatId, photo, caption, keyboard);
                return result !== null;
            },
        };
    }
};
exports.TelegramBotService = TelegramBotService;
exports.TelegramBotService = TelegramBotService = TelegramBotService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService,
        telegram_api_service_1.TelegramApiService,
        telegram_session_service_1.TelegramSessionService,
        account_handler_1.TelegramAccountHandler,
        orders_handler_1.TelegramOrdersHandler,
        tracking_handler_1.TelegramTrackingHandler])
], TelegramBotService);
function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}
//# sourceMappingURL=telegram-bot.service.js.map