export declare class TelegramBotModule {
}
