export declare class TelegramModule {
}
