import { OrderStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { TelegramApiService } from './telegram-api.service';
export interface OrderStatusNotifyPayload {
    id: string;
    trackingNumber: string;
    status: OrderStatus;
    senderId?: string | null;
    receiverId?: string | null;
}
export declare class TelegramNotifierService {
    private readonly api;
    private readonly prisma;
    private readonly logger;
    constructor(api: TelegramApiService, prisma: PrismaService);
    notifyCustomerId(customerId: string | null | undefined, text: string): Promise<boolean>;
    notifyChat(chatId: string | number, text: string): Promise<void>;
    notifyOrderStatus(payload: OrderStatusNotifyPayload): Promise<void>;
}
