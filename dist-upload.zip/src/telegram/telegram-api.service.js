"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var TelegramApiService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramApiService = void 0;
exports.splitText = splitText;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const axios_1 = __importDefault(require("axios"));
const telegram_constants_1 = require("./telegram.constants");
let TelegramApiService = TelegramApiService_1 = class TelegramApiService {
    constructor(config) {
        this.config = config;
        this.logger = new common_1.Logger(TelegramApiService_1.name);
        this.http = axios_1.default.create({
            baseURL: telegram_constants_1.TELEGRAM_API_BASE,
            timeout: telegram_constants_1.TELEGRAM_CALL_TIMEOUT_MS,
        });
    }
    get isConfigured() {
        return !!this.token;
    }
    get botToken() {
        return this.token;
    }
    get token() {
        const token = this.config.get('TELEGRAM_BOT_TOKEN');
        return token && token.trim().length > 0 ? token.trim() : undefined;
    }
    async call(method, payload = {}) {
        const token = this.token;
        if (!token) {
            this.logger.warn(`TELEGRAM_BOT_TOKEN is not set — skipped ${method}`);
            return null;
        }
        try {
            const res = await this.http.post(`/bot${token}/${method}`, payload);
            if (!res.data?.ok) {
                this.logger.error(`Telegram ${method} rejected: ${res.data?.description ?? 'unknown error'}`);
                return null;
            }
            return res.data.result ?? null;
        }
        catch (err) {
            const message = axios_1.default.isAxiosError(err)
                ? `${err.response?.status ?? 'network'} ${JSON.stringify(err.response?.data ?? err.message)}`
                : err instanceof Error
                    ? err.message
                    : String(err);
            this.logger.error(`Telegram ${method} failed: ${message}`);
            return null;
        }
    }
    async sendPhoto(chatId, photo, caption, replyMarkup) {
        const token = this.token;
        if (!token) {
            this.logger.warn(`TELEGRAM_BOT_TOKEN is not set — skipped sendPhoto`);
            return null;
        }
        try {
            if (typeof photo === 'string' && /^https?:\/\//i.test(photo)) {
                return await this.call('sendPhoto', {
                    chat_id: chatId,
                    photo,
                    ...(caption ? { caption } : {}),
                    ...(replyMarkup ? { reply_markup: replyMarkup } : {}),
                });
            }
            let buffer;
            if (Buffer.isBuffer(photo)) {
                buffer = photo;
            }
            else if (typeof photo === 'string' && photo.startsWith('data:')) {
                const base64Data = photo.replace(/^data:image\/\w+;base64,/, '');
                buffer = Buffer.from(base64Data, 'base64');
            }
            else {
                buffer = Buffer.from(photo);
            }
            const form = new FormData();
            form.append('chat_id', String(chatId));
            form.append('photo', new Blob([buffer], { type: 'image/png' }), 'order-qr.png');
            if (caption) {
                const safeCaption = caption.length > 1024 ? caption.slice(0, 1020) + '...' : caption;
                form.append('caption', safeCaption);
            }
            if (replyMarkup) {
                form.append('reply_markup', JSON.stringify(replyMarkup));
            }
            const res = await this.http.post(`/bot${token}/sendPhoto`, form);
            if (!res.data?.ok) {
                this.logger.error(`Telegram sendPhoto rejected: ${res.data?.description ?? 'unknown error'}`);
                return null;
            }
            return res.data.result ?? null;
        }
        catch (err) {
            const message = axios_1.default.isAxiosError(err)
                ? `${err.response?.status ?? 'network'} ${JSON.stringify(err.response?.data ?? err.message)}`
                : err instanceof Error
                    ? err.message
                    : String(err);
            this.logger.error(`Telegram sendPhoto failed: ${message}`);
            return null;
        }
    }
    async sendMessage(chatId, text, replyMarkup) {
        const chunks = splitText(text, telegram_constants_1.TELEGRAM_SAFE_CHUNK_LENGTH);
        for (let i = 0; i < chunks.length; i++) {
            const isLast = i === chunks.length - 1;
            await this.call('sendMessage', {
                chat_id: chatId,
                text: chunks[i],
                disable_web_page_preview: true,
                ...(isLast && replyMarkup ? { reply_markup: replyMarkup } : {}),
            });
        }
    }
    async sendToAdmins(text) {
        const admins = (this.config.get('TELEGRAM_ADMIN_CHAT_IDS') ?? '')
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean);
        if (admins.length === 0) {
            this.logger.warn('No TELEGRAM_ADMIN_CHAT_IDS configured — admin notify skipped');
            return false;
        }
        let sent = 0;
        for (const chatId of admins) {
            const result = await this.call('sendMessage', {
                chat_id: chatId,
                text,
                disable_web_page_preview: true,
            });
            if (result !== null)
                sent++;
        }
        return sent > 0;
    }
    async editMessageText(chatId, messageId, text, replyMarkup) {
        const result = await this.call('editMessageText', {
            chat_id: chatId,
            message_id: messageId,
            text,
            disable_web_page_preview: true,
            ...(replyMarkup ? { reply_markup: replyMarkup } : {}),
        });
        return result !== null;
    }
    async answerCallbackQuery(callbackQueryId, text) {
        await this.call('answerCallbackQuery', {
            callback_query_id: callbackQueryId,
            ...(text ? { text, show_alert: false } : {}),
        });
    }
    async sendChatAction(chatId, action = 'typing') {
        await this.call('sendChatAction', { chat_id: chatId, action });
    }
    async setMyCommands(commands) {
        await this.call('setMyCommands', { commands });
    }
    async getUpdates(offset, timeoutSec) {
        const updates = await this.call('getUpdates', {
            offset,
            timeout: timeoutSec,
            allowed_updates: ['message', 'callback_query'],
        });
        return updates ?? [];
    }
    async getMe() {
        return this.call('getMe');
    }
    async getFile(fileId) {
        return this.call('getFile', { file_id: fileId });
    }
    async downloadFile(filePath) {
        const token = this.token;
        if (!token) {
            this.logger.warn('TELEGRAM_BOT_TOKEN not configured — cannot download file');
            return null;
        }
        try {
            const url = `https://api.telegram.org/file/bot${token}/${filePath}`;
            const res = await axios_1.default.get(url, {
                responseType: 'arraybuffer',
                timeout: telegram_constants_1.TELEGRAM_CALL_TIMEOUT_MS,
            });
            return Buffer.from(res.data);
        }
        catch (err) {
            this.logger.error(`Failed to download file from Telegram (${filePath}): ${err instanceof Error ? err.message : String(err)}`);
            return null;
        }
    }
    async deleteMessage(chatId, messageId) {
        await this.call('deleteMessage', { chat_id: chatId, message_id: messageId });
    }
};
exports.TelegramApiService = TelegramApiService;
exports.TelegramApiService = TelegramApiService = TelegramApiService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], TelegramApiService);
function splitText(text, size) {
    if (text.length <= size)
        return [text];
    const chunks = [];
    let remaining = text;
    while (remaining.length > size) {
        let cut = remaining.lastIndexOf('\n', size);
        if (cut < size / 2)
            cut = size;
        chunks.push(remaining.slice(0, cut));
        remaining = remaining.slice(cut).replace(/^\n/, '');
    }
    if (remaining.length)
        chunks.push(remaining);
    return chunks;
}
//# sourceMappingURL=telegram-api.service.js.map