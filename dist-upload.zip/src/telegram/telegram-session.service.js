"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramSessionService = void 0;
const common_1 = require("@nestjs/common");
const telegram_i18n_1 = require("./i18n/telegram.i18n");
const telegram_constants_1 = require("./telegram.constants");
const MAX_TRACKED_SESSIONS = 5_000;
let TelegramSessionService = class TelegramSessionService {
    constructor() {
        this.sessions = new Map();
    }
    get(chatId) {
        const key = String(chatId);
        this.pruneIfNeeded();
        const existing = this.sessions.get(key);
        if (!existing) {
            const created = {
                chatId: key,
                lang: telegram_i18n_1.DEFAULT_LANG,
                step: 'idle',
                data: {},
                updatedAt: Date.now(),
            };
            this.sessions.set(key, created);
            return created;
        }
        if (Date.now() - existing.updatedAt > telegram_constants_1.SESSION_TTL_MS) {
            const reset = {
                chatId: key,
                lang: existing.lang,
                step: 'idle',
                data: {},
                updatedAt: Date.now(),
            };
            this.sessions.set(key, reset);
            return reset;
        }
        existing.updatedAt = Date.now();
        return existing;
    }
    setLang(chatId, lang) {
        const session = this.get(chatId);
        session.lang = (0, telegram_i18n_1.isLang)(lang) ? lang : telegram_i18n_1.DEFAULT_LANG;
        session.updatedAt = Date.now();
        this.sessions.set(session.chatId, session);
    }
    setStep(chatId, step, data = {}) {
        const session = this.get(chatId);
        session.step = step;
        session.data = { ...session.data, ...data };
        session.updatedAt = Date.now();
        this.sessions.set(session.chatId, session);
    }
    patchData(chatId, patch) {
        const session = this.get(chatId);
        session.data = { ...session.data, ...patch };
        session.updatedAt = Date.now();
        this.sessions.set(session.chatId, session);
    }
    reset(chatId) {
        const session = this.get(chatId);
        session.step = 'idle';
        session.data = {};
        session.updatedAt = Date.now();
        this.sessions.set(session.chatId, session);
    }
    pruneIfNeeded() {
        if (this.sessions.size < MAX_TRACKED_SESSIONS)
            return;
        const cutoff = Date.now() - telegram_constants_1.SESSION_TTL_MS;
        for (const [key, session] of this.sessions) {
            if (session.updatedAt < cutoff)
                this.sessions.delete(key);
        }
    }
};
exports.TelegramSessionService = TelegramSessionService;
exports.TelegramSessionService = TelegramSessionService = __decorate([
    (0, common_1.Injectable)()
], TelegramSessionService);
//# sourceMappingURL=telegram-session.service.js.map