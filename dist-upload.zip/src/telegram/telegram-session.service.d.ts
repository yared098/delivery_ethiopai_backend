import { Lang } from './i18n/telegram.i18n';
export type BotStep = 'idle' | 'register:name' | 'register:phone' | 'register:address' | 'order:receiver_name' | 'order:receiver_phone' | 'order:item' | 'order:photo' | 'order:weight' | 'order:sender_location' | 'order:payment' | 'order:confirm' | 'track:number';
export type PaymentPartyChoice = 'SENDER' | 'RECEIVER';
export interface SessionData {
    name?: string;
    phone?: string;
    address?: string;
    receiverName?: string;
    receiverPhone?: string;
    itemDescription?: string;
    photoUrl?: string;
    weightKg?: number;
    paymentParty?: PaymentPartyChoice;
    senderLat?: number;
    senderLng?: number;
    senderAddress?: string;
}
export interface BotSession {
    chatId: string;
    lang: Lang;
    step: BotStep;
    data: SessionData;
    updatedAt: number;
}
export declare class TelegramSessionService {
    private readonly sessions;
    get(chatId: string | number): BotSession;
    setLang(chatId: string | number, lang: Lang): void;
    setStep(chatId: string | number, step: BotStep, data?: SessionData): void;
    patchData(chatId: string | number, patch: SessionData): void;
    reset(chatId: string | number): void;
    private pruneIfNeeded;
}
