export declare const TELEGRAM_API_BASE = "https://api.telegram.org";
export declare const TELEGRAM_CALL_TIMEOUT_MS = 15000;
export declare const TELEGRAM_POLL_TIMEOUT_SEC = 25;
export declare const TELEGRAM_POLL_BACKOFF_MS = 3000;
export declare const TELEGRAM_MAX_MESSAGE_LENGTH = 4096;
export declare const TELEGRAM_SAFE_CHUNK_LENGTH = 3800;
export declare const SESSION_TTL_MS: number;
export declare const ORDERS_PAGE_SIZE = 5;
export declare const CALLBACK_DATA: {
    readonly menu: "menu";
    readonly language: "lang";
    readonly newOrder: "new";
    readonly startWizard: "wiz";
    readonly orders: "orders";
    readonly account: "account";
    readonly help: "help";
    readonly trackPrompt: "track";
    readonly orderView: "ord";
    readonly orderQr: "qr";
    readonly ordersPage: "opg";
    readonly payParty: "pay";
    readonly confirmOrder: "cfm";
    readonly cancelFlow: "abort";
};
export declare const BOT_COMMANDS: readonly [{
    readonly command: "start";
    readonly description: "Main menu";
}, {
    readonly command: "neworder";
    readonly description: "Create a new order";
}, {
    readonly command: "orders";
    readonly description: "My orders & QR codes";
}, {
    readonly command: "qr";
    readonly description: "Show pickup QR code for driver";
}, {
    readonly command: "track";
    readonly description: "Track an order: /track ETH-2026-XXXXXX";
}, {
    readonly command: "register";
    readonly description: "Create an account";
}, {
    readonly command: "link";
    readonly description: "Link account: /link 0912345678";
}, {
    readonly command: "me";
    readonly description: "My profile";
}, {
    readonly command: "language";
    readonly description: "Change language";
}, {
    readonly command: "help";
    readonly description: "Help";
}, {
    readonly command: "cancel";
    readonly description: "Cancel the current step";
}];
