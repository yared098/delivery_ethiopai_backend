import { ConfigService } from '@nestjs/config';
export interface TelegramUser {
    id: number;
    is_bot: boolean;
    first_name: string;
    last_name?: string;
    username?: string;
}
export interface TelegramChat {
    id: number;
    type: 'private' | 'group' | 'supergroup' | 'channel';
    first_name?: string;
    last_name?: string;
    username?: string;
}
export interface TelegramPhotoSize {
    file_id: string;
    file_unique_id: string;
    width: number;
    height: number;
    file_size?: number;
}
export interface TelegramDocument {
    file_id: string;
    file_unique_id: string;
    file_name?: string;
    mime_type?: string;
    file_size?: number;
}
export interface TelegramLocation {
    latitude: number;
    longitude: number;
    horizontal_accuracy?: number;
}
export interface TelegramMessage {
    message_id: number;
    from?: TelegramUser;
    chat: TelegramChat;
    date: number;
    text?: string;
    caption?: string;
    contact?: {
        phone_number: string;
        first_name: string;
        user_id?: number;
    };
    photo?: TelegramPhotoSize[];
    document?: TelegramDocument;
    location?: TelegramLocation;
}
export interface TelegramCallbackQuery {
    id: string;
    from: TelegramUser;
    message?: TelegramMessage;
    data?: string;
}
export interface TelegramUpdate {
    update_id: number;
    message?: TelegramMessage;
    edited_message?: TelegramMessage;
    callback_query?: TelegramCallbackQuery;
}
export interface TelegramApiError {
    ok: false;
    error_code?: number;
    description?: string;
}
export declare class TelegramApiService {
    private readonly config;
    private readonly logger;
    private readonly http;
    constructor(config: ConfigService);
    get isConfigured(): boolean;
    get botToken(): string | undefined;
    private get token();
    call<T>(method: string, payload?: Record<string, unknown> | FormData): Promise<T | null>;
    sendPhoto(chatId: string | number, photo: Buffer | string, caption?: string, replyMarkup?: Record<string, unknown>): Promise<TelegramMessage | null>;
    sendMessage(chatId: string | number, text: string, replyMarkup?: Record<string, unknown>): Promise<void>;
    sendToAdmins(text: string): Promise<boolean>;
    editMessageText(chatId: string | number, messageId: number, text: string, replyMarkup?: Record<string, unknown>): Promise<boolean>;
    answerCallbackQuery(callbackQueryId: string, text?: string): Promise<void>;
    sendChatAction(chatId: string | number, action?: string): Promise<void>;
    setMyCommands(commands: ReadonlyArray<{
        command: string;
        description: string;
    }>): Promise<void>;
    getUpdates(offset: number, timeoutSec: number): Promise<TelegramUpdate[]>;
    getMe(): Promise<TelegramUser | null>;
    getFile(fileId: string): Promise<{
        file_id: string;
        file_unique_id: string;
        file_path?: string;
        file_size?: number;
    } | null>;
    downloadFile(filePath: string): Promise<Buffer | null>;
    deleteMessage(chatId: string | number, messageId: number): Promise<void>;
}
export declare function splitText(text: string, size: number): string[];
