import { OrderStatus } from '@prisma/client';
export type Lang = 'en' | 'am';
export declare const LANGUAGES: ReadonlyArray<{
    code: Lang;
    label: string;
}>;
export declare const DEFAULT_LANG: Lang;
export type TranslationKey = 'btn.newOrder' | 'btn.orders' | 'btn.track' | 'btn.account' | 'btn.help' | 'btn.language' | 'btn.skip' | 'btn.confirm' | 'btn.cancel' | 'btn.back' | 'btn.refresh' | 'btn.openTracking' | 'btn.showQr' | 'btn.register' | 'btn.callSupport' | 'btn.shareLocation' | 'btn.openOrderForm' | 'btn.useWizard' | 'welcome' | 'welcomeBack' | 'help' | 'unknownCommand' | 'cancelled' | 'notRegistered' | 'registeredAs' | 'mainMenu' | 'menuPlaceholder' | 'locationPlaceholder' | 'languageTitle' | 'languageSet' | 'askName' | 'askPhone' | 'askAddress' | 'registrationDone' | 'registrationFailed' | 'accountLinked' | 'accountLinkFailed' | 'accountInUse' | 'accountUnlinked' | 'noLinkedAccount' | 'profileTitle' | 'nameLabel' | 'phoneLabel' | 'addressLabel' | 'notSet' | 'orderAskReceiverName' | 'orderAskReceiverPhone' | 'orderAskItem' | 'orderAskPhoto' | 'orderAskPhotoInvalid' | 'orderPhotoUploading' | 'orderPhotoUploaded' | 'orderPhotoUploadFailed' | 'orderAskWeight' | 'orderAskSenderLocation' | 'orderSenderLocationReceived' | 'orderSenderLocationSkipped' | 'orderAskPaymentParty' | 'paySender' | 'payReceiver' | 'orderConfirmTitle' | 'orderConfirmHint' | 'orderCreated' | 'orderCreateFailed' | 'noOrders' | 'ordersTitle' | 'ordersPageOf' | 'orderDetailsTitle' | 'senderLabel' | 'receiverLabel' | 'itemLabel' | 'photoLabel' | 'photoAttached' | 'feeLabel' | 'weightLabel' | 'statusLabel' | 'trackingLabel' | 'courierLabel' | 'eventsTitle' | 'noEvents' | 'estimateFrom' | 'orderQrPrompt' | 'qrCodeNotFound' | 'trackAsk' | 'trackNotFound' | 'trackTitle' | 'orderStatusPush' | 'invalidPhone' | 'invalidWeight' | 'invalidName' | 'invalidItem' | 'createOrderChoose';
export declare function isLang(value: string | undefined | null): value is Lang;
export declare function t(lang: Lang, key: TranslationKey, vars?: Record<string, string | number>): string;
export declare function statusLabel(lang: Lang, status: OrderStatus): string;
