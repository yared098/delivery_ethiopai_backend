"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BOT_COMMANDS = exports.CALLBACK_DATA = exports.ORDERS_PAGE_SIZE = exports.SESSION_TTL_MS = exports.TELEGRAM_SAFE_CHUNK_LENGTH = exports.TELEGRAM_MAX_MESSAGE_LENGTH = exports.TELEGRAM_POLL_BACKOFF_MS = exports.TELEGRAM_POLL_TIMEOUT_SEC = exports.TELEGRAM_CALL_TIMEOUT_MS = exports.TELEGRAM_API_BASE = void 0;
exports.TELEGRAM_API_BASE = 'https://api.telegram.org';
exports.TELEGRAM_CALL_TIMEOUT_MS = 15_000;
exports.TELEGRAM_POLL_TIMEOUT_SEC = 25;
exports.TELEGRAM_POLL_BACKOFF_MS = 3_000;
exports.TELEGRAM_MAX_MESSAGE_LENGTH = 4_096;
exports.TELEGRAM_SAFE_CHUNK_LENGTH = 3_800;
exports.SESSION_TTL_MS = 30 * 60 * 1_000;
exports.ORDERS_PAGE_SIZE = 5;
exports.CALLBACK_DATA = {
    menu: 'menu',
    language: 'lang',
    newOrder: 'new',
    startWizard: 'wiz',
    orders: 'orders',
    account: 'account',
    help: 'help',
    trackPrompt: 'track',
    orderView: 'ord',
    orderQr: 'qr',
    ordersPage: 'opg',
    payParty: 'pay',
    confirmOrder: 'cfm',
    cancelFlow: 'abort',
};
exports.BOT_COMMANDS = [
    { command: 'start', description: 'Main menu' },
    { command: 'neworder', description: 'Create a new order' },
    { command: 'orders', description: 'My orders & QR codes' },
    { command: 'qr', description: 'Show pickup QR code for driver' },
    { command: 'track', description: 'Track an order: /track ETH-2026-XXXXXX' },
    { command: 'register', description: 'Create an account' },
    { command: 'link', description: 'Link account: /link 0912345678' },
    { command: 'me', description: 'My profile' },
    { command: 'language', description: 'Change language' },
    { command: 'help', description: 'Help' },
    { command: 'cancel', description: 'Cancel the current step' },
];
//# sourceMappingURL=telegram.constants.js.map