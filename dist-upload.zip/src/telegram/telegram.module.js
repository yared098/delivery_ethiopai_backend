"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const prisma_module_1 = require("../prisma/prisma.module");
const telegram_api_service_1 = require("./telegram-api.service");
const telegram_session_service_1 = require("./telegram-session.service");
const telegram_notifier_service_1 = require("./telegram-notifier.service");
let TelegramModule = class TelegramModule {
};
exports.TelegramModule = TelegramModule;
exports.TelegramModule = TelegramModule = __decorate([
    (0, common_1.Module)({
        imports: [config_1.ConfigModule, prisma_module_1.PrismaModule],
        providers: [telegram_api_service_1.TelegramApiService, telegram_session_service_1.TelegramSessionService, telegram_notifier_service_1.TelegramNotifierService],
        exports: [telegram_api_service_1.TelegramApiService, telegram_session_service_1.TelegramSessionService, telegram_notifier_service_1.TelegramNotifierService],
    })
], TelegramModule);
//# sourceMappingURL=telegram.module.js.map