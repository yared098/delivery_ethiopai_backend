import { Response } from 'express';
import { TelegramWebAppService } from './telegram-webapp.service';
import { OrdersService } from '../../orders/orders.service';
import { PrismaService } from '../../prisma/prisma.service';
export declare class TelegramWebAppController {
    private readonly webApp;
    private readonly orders;
    private readonly prisma;
    private readonly logger;
    constructor(webApp: TelegramWebAppService, orders: OrdersService, prisma: PrismaService);
    serveForm(res: Response): void;
    createOrder(authHeader: string, body: unknown): Promise<{
        success: boolean;
        trackingNumber: string;
        deliveryFee: number;
        status: import("@prisma/client").$Enums.OrderStatus;
        message: string;
    }>;
}
