export declare class TelegramWebAppModule {
}
