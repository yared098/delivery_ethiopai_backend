export declare class WebAppCreateOrderDto {
    receiverName: string;
    receiverPhone: string;
    itemDescription: string;
    weightKg: number;
    senderLat?: number;
    senderLng?: number;
    senderAddress?: string;
    paymentParty?: 'SENDER' | 'RECEIVER';
    photoUrl?: string;
}
