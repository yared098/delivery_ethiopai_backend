"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var TelegramWebAppService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramWebAppService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const crypto_1 = require("crypto");
let TelegramWebAppService = TelegramWebAppService_1 = class TelegramWebAppService {
    constructor(config) {
        this.config = config;
        this.logger = new common_1.Logger(TelegramWebAppService_1.name);
    }
    validateInitData(initData) {
        const token = this.config.get('TELEGRAM_BOT_TOKEN');
        if (!token) {
            throw new common_1.UnauthorizedException('Bot token not configured');
        }
        const params = new URLSearchParams(initData);
        const hash = params.get('hash');
        if (!hash) {
            throw new common_1.UnauthorizedException('Missing hash in initData');
        }
        params.delete('hash');
        const dataCheckString = Array.from(params.entries())
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([k, v]) => `${k}=${v}`)
            .join('\n');
        const secretKey = (0, crypto_1.createHmac)('sha256', 'WebAppData').update(token).digest();
        const expectedHash = (0, crypto_1.createHmac)('sha256', secretKey)
            .update(dataCheckString)
            .digest('hex');
        if (expectedHash !== hash) {
            this.logger.warn('Telegram WebApp initData hash mismatch');
            throw new common_1.UnauthorizedException('Invalid initData signature');
        }
        const authDate = Number(params.get('auth_date') ?? 0);
        const ageSeconds = Math.floor(Date.now() / 1000) - authDate;
        if (ageSeconds > 86_400) {
            throw new common_1.UnauthorizedException('initData expired (older than 24 h)');
        }
        const userJson = params.get('user');
        if (!userJson) {
            throw new common_1.UnauthorizedException('No user in initData');
        }
        let user;
        try {
            user = JSON.parse(userJson);
        }
        catch {
            throw new common_1.UnauthorizedException('Malformed user in initData');
        }
        return {
            id: user['id'],
            telegramId: String(user['id']),
            first_name: user['first_name'] ?? '',
            last_name: user['last_name'],
            username: user['username'],
            language_code: user['language_code'],
        };
    }
    get isConfigured() {
        const token = this.config.get('TELEGRAM_BOT_TOKEN');
        return !!token && token.trim().length > 0;
    }
    get webAppUrl() {
        const url = (this.config.get('PUBLIC_API_URL') ?? 'http://localhost:3000').replace(/\/$/, '');
        if (!url.startsWith('https://')) {
            this.logger.warn(`PUBLIC_API_URL is not HTTPS (${url}). Telegram Web Apps require HTTPS links — ` +
                'the "Open order form" button will fail until you set PUBLIC_API_URL to an https:// URL.');
        }
        return url;
    }
};
exports.TelegramWebAppService = TelegramWebAppService;
exports.TelegramWebAppService = TelegramWebAppService = TelegramWebAppService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], TelegramWebAppService);
//# sourceMappingURL=telegram-webapp.service.js.map