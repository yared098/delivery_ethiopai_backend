import { ConfigService } from '@nestjs/config';
export interface TelegramWebAppUser {
    id: number;
    first_name: string;
    last_name?: string;
    username?: string;
    language_code?: string;
    telegramId: string;
}
export declare class TelegramWebAppService {
    private readonly config;
    private readonly logger;
    constructor(config: ConfigService);
    validateInitData(initData: string): TelegramWebAppUser;
    get isConfigured(): boolean;
    get webAppUrl(): string;
}
