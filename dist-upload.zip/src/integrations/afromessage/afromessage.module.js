"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AfroMessageModule = void 0;
const common_1 = require("@nestjs/common");
const afromessage_service_1 = require("./afromessage.service");
const telegram_module_1 = require("../../telegram/telegram.module");
let AfroMessageModule = class AfroMessageModule {
};
exports.AfroMessageModule = AfroMessageModule;
exports.AfroMessageModule = AfroMessageModule = __decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        imports: [telegram_module_1.TelegramModule],
        providers: [afromessage_service_1.AfroMessageService],
        exports: [afromessage_service_1.AfroMessageService],
    })
], AfroMessageModule);
//# sourceMappingURL=afromessage.module.js.map