import { ConfigService } from '@nestjs/config';
import { TelegramApiService } from '../../telegram/telegram-api.service';
export declare class AfroMessageService {
    private config;
    private telegram;
    private readonly logger;
    private readonly baseUrl;
    constructor(config: ConfigService, telegram: TelegramApiService);
    private send;
    sendOtp(phone: string, code: string): Promise<boolean>;
    sendReceiverLink(phone: string, senderName: string, linkUrl: string): Promise<boolean>;
    sendTrackingLink(phone: string, trackingNumber: string, trackingUrl: string): Promise<boolean>;
    sendCourierAssigned(phone: string, trackingNumber: string, courierName: string, courierPhone: string): Promise<boolean>;
    sendPickedUp(phone: string, trackingNumber: string): Promise<boolean>;
    sendProximityAlert(phone: string, trackingNumber: string, minutesAway: number): Promise<boolean>;
    sendDelivered(phone: string, trackingNumber: string): Promise<boolean>;
    sendArrivedAtBranch(phone: string, trackingNumber: string, branchName: string, isReceiver?: boolean): Promise<boolean>;
    sendHandedOver(phone: string, trackingNumber: string, branchName: string, isReceiver?: boolean): Promise<boolean>;
    sendCustomSms(phone: string, message: string): Promise<boolean>;
}
