export declare class AfroMessageModule {
}
