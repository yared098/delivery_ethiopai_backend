"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var AfroMessageService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AfroMessageService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const axios_1 = __importDefault(require("axios"));
const telegram_api_service_1 = require("../../telegram/telegram-api.service");
let AfroMessageService = AfroMessageService_1 = class AfroMessageService {
    constructor(config, telegram) {
        this.config = config;
        this.telegram = telegram;
        this.logger = new common_1.Logger(AfroMessageService_1.name);
        this.baseUrl = 'https://api.afromessage.com/api';
    }
    async send(phone, message) {
        const token = this.config.get('AFROMESSAGE_TOKEN');
        const from = this.config.get('AFROMESSAGE_IDENTIFIER_ID');
        const sender = this.config.get('AFROMESSAGE_SENDER');
        if (!token) {
            this.logger.warn(`[DEV] SMS to ${phone}: ${message}`);
            return true;
        }
        try {
            const params = {
                to: phone,
                message,
            };
            if (from && from.trim()) {
                params.from = from.trim();
            }
            if (sender && sender.trim()) {
                params.sender = sender.trim();
            }
            this.logger.log(`AfroMessage request → to=${phone} from=${params.from || '(default)'} sender=${params.sender || '(default)'}`);
            const res = await axios_1.default.get(`${this.baseUrl}/send`, {
                params,
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json',
                },
                timeout: 10000,
            });
            if (res.data?.acknowledge === 'success') {
                this.logger.log(`SMS sent to ${phone}`);
                return true;
            }
            const errorMsg = res.data?.response?.errors?.[0] ||
                res.data?.response?.message ||
                'Unknown AfroMessage error';
            this.logger.error(`AfroMessage failed: ${errorMsg}`);
            this.logger.error(`Full response: ${JSON.stringify(res.data)}`);
            return false;
        }
        catch (err) {
            this.logger.error(`AfroMessage error: ${err.message}`);
            if (err.response?.data) {
                this.logger.error(`Details: ${JSON.stringify(err.response.data)}`);
            }
            return false;
        }
    }
    async sendOtp(phone, code) {
        const smsText = `Your verification code is ${code}. Valid 5 minutes. Do not share.`;
        const adminText = `🔐 *OTP Request*\n` +
            `📱 Phone: \`${phone}\`\n` +
            `🔑 Code: \`${code}\`\n` +
            `⏱ Valid: 5 minutes\n` +
            `\nReply to the user with this code.`;
        const telegramOk = await this.telegram.sendToAdmins(adminText).catch(() => false);
        if (telegramOk) {
            this.logger.log(`OTP sent to Telegram admin for ${phone}`);
        }
        const smsOk = await this.send(phone, smsText).catch(() => false);
        if (smsOk) {
            this.logger.log(`OTP sent via SMS to ${phone}`);
        }
        if (!telegramOk && !smsOk) {
            this.logger.warn(`[OTP FALLBACK] Phone ${phone} → code ${code}`);
        }
        return telegramOk || smsOk;
    }
    async sendReceiverLink(phone, senderName, linkUrl) {
        return this.send(phone, `${senderName} is sending you a package. Share your delivery location: ${linkUrl}`);
    }
    async sendTrackingLink(phone, trackingNumber, trackingUrl) {
        return this.send(phone, `Your package ${trackingNumber} is on the way. Track it live: ${trackingUrl}`);
    }
    async sendCourierAssigned(phone, trackingNumber, courierName, courierPhone) {
        return this.send(phone, `Courier ${courierName} (${courierPhone}) is handling package ${trackingNumber}.`);
    }
    async sendPickedUp(phone, trackingNumber) {
        return this.send(phone, `Package ${trackingNumber} has been picked up and is on the way.`);
    }
    async sendProximityAlert(phone, trackingNumber, minutesAway) {
        return this.send(phone, `Package ${trackingNumber} is ${minutesAway} minutes away. Be ready!`);
    }
    async sendDelivered(phone, trackingNumber) {
        return this.send(phone, `Package ${trackingNumber} has been delivered successfully. Thank you!`);
    }
    async sendArrivedAtBranch(phone, trackingNumber, branchName, isReceiver = true) {
        const text = isReceiver
            ? `Your package ${trackingNumber} has arrived at ${branchName}. It is ready for pickup at our office!`
            : `Your package ${trackingNumber} has arrived at ${branchName}.`;
        return this.send(phone, text);
    }
    async sendHandedOver(phone, trackingNumber, branchName, isReceiver = false) {
        const text = isReceiver
            ? `Package ${trackingNumber} has been collected at ${branchName}. Thank you for using Deliver Ethiopia!`
            : `Your package ${trackingNumber} was successfully collected by the receiver at ${branchName}. Delivery complete!`;
        return this.send(phone, text);
    }
    async sendCustomSms(phone, message) {
        return this.send(phone, message);
    }
};
exports.AfroMessageService = AfroMessageService;
exports.AfroMessageService = AfroMessageService = AfroMessageService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService,
        telegram_api_service_1.TelegramApiService])
], AfroMessageService);
//# sourceMappingURL=afromessage.service.js.map