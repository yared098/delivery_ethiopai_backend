import { PrismaService } from '../prisma/prisma.service';
import { CreateRegionDto } from './dto/create-region.dto';
import { UpdateRegionDto } from './dto/update-region.dto';
export declare class RegionsService {
    private prisma;
    constructor(prisma: PrismaService);
    create(dto: CreateRegionDto, currentUser: any): Promise<{
        createdBy: {
            id: string;
            name: string;
            phone: string;
        } | null;
    } & {
        id: string;
        code: string;
        name: string;
        createdById: string | null;
        createdAt: Date;
        centerLat: number | null;
        centerLng: number | null;
        isInterCityHub: boolean;
    }>;
    findAll(): Promise<({
        createdBy: {
            id: string;
            name: string;
            phone: string;
        } | null;
        _count: {
            staff: number;
            branches: number;
            couriers: number;
        };
    } & {
        id: string;
        code: string;
        name: string;
        createdById: string | null;
        createdAt: Date;
        centerLat: number | null;
        centerLng: number | null;
        isInterCityHub: boolean;
    })[]>;
    findOne(id: string): Promise<{
        createdBy: {
            id: string;
            name: string;
            phone: string;
        } | null;
        _count: {
            staff: number;
            couriers: number;
        };
        branches: ({
            createdBy: {
                id: string;
                name: string;
            } | null;
        } & {
            id: string;
            code: string;
            name: string;
            createdById: string | null;
            createdAt: Date;
            updatedAt: Date;
            phone: string | null;
            regionId: string;
            isActive: boolean;
            city: string | null;
            woreda: string | null;
            address: string | null;
            lat: number | null;
            lng: number | null;
        })[];
    } & {
        id: string;
        code: string;
        name: string;
        createdById: string | null;
        createdAt: Date;
        centerLat: number | null;
        centerLng: number | null;
        isInterCityHub: boolean;
    }>;
    update(id: string, dto: UpdateRegionDto): Promise<{
        id: string;
        code: string;
        name: string;
        createdById: string | null;
        createdAt: Date;
        centerLat: number | null;
        centerLng: number | null;
        isInterCityHub: boolean;
    }>;
    remove(id: string): Promise<{
        message: string;
    }>;
}
