"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RegionsService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
let RegionsService = class RegionsService {
    constructor(prisma) {
        this.prisma = prisma;
    }
    async create(dto, currentUser) {
        const existing = await this.prisma.region.findFirst({
            where: { OR: [{ name: dto.name }, { code: dto.code }] },
        });
        if (existing) {
            throw new common_1.ConflictException(`Region with ${existing.name === dto.name ? 'name' : 'code'} already exists`);
        }
        return this.prisma.region.create({
            data: {
                name: dto.name,
                code: dto.code,
                createdById: currentUser.id,
            },
            include: {
                createdBy: { select: { id: true, name: true, phone: true } },
            },
        });
    }
    async findAll() {
        return this.prisma.region.findMany({
            orderBy: { name: 'asc' },
            include: {
                createdBy: { select: { id: true, name: true, phone: true } },
                _count: {
                    select: { staff: true, branches: true, couriers: true },
                },
            },
        });
    }
    async findOne(id) {
        const region = await this.prisma.region.findUnique({
            where: { id },
            include: {
                createdBy: { select: { id: true, name: true, phone: true } },
                branches: {
                    orderBy: { name: 'asc' },
                    include: {
                        createdBy: { select: { id: true, name: true } },
                    },
                },
                _count: { select: { staff: true, couriers: true } },
            },
        });
        if (!region)
            throw new common_1.NotFoundException('Region not found');
        return region;
    }
    async update(id, dto) {
        await this.findOne(id);
        if (dto.name || dto.code) {
            const conflict = await this.prisma.region.findFirst({
                where: {
                    AND: [
                        { id: { not: id } },
                        {
                            OR: [
                                dto.name ? { name: dto.name } : {},
                                dto.code ? { code: dto.code } : {},
                            ].filter((x) => Object.keys(x).length > 0),
                        },
                    ],
                },
            });
            if (conflict)
                throw new common_1.ConflictException('Name or code already in use');
        }
        return this.prisma.region.update({
            where: { id },
            data: dto,
        });
    }
    async remove(id) {
        await this.findOne(id);
        const staffCount = await this.prisma.staff.count({ where: { regionId: id } });
        const branchCount = await this.prisma.branch.count({ where: { regionId: id } });
        const courierCount = await this.prisma.courier.count({ where: { regionId: id } });
        if (staffCount > 0 || branchCount > 0 || courierCount > 0) {
            throw new common_1.BadRequestException(`Cannot delete region with ${staffCount} staff, ${branchCount} branches, ${courierCount} couriers`);
        }
        await this.prisma.region.delete({ where: { id } });
        return { message: 'Region deleted' };
    }
};
exports.RegionsService = RegionsService;
exports.RegionsService = RegionsService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], RegionsService);
//# sourceMappingURL=regions.service.js.map