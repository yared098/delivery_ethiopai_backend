export declare class RegionsModule {
}
